<?php
header('HTTP/1.1 503 Service Temporarily Unavailable');
header('Status: 503 Service Temporarily Unavailable');
header('Retry-After: 86400'); // in seconds

global $smp_config,$config;
global $dirPrefix,$addonRelativeCode;
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<title><?php echo $config['title']; ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script src="<?php echo $addonRelativeCode; ?>/view/jquery.js"></script>
		<script src="<?php echo $addonRelativeCode; ?>/view/script.js"></script>
		<script src="<?php echo $addonRelativeCode; ?>/view/bootstrap/js/bootstrap.js"></script>
		<link rel="stylesheet" href="<?php echo $addonRelativeCode; ?>/view/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="<?php echo $addonRelativeCode; ?>/view/bootstrap/css/bootstrap-responsive.min.css">

		<style>
		body{
			background-color: #000;
			background-image: url('<?php echo $smp_config['background_image']; ?>');
			background-repeat: no-repeat;
			background-attachment: fixed;
			background-position: top center;
			-webkit-background-size: cover;
			-moz-background-size: cover;
			-o-background-size: cover;
			background-size: cover;
			text-align: center;
		}
		body p{
			font-size:14px;
		}
		</style>
	</head>
	<body>
	<div id="mmModal" class="modal hide fade">
	<? if (!empty($smp_config['title'])) { ?>
	  <div class="modal-header">
	    <h1><?php echo $smp_config['title']; ?></h1>
	  </div>
	<? } ?>
	  <div class="modal-body">
	    <?php echo $smp_config['content']; ?>
	  </div>
	  <div class="Dmodal-footer">
	  </div><!-- .modal-footer -->
	</div>
	<script>
	jQuery(document).ready(function($){
		$('#mmModal').modal({
		  keyboard: false
		})
		$('#mmModal').on('shown', function () {
			$('body,.modal-backdrop').unbind();
		});
		
	});
	</script>
	  <!--[if lt IE 9]>
	  <script>
	  jQuery(document).ready(function($){
	    <?php
	    if(!empty($smp_config['background_image'])):
	    ?>
	    $.supersized({
	      slides:[ {image : '<?php echo $smp_config['background_image']; ?>'} ]
	    });
	    <?php
	    endif;
	    ?>
	  });
	  </script>
	  <![endif]-->
	</body>
</html>
<?php exit(); ?>
