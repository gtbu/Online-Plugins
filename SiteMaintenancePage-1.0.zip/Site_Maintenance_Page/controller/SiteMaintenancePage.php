<?php defined('is_running') or die('Not an entry point...');

class SiteMaintenancePage{
	function SiteMaintenancePage(){
		$this->Init();
	}
	function Init(){
		global $addonPathData;

		//get the configuration
		$this->config_file = $addonPathData.'/config.php';
		$config = array();
		if( file_exists($this->config_file) ){
			include($this->config_file);
		}
		$this->config = $config;

		$this->config += SiteMaintenancePage::Defaults();
	}
	function WhichPage($page){
		global $addonPathData,$addonPathCode;
		if (!common::LoggedIn()) {
			if ($this->config['enabled']) {
				global $smp_config;
				$smp_config=$this->config;
				gpPlugin::incl('view/maintenancemode.php');
			}
		}elseif ($this->config['enabled']) {
		//echo '<b>'.'</b> ';
			message('NOTICE: Site Maintenance Page is enabled. Only logged in users can see the site. ('.common::Link('Admin_SiteMaintenancePage','Disable Maintenance Page now','cmd=disable').')');
		}
		return $page;
	}

	function Defaults(){
		return array('enabled'=>false,'background_image'=>'','content'=>'','title'=>'Site Maintenance');
	}

	function SaveConfig(){
		return gpFiles::SaveArray($this->config_file,'config',$this->config);
	}

	function AutoSlug_Rename($title,$new_title){
		//prepare post
		$_POST['new_title']=$new_title;
		if ($this->config['autoSlug_addRedirect']){
			$_POST['add_redirect'] = 'add';
		}else {
			unset($_POST['add_redirect']);
		}

		//rename title
		includeFile('tool/Page_Rename.php');
		//gp_rename::RenameFile($title);
		$success = gp_rename::RenameFileWorker($title);
		$this->AutoSlugSaveChanges();

		//if( !admin_tools::SavePagesPHP() ){
		//	message($langmessage['OOPS'].' (R1)');
		//	return false;
		//}
		//message ('RENAMED:'.$success);
		return $success;
	}
	function DoAutoSlug($index,$parent_index=false){
		//global $langmessage, $page, $gp_index, $gp_titles,$gp_menu;
		global $langmessage, $gp_menu,$gp_titles;
		//if (empty($this->MenuCommand) || $index!=$this->MenuCommandIndex || !$this->config['autoSlug'] || empty($title) || empty($index))
		if (!$this->config['autoSlug'] || empty($index))
			return false;

		if ($parent_index===false){
			//lookup current immediate parent
			$current_menu=$gp_menu;
			$parent_index=$this->GetParentIndex($index,$current_menu);
		}
		$new_title=array();
		$parent_title=common::IndexToTitle($parent_index);
		if (!empty($parent_title))
			$new_title[]=$parent_title;
		$title=common::IndexToTitle($index);

		$title1=$title;
		if (isset($gp_titles[$index]['label'])) {
			$title1=$gp_titles[$index]['label'];
		}
		$title1=strtolower(basename($title1));
		$title1=str_replace('_',' ',$title1);//boundaries don't count _

		$title2=$title1;
		$title2=str_replace(array('?','%','$','!','@','#'),'', $title2);
		$title2=preg_replace('/\b('.implode('|',$this->config['autoSlug_removeWords']).')\b/i','', $title2);
		$title2=trim($title2,' ');//don't want extra spaces to turn into dashes

		//$title1=str_replace(array('_',' '),'-',$title1);
		$new_title[]=str_replace(' ','-',$title2?$title2:$title1);

		$new_title_path = implode('/',$new_title);
		$success=$this->AutoSlug_Rename($title,$new_title_path);
		if ($success) {
			return $success;
		}

		//hide the failed page rename
		global $wbMessageBuffer;
		array_pop($wbMessageBuffer);

		array_pop($new_title);
		$new_title[]=str_replace(' ','-',$title1);

		$new_title_path = implode('/',$new_title);
		$success=$this->AutoSlug_Rename($title,$new_title_path);
		return $success;
	}

	function AutoSlugInstall(){
		global $gp_menu;
		$current_menu=$gp_menu;
		foreach($current_menu  as $index => $level){
			$this->DoAutoSlug($index);
		}
		message('Applied');
		return $this->AutoSlugSaveChanges();
	}

	function AutoSlugSaveChanges(){
		if( !admin_tools::SavePagesPHP() ){
			message($langmessage['OOPS'].' (R1)');
			return false;
		}
		return true;
	}

	function AutoSlugUninstall(){
		global $gp_menu,$gp_titles;
		$current_menu=$gp_menu;
		foreach($current_menu  as $index => $level){
			$title=common::IndexToTitle($index);
			$gp_title=$gp_titles[$index];
			$label=$index;
			if (array_key_exists('label',$gp_title)){
				$label=$gp_title['label'];
			}else if (array_key_exists('lang_index',$gp_title)){
				$label=ucwords($gp_title['lang_index']);
			}
			$new_title = admin_tools::LabelToSlug($label);
			$success=$this->AutoSlug_Rename($title,$new_title);
		}
		message('Removed');
		return $this->AutoSlugSaveChanges();
	}
	
	function Install(){
		message('Installing');
	}
}
