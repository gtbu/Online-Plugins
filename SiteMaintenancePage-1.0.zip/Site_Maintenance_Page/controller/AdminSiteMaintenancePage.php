<?php defined('is_running') or die('Not an entry point...');

gpPlugin::incl('controller/SiteMaintenancePage.php');

class AdminSiteMaintenancePage extends SiteMaintenancePage{

	function AdminSiteMaintenancePage(){
		$this->Init();

		global $gp_menu;
		global $langmessage;

		$cmd = common::GetCommand();
		switch($cmd){
			case 'saveconfig':
				$this->SaveConfigForm();
			break;
			case $langmessage['restore_defaults']:
				$this->SaveDefaultConfigForm();
			break;
			case 'disable':
				$this->config['enabled']=false;
				$this->SaveConfig();
				$url=$_SERVER['HTTP_REFERER'];
				if (empty($url)) {
					$url=common::GetUrl();
				}
				common::Redirect($url);
			break;
		}

		echo '<h2>';
		echo common::Link('Admin_SiteMaintenancePage','Admin Site Maintenance Page');
		echo '</h2>';
		$this->EditConfigForm();

		//echo '<p>';
		//echo '<b>'.common::Link('Admin_SiteMaintenancePage','Edit Config','cmd=editconfig').'</b> ';
		//echo 'Edit the Site SEO config.';
		//echo '</p>';
	}

	function SaveConfigForm(){
		global $langmessage;

		$this->config['enabled'] = isset($_POST['enabled'])?true:false;
		$this->config['background_image'] = ($_POST['background_image']);
		$this->config['title'] = ($_POST['title']);
		$content =& $_POST['content'];
		gpFiles::cleanText($content);
		$this->config['content'] = $content;

		if( $this->SaveConfig() ){
			message($langmessage['SAVED']);
		}else{
			message($langmessage['OOPS']);
		}
	}

	function SaveDefaultConfigForm(){
		global $langmessage;

		$this->config=$this->Defaults();

		if( $this->SaveConfig() ){
			message($langmessage['SAVED']);
		}else{
			message($langmessage['OOPS']);
		}
	}

	function EditConfigForm(){
		global $langmessage;
		$content = $this->config['content'];
		if( !empty($_POST['content']) ){
			$content = $_POST['content'];
		}
		echo '<h2>';
		//echo 'Admin Site Maintenance Page';
		//echo common::Link('Admin_SiteSEO','Admin Site SEO');
		echo ' &#187; ';
		echo $langmessage['configuration'];
		echo '</h2>';
		$defaults=$this->Defaults();

		echo '<form method="post" action="'.common::GetUrl('Admin_SiteMaintenancePage').'">';
		echo '<table style="width:100%" class="bordered">';
		echo '<tr>';
			echo '<th>';
			echo 'Option';
			echo '</th>';
			echo '<th>';
			echo 'Value';
			echo '</th>';
			echo '<th>';
			echo 'Default';
			echo '</th>';
			echo '</tr>';
		echo '<tr>';
			echo '<td><b>Enabled:</b></td>';
			echo '<td>';
			echo '<input type="checkbox" name="enabled" '.($this->config['enabled']?' CHECKED':'').'/>';
			echo '</td><td>';
			echo $defaults['enabled']?'yes':'no';
			echo '</td></tr>';
		echo '<tr>';
			echo '<td>&nbsp;&nbsp;&nbsp;Title:</td>';
			echo '<td>';
			echo '<input type="text" name="title" value="'.($this->config['title']).'" />';
			echo '</td><td>';
			echo $defaults['title'];
			echo '</td></tr>';
		echo '<tr>';
			echo '<td>&nbsp;&nbsp;&nbsp;Content:</td>';
			echo '<td>';
			if (class_exists('gp_edit')) {
				gp_edit::UseCK( $this->config['content'],'content' );
			} else {
				common::UseCK( $this->config['content'],'content' );
			}
			echo '</td><td>';
			echo $defaults['content'];
			echo '</td></tr>';
		echo '<tr>';
			echo '<td>&nbsp;&nbsp;&nbsp;Background Image:</td>';
			echo '<td>';
			echo '<input type="text" name="background_image" value="'.($this->config['background_image']).'" />';
			echo '</td><td>';
			echo $defaults['background_image'];
			echo '</td></tr>';
		echo '</table>';
		echo '<input type="hidden" name="cmd" value="saveconfig"/>';
		echo '<input type="submit" value="'.$langmessage['save'].'" class="gpsubmit" />';
		echo ' <input type="submit" name="cmd" value="'.$langmessage['cancel'].'" class="gpcancel" />';
		echo ' <input type="submit" name="cmd" value="'.$langmessage['restore_defaults'].'" class="gpcancel" />';
		echo '</form>';
	}
}
