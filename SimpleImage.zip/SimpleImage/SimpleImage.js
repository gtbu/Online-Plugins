/**
 * JS/jQuery for Typesetter CMS addon Simple Image - Runtime
 * Author: J. Krausz
 * Version 1.0
 */

$(function(){

  $(".Simple_Image_wrapper").each(function(){
    if( $(this).attr("data-enable-fullscreen") == "true" ){
      create_fullscreen_trigger($(this));
    }
  });

  $(".Simple_Image_wrapper").on("click", function(e){

    // check for using colobox
    if( $(this).attr("href") && $(this).attr("data-use-colorbox") == "true" ){

      var href = $(this).attr("href");

      // check if href points to an a file, prevent colorbox in case
      if( (/\.(pdf|docx?|xlsx?|pptx?|tif?f|gz|gzip|bzip|tar|tgz|zip|7z|rar|ods|odt|ogg|oga|psd|avi|wav|mov|mpe?g|mid|mp3|mp4|m4a|webm|ogg|oga|ogv|aif?f|flac|asf)$/i).test(href) ){
        return;
      }

      // check if href points to an an image (internal or external)
      if( (/\.(jpe?g|gif|png|apng|bmp|svg|svgz|webp)$/i).test(href) ){
        var cbOpts = $gp.cboxSettings();
        cbOpts.open = true;
        $(this).colorbox(cbOpts); // {photo:true}
        return false;
      }

      // prevent colorbox AJAXing internal links while logged In
      if( isadmin && href.indexOf("://") == -1 ){
        alert(
        "Loading internal links via AJAX in Colorbox is disabled while being logged-in. " 
        +  "\nTo see how internal links will actually look in Colorbox (without header and footer),"
        + "\n please log out first. The internal link will now be loaded into an iframe."
        );
      }

      // check if href is an internal link (w/o protocol) and we're not logged in
      if( href.indexOf("://") == -1 && !isadmin ){
        // tell Typesetter to only get the body content
        var cbOpts = $gp.cboxSettings();
        cbOpts.href = updateQuery(href,'gpreq','body');
        cbOpts.open = true;
        $(this).colorbox(cbOpts);
        return false;
      }

      // otherwise use an iframe
      var cbOpts = $gp.cboxSettings();
      cbOpts.iframe = true;
      cbOpts.fastIframe = false;
      cbOpts.width = "90%";
      cbOpts.height = "90%";
      cbOpts.open = true;
      $(this).colorbox(cbOpts);
      return false;
    }

  });

});


function updateQuery(uri, key, value){
  var re = new RegExp("([?|&])" + key + "=.*?(&|#|$)", "i");
  if( uri.match(re) ){
    return uri.replace(re, '$1' + key + "=" + value + '$2');
  }else{
    var hash =  '';
    if( uri.indexOf('#') !== -1 ){
      hash = uri.replace(/.*#/, '#');
      uri = uri.replace(/#.*/, '');
    }
    var separator = uri.indexOf('?') !== -1 ? "&" : "?";
    return uri + separator + key + "=" + value + hash;
  }
}


// CREATE FULLSCREEN TRIGGER
function create_fullscreen_trigger(obj) {
  var fullscreen_support = document.body.mozRequestFullScreen || document.body.webkitRequestFullScreen || document.body.requestFullScreen;
  // console.log('fullscreen_support', fullscreen_support);
  if( !fullscreen_support ){
    return false;
  }
  $('<div title="make fullscreen" class="fullscreen-trigger">Full Screen</div>')
  .on("click", function(e){
    e.stopPropagation();
    var elem = e.target.parentNode;
    if( $(elem).hasClass("is-fullscreen") ){
      $(elem).removeClass("is-fullscreen");
      $(this).attr("title", "make full screen");
      if( document.exitFullscreen ){
        document.exitFullscreen();
      }else if( document.msExitFullscreen ){
        document.msExitFullscreen();
      }else if( document.webkitCancelFullScreen ){
        document.webkitCancelFullScreen();
      }
    }else{
      $(elem).addClass("is-fullscreen");
      $(this).attr("title", "exit full screen");
      if( elem.requestFullscreen ){
        elem.requestFullscreen();
      }else if( elem.msRequestFullscreen ){
        elem.msRequestFullscreen();
      }else if( elem.webkitRequestFullscreen ){
        elem.webkitRequestFullscreen();
      }
    }
    return false;
  })
  .appendTo(obj);

  $(document).on("webkitfullscreenchange MSFullscreenChange fullscreenchange", function(e){
    if( !document.fullScreen && !document.webkitIsFullScreen ){
      $(".is-fullscreen")
        .removeClass("is-fullscreen")
        .find(".fullscreen-trigger")
        .attr("title", "make fullscreen");
    }
  });

}
