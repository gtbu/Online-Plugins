/**
 * JS/jQuery script for Typesetter CMS addon Simple Image - Editor Component
 * Author: J. Krausz
 * Version 1.0
 */

function gp_init_inline_edit(area_id, section_object) { 

  $gp.LoadStyle( SimpleImage.base + '/SimpleImage_edit.css' );
  gp_editing.editor_tools();

  gp_editor = {
    edit_div            : gp_editing.get_edit_area(area_id),
  
    save_path           : gp_editing.get_path(area_id),
    destroy             : function(){},
    checkDirty          : function(){ return gp_editor.isDirty; },
    resetDirty          : function(){},
    updateElement       : function(){},
    gp_saveData         : function(){},

    isDirty             : false,
    updateEditor        : function(){},
    selectUsingFinder   : function(){},

    imageSrc            : false,
    getImage            : function(){},
    selectImage         : function(){},
    setImage            : function(){},

    altText             : false,
    getAltText          : function(){},
    setAltText          : function(){},

    link                : false,
    getLink             : function(){},
    selectLink          : function(){},
    setLink             : function(){},

    width               : false,
    widthUnit           : false,
    getWidth            : function(){},
    setWidth            : function(){},

    align               : { h : false, v : false },
    alignClasses        : { left    : "simpleImage-align-left",
                            center  : "simpleImage-align-center",
                            right   : "simpleImage-align-right",
                            top     : "simpleImage-valign-top",
                            middle  : "simpleImage-valign-middle",
                            bottom  : "simpleImage-valign-bottom" },
    getAlign            : function(){},
    setAlign            : function(){},

    options             : { useColorbox : false, enableFullScreen : false },
    getOptions          : function(){},
    setOptions          : function(){},

    ui                  : {}

  }; /* gp_editor -- end */



  gp_editor.gp_saveData = function() {
     var save_clone = gp_editor.edit_div.clone();
     save_clone.find(".Simple_Image_wrapper").removeAttr("cboxElement is-fullscreen");
     save_clone.find(".gpclear, .fullscreen-trigger").remove();
     var content = save_clone.html();
     save_clone = null;
     gp_editor.isDirty = false;
     return '&gpcontent=' + encodeURIComponent(content);
  };



  gp_editor.selectUsingFinder = function(callback_fn) {
    gp_editor.FinderSelect = function(fileUrl) { 
      if (fileUrl != "") {
        callback_fn(fileUrl);
      }
      return true;
    };
    var finderPopUp = window.open(gpFinderUrl, 'gpFinder', 'menubar=no,width=960,height=450');
    if (window.focus) { finderPopUp.focus(); }
  };



  gp_editor.getAlign = function(){
    var iw = gp_editor.edit_div.find(".Simple_Image_wrapper");
    if( iw.hasClass("simpleImage-align-left") )     { gp_editor.align.h = "left"; }
    if( iw.hasClass("simpleImage-align-center") )   { gp_editor.align.h = "center"; }
    if( iw.hasClass("simpleImage-align-right") )    { gp_editor.align.h = "right"; }
    if( iw.hasClass("simpleImage-valign-top") )     { gp_editor.align.v = "top"; }
    if( iw.hasClass("simpleImage-valign-middle") )  { gp_editor.align.v = "middle"; }
    if( iw.hasClass("simpleImage-valign-bottom") )  { gp_editor.align.v = "bottom"; }
    $(".ts_SI_align-button").each( function(){
      if( $(this).attr("data-align-h") == gp_editor.align.h && $(this).attr("data-align-v") == gp_editor.align.v ){
        $(this).addClass("ts_SI_align-button-on");
        $("#ts_SI_alignment").text(gp_editor.align.h + "-" + gp_editor.align.v);
        return false;
      }
    });
  };



  gp_editor.setAlign = function(){
    gp_editor.align.v = $(".ts_SI_align-button-on").attr("data-align-v");
    gp_editor.align.h = $(".ts_SI_align-button-on").attr("data-align-h");
    gp_editor.edit_div.find(".Simple_Image_wrapper")
      .removeClass("simpleImage-align-left simpleImage-align-center simpleImage-align-right simpleImage-valign-top simpleImage-valign-middle simpleImage-valign-bottom")
    $("#ts_SI_alignment").text("");
    if( gp_editor.align.v && gp_editor.align.h ){
      var ac = gp_editor.alignClasses[gp_editor.align.v] + " " + gp_editor.alignClasses[gp_editor.align.h];
      gp_editor.edit_div.find(".Simple_Image_wrapper").addClass(ac);
      $("#ts_SI_alignment").text(gp_editor.align.h + "-" + gp_editor.align.v);
    }
    gp_editor.isDirty = true
  };



  gp_editor.getWidth = function(){
    gp_editor.width = gp_editor.edit_div.find(".Simple_Image_wrapper").attr("data-width");
    gp_editor.widthUnit = gp_editor.edit_div.find(".Simple_Image_wrapper").attr("data-width-unit") || "px";
  };



  gp_editor.setWidth = function(){
    var width = gp_editor.ui.width.val();
    switch( width ) {
      case "simpleImage-shrink2fit" :
      case "simpleImage-scale2fit" :
        gp_editor.ui.custom_width.closest("label").stop().slideUp(300, function(){
          gp_editor.ui.custom_width.closest("label").hide();
        });
        gp_editor.edit_div.find(".Simple_Image_wrapper")
          .removeClass("simpleImage-shrink2fit simpleImage-scale2fit simpleImage-autoWidth")
          .addClass(width);
          gp_editor.edit_div.find("img").removeAttr("style");
        gp_editor.width = width;
        break;
      case "custom" :
        gp_editor.ui.custom_width.closest("label").stop().show().slideDown(300);
        var custom_width = gp_editor.ui.custom_width.val() + gp_editor.ui.custom_width_unit.val();
        gp_editor.width = gp_editor.ui.custom_width.val();
        gp_editor.widthUnit = gp_editor.ui.custom_width_unit.val();
        gp_editor.edit_div.find(".Simple_Image_wrapper")
          .removeClass("simpleImage-shrink2fit simpleImage-scale2fit simpleImage-autoWidth")
        gp_editor.edit_div.find("img").attr("style", "width:" + custom_width ); //  + "!important;"
        break;
      case "simpleImage-autoWidth" :
      default :
        gp_editor.ui.custom_width.closest("label").stop().slideUp(300, function(){
          gp_editor.ui.custom_width.closest("label").hide();
        });
        gp_editor.edit_div.find(".Simple_Image_wrapper")
          .removeClass("simpleImage-shrink2fit simpleImage-scale2fit")
          .addClass("simpleImage-autoWidth");
        gp_editor.edit_div.find("img").removeAttr("style");
        break;
    }
    gp_editor.edit_div.find(".Simple_Image_wrapper").attr("data-width",  gp_editor.width);
    gp_editor.edit_div.find(".Simple_Image_wrapper").attr("data-width-unit", gp_editor.widthUnit);
    gp_editor.ui.custom_width_unit.attr("data-former-unit", gp_editor.widthUnit);
    gp_editor.isDirty = true;
  };



  gp_editor.convertWidth = function(){
    var formerUnit = gp_editor.ui.custom_width_unit.attr("data-former-unit") || "px";
    var newUnit = gp_editor.ui.custom_width_unit.val();
    switch (formerUnit+newUnit) {
      case "pxem":
        var multiplier = 0.0667;
        break;
      case "empx":
        var multiplier = 15;
        break;
      case "px%":
        var multiplier = 100 / gp_editor.edit_div.width();
        break;
      case "%px":
        var multiplier = gp_editor.edit_div.width() / 100;
        break;
      case "em%":
        var multiplier = 1500 / gp_editor.edit_div.width();
        break;
      case "%em":
        var multiplier = gp_editor.edit_div.width() / 1500;
        break;
    }
    gp_editor.ui.custom_width.val(Math.round(gp_editor.ui.custom_width.val() * multiplier));
    gp_editor.setWidth();
  };


  gp_editor.getOptions = function() {
    gp_editor.options.enableFullScreen = gp_editor.edit_div.find('.Simple_Image_wrapper').attr("data-enable-fullscreen") == "true";
    gp_editor.options.useColorbox =      gp_editor.edit_div.find('.Simple_Image_wrapper').attr("data-use-colorbox") == "true";
  };


  gp_editor.setOptions = function() {
    gp_editor.options.enableFullScreen =  gp_editor.ui.show_full_screen.prop("checked");
    gp_editor.options.useColorbox =       gp_editor.ui.use_colorbox.prop("checked");
    gp_editor.edit_div.find('.Simple_Image_wrapper')
      .attr("data-enable-fullscreen", gp_editor.options.enableFullScreen ? "true" : "false")
      .attr("data-use-colorbox", gp_editor.options.useColorbox ? "true" : "false");
    if( gp_editor.options.enableFullScreen ){
      create_fullscreen_trigger(gp_editor.edit_div.find(".Simple_Image_wrapper"));
    }else{
      gp_editor.edit_div.find(".fullscreen-trigger").remove();
    }
    gp_editor.isDirty = true;
  };


  gp_editor.getAltText = function(){
    gp_editor.altText = gp_editor.edit_div.find("img").attr("alt") || "";
  };


  gp_editor.setAltText = function(){
    gp_editor.altText = gp_editor.ui.alt_text.val();
    gp_editor.edit_div.find("a").attr("title", gp_editor.altText);
    gp_editor.edit_div.find("img").attr("alt", gp_editor.altText);
    gp_editor.isDirty = true;
  };


  gp_editor.generateAltText = function(force){
    if( !force && gp_editor.altText && gp_editor.altText != "") {
      return;
    }
    var autoAlt = 
      (!gp_editor.imageSrc || gp_editor.imageSrc == "") 
      ? "Image" 
      : gp_editor.imageSrc.substring(
          gp_editor.imageSrc.lastIndexOf("/") + 1, 
          gp_editor.imageSrc.lastIndexOf(".")
        ).split("_").join(" ");
     gp_editor.ui.alt_text.val(autoAlt);
     gp_editor.setAltText();
  };


  gp_editor.getLink = function(){
    gp_editor.link = gp_editor.edit_div.find(".Simple_Image_wrapper").attr("href") || "";
  };


  gp_editor.selectLink = function(){
    gp_editor.selectUsingFinder(gp_editor.setLink);
  };


  gp_editor.setLink = function(url){
    gp_editor.link = url;
    gp_editor.ui.link_url.val(url);
    if( gp_editor.link.trim() != "" ){
      if( gp_editor.link.indexOf("://") != -1 ) {
        gp_editor.edit_div.find(".Simple_Image_wrapper").attr("target", "_blank");
      }else{
        gp_editor.edit_div.find(".Simple_Image_wrapper").removeAttr("target");
        if( (/\.(jpe?g|gif|a?png|bmp|svgz?|webp)$/i).test(gp_editor.link) ){
          // if link points to an an (internal) image, activate colorBox option
          gp_editor.ui.use_colorbox.prop("checked", true).trigger("change");
        }
      }
      gp_editor.edit_div.find(".Simple_Image_wrapper").attr("href", gp_editor.link);
    }else{
      gp_editor.edit_div.find(".Simple_Image_wrapper").removeAttr("href");
    }
    gp_editor.isDirty = true;
  };


  gp_editor.getImage = function() {
    gp_editor.imageSrc = gp_editor.edit_div.find("img").attr("src") || "";
  };


  gp_editor.selectImage = function(){
    gp_editor.selectUsingFinder(gp_editor.setImage);
  };


  gp_editor.setImage = function(fileUrl){
    gp_editor.imageSrc = fileUrl;
    gp_editor.edit_div.find("img").prop("src", gp_editor.imageSrc);
    gp_editor.ui.img_preview_area.find("img").prop("src", gp_editor.imageSrc);
    gp_editor.generateAltText(false);
    gp_editor.isDirty = true;
  };


  /* ----------------------------- */
  /* --- GET DATA FROM CONTENT --- */
  /* ----------------------------- */
  gp_editor.getImage();
  gp_editor.getWidth();
  gp_editor.getLink();
  gp_editor.getAltText();
  gp_editor.getOptions();

  /* --- RENDER EDITOR AREA --- */
  gp_editor.ui.option_area = $('<div id="ts_SI_options" />').prependTo('#ckeditor_controls');

  /* IMAGE PREVIEW */
  gp_editor.ui.img_preview_area = $('<div id="ts_SI_preview_area"><img src="' + gp_editor.imageSrc + '"/></div>');
  gp_editor.ui.img_preview_area
    .appendTo(gp_editor.ui.option_area)
    .on('click', function() {
      gp_editor.selectImage(gp_editor.setImage);
    });


  /* SELECT IMAGE BUTTON */
  var label = $('<label class="ts_SI_editor_control" />');
  gp_editor.ui.select_image = $('<button>Select Image</button>');
  gp_editor.ui.select_image
    .appendTo(label)
    .on('click', function() {
      gp_editor.selectImage(gp_editor.setImage);
    });
  label.appendTo(gp_editor.ui.option_area);


  /* ALT TEXT */
  var label = $('<label title="Alternative Text" class="ts_SI_editor_control" />');
  gp_editor.ui.alt_text = $('<input id="ts_SI_alt" placeholder="Alternative Text" type="text" />');
  gp_editor.ui.alt_text
    .appendTo(label)
    .val(gp_editor.altText)
    .on('keyup change paste', gp_editor.setAltText);

  gp_editor.ui.link_button = $('<button id="ts_SI_generateAlt" title="Generate alt text from file name"><i class="fa fa-font"></i></button>');
  gp_editor.ui.link_button
    .appendTo(label)
    .on('click', function(){
      gp_editor.generateAltText(true);
    });

  label.appendTo(gp_editor.ui.option_area);


  /* LINK */
  var label = $('<label title="Link URL" class="ts_SI_editor_control" />');
  gp_editor.ui.link_url = $('<input id="ts_SI_link" placeholder="no link" type="text" />');
  gp_editor.ui.link_url
    .appendTo(label)
    .val(gp_editor.link)
    .on('keyup change paste', function(){
      gp_editor.setLink($(this).val());
    })
    .autocomplete({
      source    : gptitles,
      appendTo  : "#gp_admin_html",
      delay     : 100, 
      minLength : 0,
      select    : function(event,ui){
                    if( ui.item ){
                      $(this).val(encodeURI(ui.item[1]));
                      $(this).trigger("change");
                      event.stopPropagation();
                      return false;
                    }
                  }
    }).data("ui-autocomplete")._renderItem = function(ul,item) {
      return $("<li></li>")
        .data("ui-autocomplete-item", item[1])
        .append('<a>' + $gp.htmlchars(item[0]) + '<span>' + $gp.htmlchars(item[1])+'</span></a>')
        .appendTo(ul);
    };

  gp_editor.ui.link_button = $('<button id="ts_SI_selectLink" title="Select File"><i class="fa fa-file-o"></i></button>');
  gp_editor.ui.link_button
    .appendTo(label)
    .on('click', gp_editor.selectLink);

  label.appendTo(gp_editor.ui.option_area);


  /* WIDTH */
  if( gp_editor.width == parseFloat(gp_editor.width) ){
    var selectVal = "custom";
    var inputVal = gp_editor.width;
  }else{
    var selectVal = gp_editor.width;
    var inputVal = 192;
  }

  var label = $('<label title="Image Width" class="ts_SI_editor_control" />');
  gp_editor.ui.width = $('<select>'
    + '<option value="simpleImage-autoWidth">original width</option>'
    + '<option value="simpleImage-shrink2fit">shrink to fit</option>'
    + '<option value="simpleImage-scale2fit">scale to fit</option>'
    + '<option value="custom">custom width</option>'
    + '</select>');
  gp_editor.ui.width
    .appendTo(label)
    .val(selectVal)
    .on('change', gp_editor.setWidth);
  label.appendTo(gp_editor.ui.option_area);

  var display = gp_editor.width == "custom" ? "block" : "none";
  var label = $('<label style="display:' + display + ';" title="Custom Image Width" class="ts_SI_editor_control" />');
  gp_editor.ui.custom_width = $('<input id="ts_SI_cutom_width" placeholder="custom width" step="any" type="number"/>');
  gp_editor.ui.custom_width
    .val(inputVal)
    .appendTo(label)
    .on('keyup change paste', gp_editor.setWidth);
  gp_editor.ui.custom_width_unit = $('<select id="ts_SI_cutom_width_unit" data-former-unit="">'
    + '<option value="px">px</option>'
    + '<option value="em">em</option>'
    + '<option value="%">%</option>'
    + '</select>');
  gp_editor.ui.custom_width_unit
    .appendTo(label)
    .val(gp_editor.widthUnit)
    .on('change', gp_editor.convertWidth);
  label.appendTo(gp_editor.ui.option_area);


  /* ALIGNMENT */
  var label = $('<label class="ts_SI_editor_control">'
    + '<div style="float:right; width:36px; height:36px; margin:4px;">'
    + '<div title="top left" class="ts_SI_align-button" data-align-v="top" data-align-h="left"></div>'
    + '<div title="top center" class="ts_SI_align-button" data-align-v="top" data-align-h="center"></div>'
    + '<div title="top right" class="ts_SI_align-button" data-align-v="top" data-align-h="right"></div>'
    + '<div title="middle left" class="ts_SI_align-button" data-align-v="middle" data-align-h="left"></div>'
    + '<div title="middle center" class="ts_SI_align-button" data-align-v="middle" data-align-h="center"></div>'
    + '<div title="middle right" class="ts_SI_align-button" data-align-v="middle" data-align-h="right"></div>'
    + '<div title="bottom left" class="ts_SI_align-button" data-align-v="bottom" data-align-h="left"></div>'
    + '<div title="bottom center" class="ts_SI_align-button" data-align-v="bottom" data-align-h="center"></div>'
    + '<div title="bottom right" class="ts_SI_align-button" data-align-v="bottom" data-align-h="right"></div>'
    + '</div>'
    + '<div style="line-height:16px!important; padding-top:7px; margin-left:6px;">Alignment</div>'
    + '<div id="ts_SI_alignment" style="line-height:16px!important; margin-left:6px; font-style:italic!important;"></div>'
    + '</label>');
  label
    .appendTo(gp_editor.ui.option_area)
    .find(".ts_SI_align-button")
    .on("click", function(){
      $(this).toggleClass("ts_SI_align-button-on")
        .siblings().removeClass("ts_SI_align-button-on");
      gp_editor.setAlign();
    });


  /* COLORBOX OPTION */
  var label = $('<label class="ts_SI_editor_control"><span/> Open Link in Colorbox</label>');
  gp_editor.ui.use_colorbox = $('<input type="checkbox" />');
  gp_editor.ui.use_colorbox
    .prependTo(label)
    .prop("checked", gp_editor.options.useColorbox)
    .on('change', gp_editor.setOptions);
  label.appendTo(gp_editor.ui.option_area);


  /* FULLSCREEN OPTION */
  var label = $('<label class="ts_SI_editor_control"><span/> Show Full-Screen Button</label>');
  gp_editor.ui.show_full_screen = $('<input type="checkbox" />');
  gp_editor.ui.show_full_screen
    .prependTo(label)
    .prop("checked", gp_editor.options.enableFullScreen)
    .on('change', gp_editor.setOptions);
  label.appendTo(gp_editor.ui.option_area);


  gp_editor.setWidth();
  gp_editor.getAlign();
  loaded();

}
