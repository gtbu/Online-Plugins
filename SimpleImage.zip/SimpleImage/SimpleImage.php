<?php
/**
 * PHP class for Typesetter CMS plugin Simple Image
 * Author: J. Krausz
 * Version 1.0
 */

defined('is_running') or die('Not an entry point...');

class SimpleImage{

  static function GetHead(){
    global $page, $addonRelativeCode;

    $page->css_user[] = $addonRelativeCode . '/SimpleImage.css';
    $page->head_js[]  = $addonRelativeCode . '/SimpleImage.js';
    \gp\tool::AddColorBox();
  }



  static function SectionTypes($section_types){
    $section_types['Simple_Image'] = array();
    $section_types['Simple_Image']['label'] = 'Simple Image';

    return $section_types;
  }



  static function NewSections($links){
    global $addonRelativeCode;

    foreach( $links as $key => $section_type_arr ){
      if( $section_type_arr[0] == 'Simple_Image' ){
        $links[$key] = array('Simple_Image', $addonRelativeCode . '/icons/section.png');
      }
    }

    return $links;
  }



  static function DefaultContent($default_content, $type){
    global $addonRelativeCode;

    if( $type !== 'Simple_Image' ){
      return $default_content;
    }

    $newSection = array();
    $newSection['content']  = '<a class="Simple_Image_wrapper simpleImage-scale2fit" ';
    $newSection['content'] .=   'data-width="simpleImage-scale2fit" data-width-unit="px" ';
    $newSection['content'] .=   'data-use-colorbox="false" data-enable-fullscreen="false">';
    $newSection['content'] .=   '<img alt="" src="' . $addonRelativeCode . '/img/default_image.png" />';
    $newSection['content'] .= '</a>';

    $newSection['gp_label'] = 'Simple Image';
    $newSection['gp_color'] = '#b7b2aa';

    return $newSection;
  }



  static function SaveSection($return, $section, $type){
    global $page;

    if( $type == 'Simple_Image' ){
      $content =& $_POST['gpcontent'];
      $page->file_sections[$section]['content'] = $content;
      return true;
    }

    return $return;
  }



  static function InlineEdit_Scripts($scripts, $type){
    global $addonRelativeCode, $addonCodeFolder, $addonFolderName;

    if( $type !== 'Simple_Image' ){
      return $scripts;
    }

    // autocomplete
    echo \gp\tool\Editing::AutoCompleteValues(true);

    // addon JS Data Object/basepath
    $addonBasePath = (strpos($addonRelativeCode, 'addons/') > 0) ?
      '/addons/' . $addonFolderName :
      '/data/_addoncode/' . $addonFolderName;
    echo 'var SimpleImage = { base : "' . $addonBasePath . '" };';

    // scripts
    $scripts[] = $addonCodeFolder . '/SimpleImage_edit.js'; 

    return $scripts;
  }

}
