<?php /* UTF-8! ÄÖÜäöüß
######################################################################
PHP script for FullCalendar for gpEasy
Author: J. Krausz
Date: 2015-03-24
Version 1.0
######################################################################
*/
defined('is_running') or die('Not an entry point...');

class FullCalendar {

  function SectionTypes($section_types) {
    $section_types['fullcalendar_section'] = array();
    $section_types['fullcalendar_section']['label'] = 'FullCalendar';
    return $section_types;
  }


  function SectionToContent($section_data, $section_index) {
    if( $section_data['type'] != 'fullcalendar_section' ) {
      return $section_data;
    }
    global $page, $addonRelativeCode, $addonPathCode, $langmessage, $languages, $config, $ml_object; 

    // message("FullCalendar-section[" . $section_index . "], Data: " . showArray($section_data));


    // Load CSS and JS

    $page->head_js[] =   $addonRelativeCode . '/fullcalendar/lib/moment.min.js';
    $page->head_js[] =   $addonRelativeCode . '/fullcalendar/fullcalendar.min.js';
    $page->css_user[] =  $addonRelativeCode . '/loaders/loaders.css';

    // load colorbox if set for eventClick
    if ($section_data['eventClick'] == "colorbox") {
      common::LoadComponents('colorbox');
    }

    // load FullCalendar theme/skin
    $page->css_user[] = $addonRelativeCode . '/themes/fullcalendar.css'; // basis for all
    if ($section_data['FCtheme'] == "jQuery UI") {
      common::LoadComponents('ui-theme');
    } elseif ($section_data['FCtheme'] != "default") {
      // alternative skins partially override defaults from fullcalendar.css
      $page->css_user[] = $addonRelativeCode . '/themes/' . $section_data['FCtheme'] . '.css'; 
    }


    // only if language inheriting = on and lang is forced to user other than US english, 
    // start the following language logic: 
    // (otherwise don't load anything - use FC built-in/default)
    // if (array_key_exists("FClangInherit", $section_data) && $section_data['FClang'] != "en") {

      if (array_key_exists("FClangInherit", $section_data) && $section_data['FClangInherit']) { // if language is set to inherit from gpEasy
        // determine interface language or (if present) Multi Language Manager (gpEasy plugin) -> current page language
        $lang = $config["language"]; 
        if ($ml_object) { message(showArray($ml_object));
          $ml_list = $ml_object->GetList($page->gp_index);
          $page_lang = is_array($ml_list) && ($page_lang = array_search($page->gp_index,$ml_list)) !== false ? $page_lang : $lang;
        } else {
          $page_lang = $lang;
        }
        $FClang = $page_lang;
      } else { // use fallback language set in editor otherwise
        $FClang = $section_data['FClang'];
      }

      if ($FClang != "en") { // if FClang is not US english, try to load the lang.js file
        $FClang_file = $addonPathCode . '/fullcalendar/lang/' . $FClang . '.js';
        if (file_exists($FClang_file)) {
          $page->head_js[] =  $addonRelativeCode . '/fullcalendar/lang/' . $FClang . '.js';
        } else { // lang file does not exist. Report to admin. 
          if (common::LoggedIn()) {
            include $addonPathCode . '/languages.php';
            message('Sorry, FullCalendar currently doesn’t support the inherited language <i>' . $all_languages[$FClang] . '</i>.');
            message('FullCalendar will currently fall back to <i>' . $all_languages[$section_data['FClang']] . '</i>.');
            message('You may change the Fallback Language via FullCalendar Section -&gt; Edit -&gt; Internationalization.');
          }
          $FClang = $section_data['FClang']; 
          $page->head_js[] =  $addonRelativeCode . '/fullcalendar/lang/' . $FClang . '.js';
        }
      } else { // FClang == en, so we do not need to load any lang stuff
        $FClang = false;
      }
    //} 

    /* use google Calendar? */
    if ($section_data['use_gCal']) {
      $gcalJS = $addonRelativeCode . '/fullcalendar/gcal.min.js';
      if ( !array_search($gcalJS, $page->head_js) ) { // load gcal.min.js, if not already loaded
        $page->head_js[] = $gcalJS; 
      }
    }

    $JS_section_index = intval($section_index) - 1;

    $jQcode = '';

    /* loader Animation */
    if ($section_data['loaderAnim'] != 'none') {
      $jQcode .= "\n" . '$("#' . $section_data['uniqid'] . '").parent().find(".gp_fullcalendar_loader").addClass("loader-' . 
         $section_data['loaderAnim'] . '");' 
       . "\n";
    }

    // Build Config + init FullCalendar for this section

    $jQcode .= "\n" . '$("#' . $section_data['uniqid'] . '")';

    if ($section_data['FCtheme'] != "jQuery UI" && $section_data['FCtheme'] != "default") {
      $jQcode .= '.addClass("' . $section_data['FCtheme'] . '")'; // apply theme
    }

    // fc...
    $jQcode .= '.fullCalendar( {' . "\n";

    if ($section_data['FCtheme'] == "jQuery UI") {
      $jQcode .= ' theme : true , ' . "\n";
    };

    if ($FClang) {
      $jQcode .= ' lang : "' . $FClang . '", ' . "\n";
    };

    if ($section_data['firstDay'] != "lang") {
      $jQcode .= ' firstDay : ' . intval($section_data['firstDay']) . ' , ' . "\n";
    };

    if (array_key_exists("FCheader", $section_data)) {
      if (!array_key_exists('left', $section_data['FCheader'])   || $section_data['FCheader']['left'] == "")   { $section_data['FCheader']['left'] =   false; }
      if (!array_key_exists('center', $section_data['FCheader']) || $section_data['FCheader']['center'] == "") { $section_data['FCheader']['center'] = false; }
      if (!array_key_exists('right', $section_data['FCheader'])  || $section_data['FCheader']['right'] == "")  { $section_data['FCheader']['right'] =  false; }
      $jQcode .= ' header : ' 
        . JSON_encode($section_data['FCheader'], JSON_FORCE_OBJECT)
        . ', ' . "\n";

    };

    if (array_key_exists("defaultView", $section_data)) {
      $jQcode .= ' defaultView : "' . $section_data['defaultView'] . '", ' . "\n";
    };

    if (array_key_exists("use_gCal", $section_data) && $section_data['use_gCal'] == "true") {
      $jQcode .= '  googleCalendarApiKey : "' . $section_data['gCalApiKey'] . '", ' . "\n";
      $jQcode .= '  events : { ' . "\n";
      $jQcode .= '    googleCalendarId : "' . $section_data['gCalId'] . '", ' . "\n";
      $jQcode .= '    className : "fc-gcal-event", ' . "\n";
      $jQcode .= ($section_data['evTxtColor'] != '')    ? '    textColor : "' . $section_data['evTxtColor'] . '", ' . "\n" : '' ;
      $jQcode .= ($section_data['evBgColor'] != '')     ? '    backgroundColor : "' . $section_data['evBgColor'] . '", ' . "\n" : '' ;
      $jQcode .= ($section_data['evBorderColor'] != '') ? '    borderColor : "' . $section_data['evBorderColor'] . '" ' . "\n" : '' ;

      $jQcode .= '  }, ' . "\n";
    };

    if (array_key_exists("eventClick", $section_data)) {
      $jQcode .= '  eventClick : function(e) { ' . "\n    ";

        switch ($section_data['eventClick']) {

         case "colorbox" : 
          $jQcode .= '$.colorbox({ href : e.url, title : "google Calendar Event" }); return false; ' . "\n";
          break;

         case "window" : 
          $jQcode .= 'window.open(e.url, "gcalevent", "width=700,height=600"); return false; ' . "\n";
          break;

         case "nothing" : 
           $jQcode .= 'return false; ' . "\n";
           break;

         default : 
           $jQcode .= 'return false;' . "\n";
           break;
        }

      $jQcode .= '  }, ' . "\n";
    };

    $jQcode .= '  loading : function(bool) { ' . "\n";
    $jQcode .= '   $("#' . $section_data['uniqid'] . '").parent().find(".gp_fullcalendar_loader").toggle(bool); ' . "\n";
    $jQcode .= '  }' . "\n";


    if (array_key_exists("additionalOptions", $section_data) && trim($section_data["additionalOptions"]) != "") {
      $jQcode .= ',' . trim($section_data["additionalOptions"], ",;") . "\n"; 
    }

    $jQcode .= '});' . "\n"; 


    $page->jQueryCode .= $jQcode;

    return $section_data;

  }


  function DefaultContent($default_content, $type) {
    if( $type != 'fullcalendar_section' ) {
      return $default_content;
    } 

    $section_uniqid = "fc-" . crc32(uniqid("",true));

    $newSectionHTML   = '<div class="gp_fullcalendar_area" id="' . $section_uniqid . '"></div>';
    $newSectionHTML  .= '<div class="gp_fullcalendar_loader"></div>';
    $newSectionHTML  .= '<noscript><h3>Sorry, but this calendar will not work without JavaScript!</h3></noscript>';

    $section = array();

    $section['uniqid'] =              $section_uniqid;
    $section['content'] =             $newSectionHTML;

    $section['use_gCal'] =            true;
    $section['gCalApiKey'] =          '';

    $section['evTxtColor'] =          '#ffffff';
    $section['evBorderColor'] =       '#3a87ad';
    $section['evBgColor'] =           '#3a87ad';

    $section['gCalId'] =              '';

    $section['FCtheme'] =             'default';
    $section['defaultView'] =         'month';
    $section['FCheader']  =           array( "left"   => "prev,next today", "center" => "title", "right"  => "month,agendaWeek,agendaDay" );
    $section['loaderAnim'] =          'none';

    $section['eventClick']  =         'window';

    $section['FClangInherit']  =      true;
    $section['FClang']  =             'en';
    $section['firstDay'] =            'lang';

    $section['additionalOptions']  = '/* ############# SOME EXAMPLES TO UNCOMMENT ############# */' . "\n" .
                                     '/* ## YOU CAN ALSO OVERRIDE ABOVE DEFINED OPTIONS HERE ## */' . "\n" .
                                     " \n" .
                                     '/* weekends : false, */' . "\n" .
                                     '/* weekNumbers : true, */' . "\n" .
                                     '/* aspectRatio : 2, */' . "\n" .
                                     '/* businessHours : {' . "\n" .
                                     '    start: "9:00", ' . "\n" .
                                     '    end: "17:00", ' . "\n" .
                                     '    dow: [ 1, 2, 3, 4, 5 ] ' . "\n" .
                                     '  }, */' . "\n" .
                                     '/* scrollTime : "08:00:00", */' . "\n" .
                                     '/* minTime    : "06:00:00", */' . "\n" .
                                     '/* maxTime    : "20:00:00"  */' . "\n" .
                                     "\n";

    return $section;
  }


  function SaveSection($return,$section,$type){
    if( $type != 'fullcalendar_section' ) {
      return $return;
    }

    // message(showArray($_POST));

    global $page;
    $page->file_sections[$section]['uniqid '] =       $_POST['uniqid'];
    $page->file_sections[$section]['content'] =       $_POST['gpcontent'];
    $page->file_sections[$section]['full_content'] =  true;

    $page->file_sections[$section]['use_gCal'] =      (isset($_POST['use_gcal']));
    $page->file_sections[$section]['gCalApiKey'] =    $_POST['gcal_api_key'] ;
    $page->file_sections[$section]['gCalId'] =        $_POST['gcal_id'] ;

    $page->file_sections[$section]['evTxtColor'] =    $_POST['event_text_color'] ;
    $page->file_sections[$section]['evBorderColor'] = $_POST['event_border_color'] ;
    $page->file_sections[$section]['evBgColor'] =     $_POST['event_bg_color'] ;

    $page->file_sections[$section]['FCtheme'] =       $_POST['fc_theme'] ;
    $page->file_sections[$section]['defaultView'] =   $_POST['default_view'] ;
    $page->file_sections[$section]['FCheader'] =      $_POST['fc_header'] ; // = array
    $page->file_sections[$section]['loaderAnim'] =    $_POST['loader_anim'] ; // = array

    $page->file_sections[$section]['eventClick'] =    $_POST['event_click'] ;

    $page->file_sections[$section]['FClangInherit'] = (isset($_POST['fc_lang_inherit']));
    $page->file_sections[$section]['FClang'] =        $_POST['fc_lang'] ;
    $page->file_sections[$section]['firstDay'] =      $_POST['first_day'] ;

    $page->file_sections[$section]['additionalOptions'] = $_POST['additional_options'] ;

    return true;
  }


  function GenerateContent_Admin() {
    global $addonFolderName, $addonRelativeCode, $page; //, $index, $langmessage;
    static $done = false;

    if( $done || !common::LoggedIn() ) return;

    common::LoadComponents('accordion');

    $page->head_js[] =   $addonRelativeCode . '/codemirror5/lib/codemirror.min.js';
    $page->css_admin[] = $addonRelativeCode . '/codemirror5/lib/codemirror.gp_prefixed.css';
    $page->head_js[] =   $addonRelativeCode . '/codemirror5/mode/javascript/javascript.js';
    $page->head_js[] =   $addonRelativeCode . '/codemirror5/addon/edit/matchbrackets.js';
    $page->css_admin[] = $addonRelativeCode . '/minicolors/jquery.minicolors.css';
    $page->head_js[] =   $addonRelativeCode . '/minicolors/jquery.minicolors.min.js';

    $page->head_js[] =   $addonRelativeCode . '/edit.js';

    $addonBasePath = ($addonFolderName == "FullCalendar") ? '/addons/FullCalendar' : '/data/_addoncode/' . $addonFolderName;
    $page->head_script .= "\nvar FULLCALENDAR_BASE = '" . $addonBasePath . "';\n";

    $done = true;
  }


} // class end
?>