/* UTF-8! ÄÖÜäöüß
######################################################################
JS/jQuery script for FullCalendar for gpEasy - Editor Component
Author: J. Krausz
Date: 2015-03-24
Version 1.0
######################################################################
*/

function gp_init_inline_edit(area_id,section_object) { 

  $gp.LoadStyle( FULLCALENDAR_BASE + '/edit.css' );

  loaded();

  gp_editing.editor_tools();
  edit_div = gp_editing.get_edit_area(area_id);

  gp_editor = {
    save_path          : gp_editing.get_path(area_id),
    destroy            : function() {},
    checkDirty         : function() { return false; },
    resetDirty         : function() {},
    updateElement      : function() {},
    optionsChanged     : false,
    gp_saveData        : function() {
                            var args = {};
                            var fc_uniqid = section_object.uniqid ? section_object.uniqid : "fc-" + ((new Date().getTime()).toString(16));
                            var options = $('#gp_FC_options').find('input,select,textarea').serialize();
                            options += "&uniqid=%23" + fc_uniqid + "%23";
                            var content = '<div class="gp_fullcalendar_area" id="' + fc_uniqid + '"></div>' + 
                            '<div class="gp_fullcalendar_loader"></div>' + 
                            '<noscript><h3>Sorry, but this calendar will not work without JavaScript!</h3></noscript>';
                            gp_editor.optionsChanged = false;
                            return $.param(args)+'&'+options+'&gpcontent=' + encodeURIComponent(content);
    },

    use_gCal              : function() { gp_editor.optionsChanged = true; checkMessages(); },
    gCalApiKey            : function() { gp_editor.optionsChanged = true; checkMessages(); },
    gCalId                : function() { gp_editor.optionsChanged = true; checkMessages(); },

    evTxtColor            : function(hexcol) { gp_editor.optionsChanged = true; edit_div.find(".fc-gcal-event").css({color:hexcol}); },
    evBgColor             : function(hexcol) { gp_editor.optionsChanged = true; edit_div.find(".fc-gcal-event").css({backgroundColor:hexcol} ); },
    evBorderColor         : function(hexcol) { gp_editor.optionsChanged = true; edit_div.find(".fc-gcal-event").css({borderColor:hexcol}); },

    FCtheme               : function(e) { 
                              gp_editor.optionsChanged = true; 
                              changeFCtheme( $(e.target).val() ); 
                            },

    defaultView           : function(e) { 
                              gp_editor.optionsChanged = true; 
                              edit_div.find(".gp_fullcalendar_area").fullCalendar('changeView', $(e.target).val() ); 
                            },

    FCheader              : {
          left   : function() { 
                                gp_editor.optionsChanged = true; 
                                option_messages.find("#fc-setHeader").slideToggleBool(true); 
                                /* changeHeader(edit_div.find(".gp_fullcalendar_area"); */ 
                              },
          center : function() { 
                                gp_editor.optionsChanged = true; 
                                option_messages.find("#fc-setHeader").slideToggleBool(true);
                                /* changeHeader(edit_div.find(".gp_fullcalendar_area"); */ 
                              },
          right  : function() { 
                                gp_editor.optionsChanged = true; 
                                option_messages.find("#fc-setHeader").slideToggleBool(true);
                                /* changeHeader(edit_div.find(".gp_fullcalendar_area"); */ 
                              },
    },

    loaderAnim            : function(e) { 
                              gp_editor.optionsChanged = true;
                              previewLoader( edit_div.find(".gp_fullcalendar_loader"), $(e.target).val() ); 
                            },

    eventClick            : function() { 
                              gp_editor.optionsChanged = true;
                              checkMessages(); 
                            },

    FClangInherit         : function() { 
                              gp_editor.optionsChanged = true; 
                              setFClangEditorCaption();
                            },

    FClang                : function() { gp_editor.optionsChanged = true; },
    firstDay              : function() { gp_editor.optionsChanged = true; },

    additionalOptions     : function(e) { 
                              e.preventDefault();
                              gpabox_AdditionalOptions();
                            }

  } // gpeditor --end

    $(window).bind("beforeunload", function() {
      if (gp_editor.optionsChanged) {
        return "Warning: There are unsaved changes that will be lost. Proceed anyway?"; // most browsers will show their own msg here
      }
    });


  // console.log("Section_object:" + JSON.stringify(section_object));

  var option_area = $('<div id="gp_FC_options"/>').prependTo('#ckeditor_controls');
  
  var options_accordion = $(
  '<div id="options_accordion">' +
  '<h5 class="nomargin">google Calendar</h5><div id="options_gcal"/>' + 
  '<h5 class="nomargin">Appearance</h5><div id="options_appearance"/>' + 
  '<h5 class="nomargin">Behavior</h5><div id="options_behavior"/>' +
  '<h5 class="nomargin">Internationalization</h5><div id="options_i8n"/>' + 
  '<h5 class="nomargin">Advanced Configuration</h5><div id="options_advanced"/>' + 
  '</div>'
  );

  var option_messages = $(
  '<div id="option_messages">' +
  '<div class="notice" id="gcal-jQUI-theme">Activating/deactivating the jQuery UI theme requires reloading. <br/>Please click <span style="font-style:normal; white-space:nowrap;">[ Save &amp; Close ]</span>.</div>' + 
  '<div class="notice" id="fc-setHeader">Currently the header view cannot change dynamically. Please click <span style="font-style:normal; white-space:nowrap;">[ Save &amp; Close ]</span>.</div>' + 
  '<div class="notice" id="gcal-tut">FullCalendar developers provide a nice tutorial on ' + 
  '<a target="_blank" href="http://fullcalendar.io/docs/google_calendar">how to generate a public google Calendar</a>.</div>' + 
  '<div class="warning" id="gcal-off">Currently the plugin only supports google Calendar as backend and event source!</div>' + 
  '<div class="error" id="gcal-empty-apikey">please enter your google Calendar API key!</div>' + 
  '<div class="error" id="gcal-empty-id">please enter your google Calendar ID!</div>' + 
  '<div class="warning" id="gcal-colorbox">colorbox cannot show google Calendar events due to google’s Cross-Origin Resource Sharing (CORS) restriction.</div>' + 
  '</div>'
  ).appendTo(option_area);
  
  option_messages.find(".notice, .warning, .error").each( function() {
    $('<div class="dismiss"/>')
      .on("click", function() { 
        $(this).parent().slideToggleBool(false); 
      }
    ).appendTo($(this));
  });


  /* google Calendar */
  if( gp_editor.use_gCal ) {
    gplang.use_gCal = 'Use google Calendar';
    $('<div class="full_width"><input class="ck_input" type="checkbox" name="use_gcal" value="true" /> ' + gplang.use_gCal + '</div>')
      .appendTo( options_accordion.find("#options_gcal") )
      .find('input')
      .prop('checked', section_object.use_gCal)
      .on('click change', gp_editor.use_gCal);
  }
  
  if( gp_editor.gCalApiKey ){
    gplang.gCalApiKey = 'google Calendar API Key';
    $('<div class="full_width">' + gplang.gCalApiKey + 
      ' <input class="ck_input" type="text" name="gcal_api_key" ' + 
      'placeholder="XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_XX"/></div>')
      .appendTo( options_accordion.find("#options_gcal") )
      .find('input')
      .val(section_object.gCalApiKey)
      .on('keyup paste change', gp_editor.gCalApiKey) 
      ;
  }

  if( gp_editor.gCalId ){
    gplang.gCalId = 'google Calendar Id';
    $('<div class="full_width">' + gplang.gCalId + 
    ' <input class="ck_input" type="text" name="gcal_id" placeholder="your.google@calendar.id"/></div>')
      .appendTo( options_accordion.find("#options_gcal") )
      .find('input')
      .val(section_object.gCalId)
      .on('keyup paste change', gp_editor.gCalId )
      ;
  }

  $('<div class="full_width">google Calender Event Colors</div>').appendTo( options_accordion.find("#options_gcal") );

  if( gp_editor.evTxtColor ){
    gplang.evTxtColor = 'Text Color';
    $('<div class="third_width">' + gplang.evTxtColor + 
    ' <input class="ck_input" type="text" name="event_text_color" style="width:56px;"/></div>')
      .appendTo( options_accordion.find("#options_gcal") )
      .find('input')
      .val(section_object.evTxtColor)
      //.on('keyup paste change', gp_editor.evTxtColor )
      .minicolors( { letterCase : "lowercase", change : gp_editor.evTxtColor } )
      ;
  }

  if( gp_editor.evBorderColor ){
    gplang.evBorderColor = 'Border Color';
    $('<div class="third_width">' + gplang.evBorderColor + 
    ' <input class="ck_input" type="text" name="event_border_color" style="width:56px;"/></div>')
      .appendTo( options_accordion.find("#options_gcal") )
      .find('input')
      .val(section_object.evBorderColor)
      //.on('keyup paste change', gp_editor.evBorderColor ) 
      .minicolors( { letterCase : "lowercase", change : gp_editor.evBorderColor } )
      ;
  }

  if( gp_editor.evBgColor ){
    gplang.evBgColor = 'Backgr. Color';
    $('<div class="third_width">' + gplang.evBgColor + 
    ' <input class="ck_input" type="text" ' + 
    'name="event_bg_color" style="width:56px;"/></div>')
      .appendTo( options_accordion.find("#options_gcal") )
      .find('input')
      .val(section_object.evBgColor)
      //.on('keyup paste change', gp_editor.evBgColor ) 
      .minicolors( { letterCase : "lowercase" , change : gp_editor.evBgColor } )
      ;
  }


  /* Calendar Appearance */
  if( gp_editor.FCtheme ){
    gplang.FCtheme = 'FullCalendar Theme';
    $('<div class="full_width">' + gplang.FCtheme + 
      ' <select class="ck_select" name="fc_theme">' + 
      '<option value="default">default</option>' + 
      '<option value="bootswatch-flatly">bootswatch-flatly</option>' + 
      '<option value="bootswatch-slate">bootswatch-slate</option>' + 
      '<option value="midnight">midnight</option>' + 
      '<option value="jQuery UI">jQuery UI</option>' + 
      '</select></div>'
      )
      .appendTo( options_accordion.find("#options_appearance") )
      .find('select')
      .val(section_object.FCtheme)
      .on('change', gp_editor.FCtheme ) 
      ;
  }

  if( gp_editor.defaultView ){
    gplang.defaultView = 'Default View';
    $('<div class="full_width">' + gplang.defaultView + 
      ' <select class="ck_select" name="default_view">' + 
      '<option value="month">month</option>' + 
      '<option value="agendaWeek">agendaWeek</option>' + 
      '<option value="agendaDay">agendaDay</option>' + 
      '<option value="basicWeek">basicWeek</option>' + 
      '<option value="basicDay">basicDay</option>' + 
      '</select></div>'
      )
      .appendTo( options_accordion.find("#options_appearance") )
      .find('select')
      .val(section_object.defaultView)
      .on('change', gp_editor.defaultView )
      ;
  }

  if( gp_editor.FCheader ) {

    gplang.FCheaderLeft = 'Header Left';
    gplang.FCheaderCenter = 'Header Center';
    gplang.FCheaderRight = 'Header Right';
    var FCheaderWrapper = $('<div class="full_width"/>');

    var FCheaderLeft =  $('<div class="third_width">' + gplang.FCheaderLeft + 
    ' <select class="ck_select" name="fc_header[left]">' + 
      '<option value="prev,next today">prev,next today</option>' + 
      '<option value="prev,today,next">prev,today,next</option>' + 
      '<option value="title">title</option>' + 
      '<option value="month,agendaWeek,agendaDay">month,agendaWeek,agendaDay</option>' + 
      '<option value="month,basicWeek,basicDay">month,basicWeek,basicDay</option>' +
      '<option value="">empty</option>' +
      '</select></div>'
      )
      .appendTo(FCheaderWrapper)
      .find('select')
      .val(section_object.FCheader.left)
      .on('change', gp_editor.FCheader.left ) 
      ;

    var FCheaderCenter =  $('<div class="third_width">' + gplang.FCheaderCenter + 
      ' <select class="ck_select" name="fc_header[center]">' + 
      '<option value="title">title</option>' + 
      '<option value="prev,next today">prev,next today</option>' + 
      '<option value="prev,today,next">prev,today,next</option>' + 
      '<option value="month,agendaWeek,agendaDay">month,agendaWeek,agendaDay</option>' + 
      '<option value="month,basicWeek,basicDay">month,basicWeek,basicDay</option>' +
      '<option value="">empty</option>' +
      '</select></div>'
      )
      .appendTo(FCheaderWrapper)
      .find('select')
      .val(section_object.FCheader.center)
      .on('change', gp_editor.FCheader.center)
      ;

    var FCheaderRight =  $('<div class="third_width">' + gplang.FCheaderRight + 
    ' <select class="ck_select" name="fc_header[right]">' + 
      '<option value="title">title</option>' + 
      '<option value="prev,next today">prev,next today</option>' + 
      '<option value="prev,today,next">prev,today,next</option>' + 
      '<option value="month,agendaWeek,agendaDay">month,agendaWeek,agendaDay</option>' + 
      '<option value="month,basicWeek,basicDay">month,basicWeek,basicDay</option>' +
      '<option value="">empty</option>' +
      '</select></div>'
      )
      .appendTo(FCheaderWrapper)
      .find('select')
      .val(section_object.FCheader.right)
      .on('change', gp_editor.FCheader.right )
      ;

    FCheaderWrapper.appendTo( options_accordion.find("#options_appearance") );
  } // if header end

  if( gp_editor.loaderAnim ){
    gplang.loaderAnim = 'Show Animated Event Loader';
    $('<div class="full_width">' + 
      '<div class="twothird_width">' + gplang.loaderAnim + '</div>' +
      '<div class="third_width">' + 
      '<select class="ck_select" name="loader_anim">' + 
      '<option value="none">none</option>' +       
      '<option value="spinner-light1">spinner light 1</option>' + 
      '<option value="spinner-light2">spinner light 2</option>' + 
      '<option value="spinner-dark1">spinner dark 1</option>' + 
      '<option value="spinner-dark2">spinner dark 2</option>' + 
      '<option value="bar-light">bar light</option>' + 
      '<option value="bar-dark1">bar dark 1</option>' + 
      '<option value="bar-dark2">bar dark 2</option>' + 
      '</select>' + 
      '</div>' + 
      '</div>'
      )
      .appendTo( options_accordion.find("#options_appearance") )
      .find('select')
      .val(section_object.loaderAnim)
      .on('change', gp_editor.loaderAnim )
      ;
  }


  /* Calendar Behavior */
  if( gp_editor.eventClick ){
    gplang.eventClick = 'On Event Click';
    $('<div class="full_width">' + gplang.eventClick + 
      ' <select class="ck_select" name="event_click">' + 
      '<option value="window">open in new window (popup)</option>' + 
      '<option value="colorbox">open in colorbox</option>' + 
      '<option value="nothing">do nothing</option>' + 
      '</select>' + 
      '</div>'
      )
      .appendTo( options_accordion.find("#options_behavior") )
      .find('select')
      .val(section_object.eventClick)
      .on('change', gp_editor.eventClick ) 
      ;
  }


  /* Internationalization */

  if( gp_editor.FClangInherit ) {
    gplang.FClangInherit = 'try to inherit language from gpEasy <br\/>(or Multi-Language Manager)';
    $('<div class="full_width">' + 
      '<input class="ck_input" type="checkbox" style="float:left; margin:0 0.6em 1em 0;" ' + 
      'name="fc_lang_inherit" value="true" />' + gplang.FClangInherit + '</div>')
      .appendTo( options_accordion.find("#options_i8n") )
      .find('input')
      .prop('checked', section_object.FClangInherit)
      .on('click', gp_editor.FClangInherit ) 
      ;
  }
  
  if( gp_editor.FClang ){
    gplang.FClang = 'Fallback Language';
    $('<div class="full_width"><span id="FClang_caption">' + gplang.FClang + '</span>' +
      ' <select class="ck_select" name="fc_lang">' + 
      '<option value="ar">Arabic</option>' + 
      '<option value="ar-ma">Arabic (Morocco)</option>' + 
      '<option value="ar-sa">Arabic (Saudi Arabia)</option>' + 
      '<option value="ar-tn">Arabic (Tunisia)</option>' + 
      '<option value="bg">Bulgarian</option>' + 
      '<option value="ca">Catalan</option>' + 
      '<option value="zh-cn">Chinese (China)</option>' + 
      '<option value="zh-tw">Chinese (Taiwan)</option>' + 
      '<option value="hr">Croatian</option>' + 
      '<option value="cs">Czech</option>' + 
      '<option value="da">Danish</option>' + 
      '<option value="nl">Dutch</option>' + 
      '<option value="en">English (default/US)</option>' + 
      '<option value="en-au">English (Australia)</option>' + 
      '<option value="en-ca">English (Canada)</option>' + 
      '<option value="en-gb">English (United Kingdom)</option>' + 
      '<option value="fi">Finnish</option>' + 
      '<option value="fr">French</option>' + 
      '<option value="fr-ca">French (Canada)</option>' + 
      '<option value="de">German</option>' + 
      '<option value="de-at">German (Austria)</option>' + 
      '<option value="el">Greek</option>' + 
      '<option value="he">Hebrew</option>' + 
      '<option value="hi">Hindi</option>' + 
      '<option value="hu">Hungarian</option>' + 
      '<option value="is">Icelandic</option>' + 
      '<option value="id">Indonesian</option>' + 
      '<option value="it">Italian</option>' + 
      '<option value="ja">Japanese</option>' + 
      '<option value="ko">Korean</option>' + 
      '<option value="lv">Latvian</option>' + 
      '<option value="lt">Lithuanian</option>' + 
      '<option value="nb">Norwegian</option>' + 
      '<option value="fa">Persian</option>' + 
      '<option value="pl">Polish</option>' + 
      '<option value="pt">Portuguese</option>' + 
      '<option value="pt-br">Portuguese (Brazil)</option>' + 
      '<option value="ro">Romanian</option>' + 
      '<option value="ru">Russian</option>' + 
      '<option value="sr">Serbian</option>' + 
      '<option value="sr-cyr">Serbian (Cyrillic)</option>' + 
      '<option value="sk">Slovak</option>' + 
      '<option value="sl">Slovenian</option>' + 
      '<option value="es">Spanish</option>' + 
      '<option value="sv">Swedish</option>' + 
      '<option value="th">Thai</option>' + 
      '<option value="tr">Turkish</option>' + 
      '<option value="uk">Ukrainian</option>' + 
      '<option value="vi">Vietnamese</option>' + 
      '</select>' + 
      '</div>'
      )
      .appendTo( options_accordion.find("#options_i8n") )
      .find('select')
      .val(section_object.FClang)
      .on('change', gp_editor.FClang )
      ;
  }

  if( gp_editor.firstDay ){
    gplang.firstDay = 'Week starts with';
    $('<div class="full_width">' + gplang.firstDay + 
      ' <select class="ck_select" name="first_day">' + 
      '<option value="lang">use language default</option>' + 
      '<option value="0">Sunday</option>' + 
      '<option value="1">Monday</option>' + 
      '<option value="2">Tuesday</option>' + 
      '<option value="3">Wednesday</option>' + 
      '<option value="4">Thursday</option>' + 
      '<option value="5">Friday</option>' + 
      '<option value="6">Saturday</option>' + 
      '</select>' + 
      '</div>'
      )
      .appendTo( options_accordion.find("#options_i8n") )
      .find('select')
      .val(section_object.firstDay)
      .on('change', gp_editor.firstDay )
      ;
  }

  /* Advanced Config */

  if( gp_editor.additionalOptions ){
    gplang.additionalOptions = 'Edit Additional Options';
    $('<div class="full_width">' + 
      '<textarea style="display:none;" name="additional_options">' + 
      section_object.additionalOptions + 
      '</textarea>' + 
      '<a class="gpbutton" style="width:100%; text-align:center;">' + 
        gplang.additionalOptions + 
      '</a>' + 
      '</div>')
      .appendTo( options_accordion.find("#options_advanced") )
      .find('a')
      .on('click', gp_editor.additionalOptions )
      ;
  }


  /* ########## Initialize Options Accordion (jQuery UI) ########### */
  options_accordion.appendTo(option_area).accordion({ 
    header: "h5.nomargin",
    collapsible : true,
    heightStyle : "content" 
  });

  setTimeout( function() { 
      checkMessages();
      setFClangEditorCaption();
    }, 1000
  );


  function checkMessages() {  
    option_messages.find("#gcal-tut").slideToggleBool( 
      option_area.find("input[name='use_gcal']").prop('checked') 
        && option_area.find("input[name='gcal_api_key']").val().length < 1 
        && option_area.find("input[name='gcal_id']").val().length < 1
    );
    option_messages.find("#gcal-colorbox").slideToggleBool( 
      option_area.find("input[name='use_gcal']").prop('checked') && option_area.find("select[name='event_click']").val() == "colorbox"
    );
    option_messages.find("#gcal-off").slideToggleBool(  
      option_area.find("input[name='use_gcal']").prop('checked') == false
    );
    option_messages.find("#gcal-empty-id").slideToggleBool( 
      option_area.find("input[name='use_gcal']").prop('checked') && option_area.find("input[name='gcal_id']").val().length < 1
    );
    option_messages.find("#gcal-empty-apikey").slideToggleBool( 
      option_area.find("input[name='use_gcal']").prop('checked') && option_area.find("input[name='gcal_api_key']").val().length < 1
    );
  }

  function gpabox_AdditionalOptions() {
    var confData = options_accordion.find("textarea[name='additional_options']").val();
    //console.log("Type:" + typeof(confData) );
    //console.log("ConfData:" + confData);
    $gp.AdminBoxC( 
      $('<form>' + 
          '<div class="inline_box">' + 
            '<h3>Additional Configuration Options ' +
            '<a style="float:right;" href="http://fullcalendar.io/docs" target="_blank">» FullCalendar Documentation</a></h3>' +
            '<br style="clear:both;"/>' +
            '<textarea id="FC_advancedConfig">' + confData + '</textarea>' + 
            '<p style="text-align:right;">' + 
              '<input class="gpsubmit" type="submit" value="' + gplang.up + '"> ' + 
              '<input class="admin_box_close gpcancel" type="submit" value="' + gplang.ca + '">' + 
            '</p>' + 
          '</div>' +
        '</form>'
       )
      .on("submit", function(e) {
          e.preventDefault();
          gp_editor.optionsChanged = true; 
          var newConf = FC_CodeMirror.getValue();
          options_accordion.find("textarea[name='additional_options']").val(newConf); 
          FC_CodeMirror.toTextArea();
          $gp.CloseAdminBox();
        }
      )
    );
    var FC_CodeMirror = CodeMirror.fromTextArea( 
      document.getElementById("FC_advancedConfig"), 
      { 
        mode : { name: "javascript" },
        matchBrackets : true,
        lineNumbers : true,
        lineWrapping: true,
        showCursorWhenSelecting : true,
        autofocus : true,
        dragDrop : false
       }
    ); 
  } // /gpabox_AdditionalOptions -- end


  function setFClangEditorCaption() {
    if ( options_accordion.find('input[name="fc_lang_inherit"]').prop('checked') ) {
      options_accordion.find("#FClang_caption").text("Fallback Language");
    } else {
      options_accordion.find("#FClang_caption").text("Calendar Language (forced)");
    }
  }


  function changeFCtheme(theme) {
  
    var availableThemes = "bootswatch-flatly bootswatch-slate midnight"; // space separated class names of availabe themes
  
    if (theme == "jQuery UI" || edit_div.find(".gp_fullcalendar_area.ui-widget").length > 0 ) {
      option_messages.find("#gcal-jQUI-theme").slideToggleBool( true );
      return;
    }
    if (theme == "default") {
      edit_div.find(".gp_fullcalendar_area").removeClass(availableThemes);
      return;
    }
    $gp.LoadStyle( FULLCALENDAR_BASE + '/themes/' + theme + '.css' );
    edit_div.find(".gp_fullcalendar_area").removeClass(availableThemes).addClass(theme);
  }

  function previewLoader(loaderDiv,loaderClass) {
    loaderDiv
      .removeClass("loader-spinner-dark1 loader-spinner-dark2 loader-spinner-light1 loader-spinner-light2 loader-bar-dark1 loader-bar-dark2 loader-bar-light loader-none")
      .addClass("loader-" + loaderClass)
      .show();
    setTimeout( function() {
      loaderDiv.hide();
    }, 3000);
  }

  function changeHeader(fcDiv) { 
    // won’t work for now - no live setters available yet in FC 2.3.1
    /* 
    var newHeader = {
      left   : FCheaderWrapper.find("select[name='fc_header[left]']").val(),
      center : FCheaderWrapper.find("select[name='fc_header[center]']").val(),
      right  : FCheaderWrapper.find("select[name='fc_header[right]']").val()
    };
    //fcDiv.fullCalendar('getView').options.header = newHeader;
    fcDiv.fullCalendar('options', 'header', newHeader);
    fcDiv.fullCalendar('render');
    */
  }

}

// jQuery + slideToggleBool by JK
$.fn.slideToggleBool = function(bool,time,callback) { 
  time = ( typeof(time)=="undefined" ) ? 300 : time ;
  callback = ( typeof(callback) === 'function' ) ? callback : function(){} ;
  if(bool) { $(this).slideDown(time); } else { $(this).slideUp(time); } 
}

