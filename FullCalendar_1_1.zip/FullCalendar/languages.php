<?php /* UTF-8! ÄÖÜäöüß
######################################################################
PHP languages definition for FullCalendar for gpEasy
Author: J. Krausz
Date: 2015-03-24
Version 1.0
######################################################################
*/
$all_languages = array(
  'aa' => 'Afar', 'ab' => 'Abkhaz', 'ace' => 'Aceh', 'af' => 'Afrikaans', 'ak' => 'Akan', 'aln' => 'Gheg Albanian',
  'als' => 'Alemannic','am' => 'Amharic', 'an' => 'Aragonese', 'ang' => 'Old English', 'ar' => 'Arabic', 'arc' => 'Aramaic', 
  'arn' => 'Mapudungun','arz' => 'Egyptian Spoken Arabic', 'as' => 'Assamese', 'ast' => 'Asturian', 'av' => 'Avar', 'avk' => 'Kotava',
  'ay' => 'Aymara', 'az' => 'Azerbaijani', 

  'ba' => 'Bashkir', 'bar' => 'Bavarian', 'bat-smg' => 'Samogitian', 'bcc' => 'Southern Balochi', 'bcl' => 'Bikol', 'be' => 'Belarusian',
  'be-tarask' => 'Belarusian (Taraskievica)', 'bg' => 'Bulgarian', 'bh' => 'Bhojpuri', 'bi' => 'Bislama', 'bm' => 'Bambara', 'bn' => 'Bengali',
  'bo' => 'Tibetan', 'bpy' => 'Bishnupriya Manipuri', 'bqi' => 'Bakthiari', 'br' => 'Breton', 'bs' => 'Bosnian', 'bug' => 'Bugis', 'bxr' => 'Buryat (Russia)',

  'ca' => 'Catalan', 'cbk-zam' => 'Zamboanga Chavacano', 'cdo' => 'Min Dong', 'ce' => 'Chechen', 'ceb' => 'Cebuano', 'ch' => 'Chamorro', 'cho' => 'Choctaw',
  'chr' => 'Cherokee', 'chy' => 'Cheyenne', 'ckb' => 'Sorani', 'ckb-latn' => "Central Kurdish Latin script", 'ckb-arab' => 'Central Kurdish Arabic script',
  'co' => 'Corsican', 'cps' => 'Capiznon',  'cr' => 'Cree', 'crh' => 'Crimean Tatar', 'crh-latn' => 'Crimean Tatar (Latin)', 'crh-cyrl' => 'Crimean Tatar (Cyrillic)',
  'cs' => 'Czech', 'csb' => 'Cassubian', 'cu' => 'Old Church Slavonic', 'cv' => 'Chuvash', 'cy' => 'Welsh', 

  'da' => 'Danish', 'de' => 'German',
  'de-at' => 'German (Austria)', 'de-ch' => 'German (Switzerland)', 'de-formal' => 'German (formal/Sie)', 'diq' => 'Zazaki', 'dsb' => 'Lower Sorbian', 
  'dv' => 'Dhivehi', 'dz' => 'Bhutani', 

  'ee' => 'Éwé', 'el' => 'Greek', 'eml' => 'Emiliano-Romagnolo/Sammarinese', 'en' => 'English (US)', 'en-gb' => 'British English (United Kingdom)',
  'eo' => 'Esperanto', 'es' => 'Spanish', 'et' => 'Estonian', 'eu' => 'Basque', 'ext' => 'Extremaduran', 

  'fa' => 'Persian', 'ff' => 'Fulfulde/Maasina',
  'fi' => 'Finnish', 'fiu-vro' => 'Võro', 'fj' => 'Fijian', 'fo' => 'Faroese', 'fr' => 'French', 'frc' => 'Cajun French', 'frp' => 'Arpitan',
  'frr' => 'North Frisian', 'fur' => 'Friulian', 'fy' => 'Frisian', 

  'ga' => 'Irish', 'gag' => 'Gagauz', 'gan' => 'Gan', 'gan-hans' => 'Gan (Simplified Han)', 'gan-hant' => 'Gan (Traditional Han)', 'gd' => 'Scots Gaelic', 
  'gl' => 'Galician', 'glk' => 'Gilaki', 'gn' => 'Guaraní/Paraguayan', 'got' => 'Gothic', 'grc' => 'Ancient Greek', 'gsw' => 'Alemannic', 
  'gu' => 'Gujarati', 'gv' => 'Manx',

  'ha' => 'Hausa', 'hak' => 'Hakka', 'haw' => 'Hawaiian', 'he' => 'Hebrew', 'hi' => 'Hindi', 'hif' => 'Fijian Hindi','hif-deva' => 'Fiji Hindi (devangari)',
  'hif-latn' => 'Fiji Hindi (latin)', 'hil' => 'Hiligaynon', 'ho' => 'Hiri Motu', 'hr' => 'Croatian', 'hsb' => 'Upper Sorbian', 'ht'  => 'Haitian Creole French',
  'hu' => 'Hungarian', 'hy' => 'Armenian', 'hz' => 'Herero', 'ia' => 'Interlingua (IALA)', 'id' => 'Indonesian', 'ie' => 'Interlingue (Occidental)',
  'ig' => 'Igbo', 'ii' => 'Sichuan Yi', 'ik' => 'Inupiak/Inupiatun', 'ike-cans' => 'Inuktitut', 'ike-latn' => 'Inuktitut (Latin script)',
  'ilo' => 'Ilokano', 'inh' => 'Ingush', 'io' => 'Ido', 'is' => 'Icelandic', 'it' => 'Italian', 'iu' => 'Inuktitut (macro language)',

  'ja' => 'Japanese', 'jbo' => 'Lojban', 'jut' => 'Jutish/Jutlandic', 'jv' => 'Javanese', 

  'ka' => 'Georgian', 'kaa' => 'Karakalpak', 'kab' => 'Kabyle', 'kg' => 'Kongo/Kikongo', 'ki' => 'Gikuyu', 'kiu' => 'Kirmanjki', 'kj' => 'Kwanyama',
  'kk' => 'Kazakh', 'kk-arab' => 'Kazakh Arabic', 'kk-cyrl' => 'Kazakh Cyrillic', 'kk-latn' => 'Kazakh Latin', 'kk-cn' => 'Kazakh (China)',
  'kk-kz' => 'Kazakh (Kazakhstan)', 'kk-tr' => 'Kazakh (Turkey)', 'kl' => 'Inuktitut, Greenlandic/Kalaallisut', 'km' => 'Khmer (Central)',
  'kn' => 'Kannada', 'ko' => 'Korean', 'ko-kp' => 'Korean (DPRK)', 'koi' => 'Komi-Permyak', 'kr' => 'Kanuri (Central)', 'krc' => 'Karachay-Balkar',
  'kri' => 'Krio', 'krj' => 'Kinaray-a', 'ks' => 'Kashmiri', 'ksh' => 'Ripuarian', 'ku'  => 'Kurdish', 'ku-latn' => 'Northern Kurdish Latin script',
  'ku-arab' => 'Northern Kurdish Arabic script', 'kv' => 'Komi-Zyrian', 'kw' => 'Cornish', 'ky' => 'Kirghiz', 

  'la' => 'Latin', 'lad' => 'Ladino', 'lb' => 'Luxemburguish', 'lbe' => 'Lak', 'lez' => 'Lezgi', 'lfn' => 'Lingua Franca Nova', 'lg' => 'Ganda', 'li' => 'Limburgian',
  'lij' => 'Ligurian', 'lmo' => 'Lombard', 'ln' => 'Lingala', 'lo' => 'Laotian', 'loz' => 'Lozi', 'lt' => 'Lithuanian', 'ltg' => 'Latgalian', 'lv' => 'Latvian',
  'lzh' => 'Literary Chinese', 'lzz' => 'Laz', 

  'mai' => 'Maithili', 'map-bms' => 'Banyumasan', 'mdf' => 'Moksha', 'mg' => 'Malagasy', 'mh' => 'Marshallese', 'mhr' => 'Eastern Mari', 'mi' => 'Maori', 
  'mk' => 'Macedonian','ml' => 'Malayalam', 'mn' => 'Halh Mongolian (Cyrillic)', 'mo' => 'Moldovan', 'mr' => 'Marathi', 'mrj' => 'Hill Mari', 'ms' => 'Malay',
  'mt' => 'Maltese', 'mus' => 'Muskogee/Creek', 'mwl' => 'Mirandese', 'my' => 'Burmese', 'myv' => 'Erzya', 'mzn' => 'Mazanderani', 

  'na' => 'Mazanderani', 'nah' => 'Nahuatl', 'nan' => 'Min-nan', 'nap' => 'Neapolitan', 'nb' => 'Norwegian (Bokmal)', 'nds' => 'Low German/Low Saxon',
  'nds-nl' => 'Dutch Low Saxon', 'ne' => 'Nepali', 'new' => 'Newar/Nepal Bhasa', 'ng' => 'Ndonga', 'niu' => 'Niuean', 'nl' => 'Dutch', 'nn' => 'Norwegian (Nynorsk)',
  'no' => 'Norwegian', 'nov' => 'Novial', 'nrm' => 'Norman', 'nso' => 'Northern Sotho', 'nv' => 'Navajo', 'ny' => 'Chichewa', 

  'oc' => 'Occitan', 'om' => 'Oromo', 'or' => 'Oriya', 'os' => 'Ossetic', 

  'pa' => 'Eastern Punjabi (pan)', 'pag' => 'Pangasinan', 'pam' => 'Pampanga', 'pap' => 'Papiamentu', 'pcd' => 'Picard', 'pdc' => 'Pennsylvania German', 
  'pdt' => 'Plautdietsch/Mennonite Low German', 'pfl' => 'Palatinate German', 'pi' => 'Pali', 'pih' => 'Norfuk/Pitcairn/Norfolk', 'pl' => 'Polish',
  'pms' => 'Piedmontese', 'pnb' => 'Western Punjabi', 'pnt' => 'Pontic/Pontic Greek', 'prg' => 'Prussian', 'ps' => 'Pashto/Afghan/Yusufzai Pashto',
  'pt' => 'Portuguese', 'pt-br' => 'Brazilian Portuguese', 

  'qu' => 'Quechua',

  'rgn' => 'Romagnol', 'rif' => 'Tarifit', 'rm' => 'Raeto-Romance', 'rmy' => 'Vlax Romany', 'rn' => 'Rundi/Kirundi/Urundi', 'ro' => 'Romanian', 
  'roa-rup' => 'Aromanian', 'roa-tara' => 'Tarantino', 'ru' => 'Russian', 'rue' => 'Rusyn', 'ruq' => 'Megleno-Romanian', 
  'ruq-cyrl' => 'Megleno-Romanian (Cyrillic script)', 'ruq-grek' => 'Megleno-Romanian (Greek script)', 'ruq-latn' => 'Megleno-Romanian (Latin script)',
  'rw' => 'Kinyarwanda', 

  'sa' => 'Sanskrit',  'sah' => 'Sakha', 'sc' => 'Sardinian', 'scn' => 'Sicilian', 'sco' => 'Scots', 'sd' => 'Sindhi', 'sdc' => 'Sassarese', 'se' => ' Northern Sami',
  'sei' => 'Seri', 'sg' => 'Sango/Sangho', 'sh' => 'Serbocroatian', 'shi' => 'Tachelhit',  'si' => 'Sinhalese', 'simple' => 'Simple English', 'sk' => 'Slovak',
  'sl' => 'Slovenian', 'sli' => 'Lower Selisian', 'sm' => 'Samoan', 'sma' => 'Southern Sami', 'sn' => 'Shona', 'so' => 'Somali', 'sq' => 'Albanian', 'sr' => 'Serbian',
  'sr-ec' => 'Serbian Cyrillic ekavian', 'sr-el' => 'Serbian Latin ekavian', 'srn' => 'Sranan Tongo', 'ss' => 'Swati', 'st' => 'Southern Sotho', 'stq' => 'Saterland Frisian',
  'su' => 'Sundanese', 'sv' => 'Swedish', 'sw' => 'Swahili', 'szl' => 'Silesian', 

  'ta' => 'Tamil', 'tcy' => 'Tulu', 'te' => 'Telugu', 'tet' => 'Tetun', 'tg' => 'Tajiki', 'tg-cyrl' => 'Tajiki (Cyrllic script)', 'tg-latn' => 'Tajiki (Latin script)',
  'th' => 'Thai', 'ti' => 'Tigrinya', 'tk' => 'Turkmen', 'tl' => 'Tagalog', 'tn' => 'Setswana', 'to' => 'Tonga (Tonga Islands)', 'tokipona' => 'Toki Pona', 
  'tp' => 'Toki Pona (deprecated code!)', 'tpi' => 'Tok Pisin', 'tr' => 'Turkish', 'ts' => 'Tsonga', 'tt' => 'Tatar', 'tt-cyrl' => 'Tatar (Cyrillic script)',
  'tt-latn' => 'Tatar (Latin script)', 'tum' => 'Tumbuka', 'tw' => 'Twi (Ashanti/Akuapem)', 'ty' => 'Tahitian', 'tyv' => 'Tyvan',

  'udm' => 'Udmurt', 'ug' => 'Uyghur', 'ug-arab' => 'Uyghur (Arabic script)', 'ug-latn' => 'Uyghur (Latin script)', 'uk' => 'Ukrainian', 'ur' => 'Urdu',
  'uz' => 'Uzbek', 

  've' => 'Venda', 'vec' => 'Venetian', 'vep' => 'Veps', 'vi' => 'Vietnamese', 'vls' => 'West Flemish', 'vmf' => 'Upper Franconian/Main-Franconian', 
  'vo' => 'Volapük', 'vot' => 'Vod/Votian', 'vro' => 'Võro', 

  'wa' => 'Walloon', 'war' => 'Waray-Waray', 'wo' => 'Wolof', 'wuu' => 'Wu Chinese', 

  'xal' => 'Kalmyk-Oirat', 'xh' => 'Xhosan', 'xmf' => 'Mingrelian', 

  'yi' => 'Yiddish', 'yo' => 'Yoruba', 'yue' => 'Cantonese', 

  'za' => 'Zhuang', 'zea' => 'Zeeuws/Zeaws', 'zh' => 'Zhong Wén - Chinese', 'zh-classical' => 'Classical Chinese/Literary Chinese',
  'zh-cn' => 'Chinese (PRC)', 'zh-hans' => 'Simplified Chinese script', 'zh-hant' => 'Traditional Chinese script', 'zh-hk' => 'Chinese (Hong Kong)',
  'zh-min-nan' => 'Min-nan', 'zh-mo' => "Chinese (Macau)", 'zh-my' => 'Chinese (Malaysia)', 'zh-sg' => 'Chinese (Singapore)', 'zh-tw' => 'Chinese (Taiwan)',
  'zh-yue' => 'Cantonese', 'zu' => 'Zulu'
);