$(document).ready(function(){
	$("#MultiSiteSearch_EditConfig").append('<input type="hidden" name="verified" value="'+post_nonce+'" />');
	$.fn.dirrty.defaults.preventLeaving = false;
	$("#MultiSiteSearch_EditConfig").dirrty().on("dirty", function(){
		$("#status")
			.html("Click on the save button to make your changes persistent")
			.addClass("mss_notice")
			.removeClass("mss_passed"); 
		$("#save_config")
			.removeAttr("disabled")
			.addClass("gpsubmit")
			.removeClass("gpdisabled");
	}).on("clean", function(){
		$("#status")
			.html("Form and data are synchronized")
			.addClass("mss_passed")
			.removeClass("mss_notice");
		$("#save_config")
			.attr("disabled", "disabled")
			.removeClass("gpsubmit")
			.addClass("gpdisabled");
	});
});
