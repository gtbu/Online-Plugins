<?php defined('is_running') or die('Not an entry point...'); ?>

<?php global $langmessage, $config; ?>

<div class="MultiSiteSearch_ShowWarningMsg">

<h2 class="hqmargin">MultiSitesearch - <?php echo $langmessage['Settings']; ?></h2><br/>

<fieldset>
	<legend>Warning</legend>
	<p class="warning">MultiSite plugin is not installed!</p>
	<p>Please either install the MultiSite plugin or uninstall the MultiSiteSearch plugin.</p>
	<p><?php echo common::Link('Admin_Addons', 'Modules Management'); ?></p>
</fieldset>

</div>


