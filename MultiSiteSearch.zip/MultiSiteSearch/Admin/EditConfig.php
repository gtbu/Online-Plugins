<?php defined('is_running') or die('Not an entry point...');

gpPlugin::incl('MultiSiteSearch.php');

class MultiSitesearch_EditConfig extends MultiSitesearch {

	protected $css;
	protected $default_css;

	// Constructor
	public function __construct() {

		// Parent Class Constructor
		parent::__construct();

		// Is MultiSite still installed?
		if ($this->installed === FALSE) {
			$this->_showWarningMsg();
			return;
		}		

		$this->_loadCssFile();

		// Save Global Conf
		if ($this->_doSaveConfig()) { 
			$this->_updateConfig();
			if ($this->_isValidConfig()) {
				$this->_saveConfig();
			} 
		}

		// Init Custom Css
		if ($this->_doInitCustomCss()) { 
			$this->_initCustomCss(false);		
		}

		// Clear Custom Css
		if ($this->_doClearCustomCss()) { 
			$this->_initCustomCss(true);		
		}

		$this->_editConfig();

	}

	/////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	/////////////////////////////////////////////////////////////////////

	private function _loadCssFile() {

		global $addonPathData, $addonPathCode;

		$this->css = '';
		$this->default_css = '';

		// Default css file
		$file = $addonPathCode.'/Site/MultiSiteSearch.css';

		if (file_exists($file)) {
			$this->default_css = file_get_contents($file);
		} else {
			message('Oops, no default css file found!');
		}

		// Custom css file
		$file = $addonPathData.'/MultiSiteSearch.css';

		if (file_exists($file)) {
			$this->css = file_get_contents($file);
		} 

	}

	private function _isValidConfig() {

		return true;

	}

	private function _updateConfig() {
		
		// Css
		$this->css = trim(strval($_POST['mss_css']));

		// siteData
		foreach (array_keys($this->siteData['sites']) as $key) {
			$this->siteData['sites'][$key]['search_enabled'] = $_POST['mss_sites'][$key]['search_enabled'];
		}

		// MultiSiteSearch Conf
		$this->config['use_default_css'] = intval($_POST['use_default_css']);
	}

	private function _doSaveConfig() {
		return isset($_POST['save_config']);
	}

	private function _doInitCustomCss() {
		return isset($_POST['init_custom_css']);
	}

	private function _doClearCustomCss() {
		return isset($_POST['clear_custom_css']);
	}

	private function _initCustomCss($clear = false) {

		global $addonPathData, $langmessage;

		$this->css = $clear === true ? '' : $this->default_css;

		$css_file = $addonPathData.'/MultiSiteSearch.css';
		$return = true;

		if (!empty($this->css)) {
			$return = gpFiles::Save($css_file, $this->css);
		} elseif (file_exists($css_file) && is_file($css_file)) {
			$return = unlink($css_file);
		}	

		if ($return === false) {
			message($langmessage['OOPS']);
		} else {
			message($langmessage['SAVED']);
		}

	}

	private function _editConfig() {

		global $addonPathCode, $addonFolderName, $page;
		
		// Css
		$page->css_user[] = '/addons/'.$addonFolderName.'/Admin/EditConfig.css';

		// Js
		$page->head_js[] = '/addons/'.$addonFolderName.'/Admin/jquery.dirrty.js';
		$page->head_js[] = '/addons/'.$addonFolderName.'/Admin/EditConfig.js';

		// We load the editConfig.php template
		include($addonPathCode.'/Admin/EditConfig_Tmpl.php');

	}

	private function _saveConfig() {

		global $config, $addonPathData, $langmessage;

		$return_1 = gpFiles::SaveArray($this->dataFile,'siteData',$this->siteData);

		$css_file = $addonPathData.'/MultiSiteSearch.css';
		$return_2 = true;

		if (!empty($this->css)) {
			$return_2 = gpFiles::Save($css_file, $this->css);
		} elseif (file_exists($css_file) && is_file($css_file)) {
			$return_2 = unlink($css_file);
		}

		$cfg_file = $addonPathData.'/config.php';
		$return_3 = gpFiles::SaveArray($cfg_file,'cfg',$this->config);

		if (($return = $return_1 && $return_2 && $return_3) === false) {
			message($langmessage['OOPS']);
		} else {
			message($langmessage['SAVED']);
		}

		return $return;

	}

	private function _showWarningMsg() {

		global $addonPathCode, $page;

		// Css
		$css	= '<style type="text/css">'
			. '.MultiSiteSearch_ShowWarningMsg h2{'
			. '	margin-bottom: 20px'
			. "}\n"
			. '.MultiSiteSearch_ShowWarningMsg p.warning{'
			. '	color: red;'
			. '	font-weight: bold;'
			. "}\n"
			. '.MultiSiteSearch_ShowWarningMsg fieldset{'
			. '	-webkit-border-radius: 8px;'
			. '	-moz-border-radius: 8px;'
			. '	border-radius: 8px;'
			. '	padding: 10px;'
			. '	border:1px solid #ccc;'
			. '	margin: 0 0 10px 0;'
			. '	position: relative'
			. "}\n"
			. '</style>'
			;
		$page->head .= $css;

		// We load the editConfig.php template
		include($addonPathCode.'/Admin/ShowWarningMsg_Tmpl.php');

	}

}

