<?php defined('is_running') or die('Not an entry point...'); ?>

<?php global $langmessage, $config; ?>

<h2 class="hqmargin">MultiSiteSearch - <?php echo $langmessage['Settings']; ?></h2><br/>

<div class="MultiSiteSearch_EditConfig">


<p id="status" class="mss_passed">Form and data are synchronized</p>

<form action="<?php echo common::GetUrl('Admin_MultiSitesearch_EditConfig'); ?>" method="post" id="MultiSiteSearch_EditConfig" name="MultiSiteSearch_EditConfig">

<table class="bordered" style="width:100%;">
<tr><th width="60%">Sub Sites</th><th width="40%">Search Enabled</th></tr>

<?php foreach ($this->siteData['sites'] as $path => $site) : ?>

<tr>

	<?php $val = (isset($site['search_enabled']) ? intval($site['search_enabled']) : 0); ?>

	<td><a href="<?php echo $site['url']; ?>" target="_blank"><?php echo $site['url']; ?></a></td>
	
	<td>
		<input type="hidden" name="mss_sites[<?php echo $path; ?>][search_enabled]" value="0" <?php echo ($val == 0 ? 'checked="checked"' : ''); ?> />
		<input type="checkbox" name="mss_sites[<?php echo $path; ?>][search_enabled]" value="1" <?php echo ($val == 1 ? 'checked="checked"' : ''); ?> />
	</td>

</tr>

<?php endforeach; ?>

</table>

<br />

<table class="bordered" style="width:100%;">
<tr><th width="60%">Custom Css</th><th width="40%">Description</th></tr>

<tr>

<td>
	<textarea name="mss_css"><?php echo $this->css; ?></textarea>
	<?php $val = (isset($this->config['use_default_css']) ? intval($this->config['use_default_css']) : 0); ?>
	<input type="hidden" name="use_default_css" value="0" <?php echo ($val == 0 ? 'checked="checked"' : ''); ?> />
	<?php if (empty($this->css)) : ?>
	<br />
	<input type="checkbox" name="use_default_css" value="1" <?php echo ($val == 1 ? 'checked="checked"' : ''); ?> />
	Use default css when custom css is empty
	<?php else: ?>
	<input type="hidden" name="use_default_css" value="1" <?php echo ($val == 1 ? 'checked="checked"' : ''); ?> />
	<?php endif; ?>
</td>

<td>
This custom css will be added to the head of the search page.
You will usually use it to style external links differently from internal ones but it can serve any other purpose.
To help you getting started you can copy the default css in the custom css and tweak it the way you like.
Please use the <a href="http://gpeasy.com/Forum" target="_blank">gpEasy forum</a> if you have any css-related question.
</td>

</tr>
</table>

<br/>
<input type="submit" name="save_config" value="<?php echo $langmessage['save']; ?>" id="save_config" class="gpdisabled" disabled="disabled" style="float:left" />

<?php if (empty($this->css)) : ?>
<input type="submit" name="init_custom_css" value="<?php echo gpOutput::SelectText('Save Default Css as Custom Css'); ?>" class="gpsubmit" style="float:right" />
<?php else: ?>
<input type="submit" name="clear_custom_css" value="<?php echo gpOutput::SelectText('Clear Custom Css'); ?>" class="gpsubmit" style="float:right" />
<?php endif; ?>

</form>

</div>
