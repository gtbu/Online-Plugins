<?php
defined('is_running') or die('Not an entry point...');

abstract class MultiSiteSearch {

	// Multi Site
	protected $installed;
	protected $dataFile;
	protected $siteData;

	// MultiSiteSearch
	protected $config;

	public function __construct(){

		global $config, $dataDir, $page, $addonFolderName;

		$this->installed = true;

		// Is MultiSite still installed?
		$addons_multisite = array_filter($config['addons'], function($addon) {
				if (isset($addon['id'])) return ($addon['id'] == 16 ? $addon : false);
				return false;
			});

		if (empty($addons_multisite)) {
			$this->installed = false;
			return;
		}

		$addons_multisite = array_values($addons_multisite);
		$addons_multisite = $addons_multisite[0];

		// MultiSite plugin path data
		$this->dataFile = $dataDir.'/data/_addondata/'.$addons_multisite['data_folder'].'/data.php';

		// Load the MultiSite data
		$this->_getMultiSiteData();

		// Load MultiSiteSearch config
		$this->_loadConfig();

	}

	private function _getMultiSiteData(){

		$this->siteData = array();

		if( file_exists($this->dataFile) ){
			require($this->dataFile);
			if( isset($siteData) ){
				$this->siteData = $siteData;
			}
		}

		$this->siteData += array('sites'=>array());
	}

	private function _loadConfig() {

		global $addonPathData;

		$cfg_file = $addonPathData.'/config.php';

		if (file_exists($cfg_file)) {
			include($cfg_file);
		} else {
			$cfg = $this->_loadDefaults($cfg_file);
		}

		$this->config = $cfg;

	}

	private function _loadDefaults($cfg_file) {

		global $addonPathData, $addonPathCode, $config;

		$cfg = array();

		$cfg['use_default_css'] = 1; 

		// Save default config
		if (gpFiles::SaveArray($cfg_file,'cfg',$cfg)) {
			$message = gpOutput::SelectText('Default settings saved.');
			message($message);
		}

		// Copy MultiSiteSearch.png to the data folder
		$file_source = $addonPathCode.'/Site/MultiSiteSearch.png';
		$file_dest = $addonPathData.'/MultiSiteSearch.png';

		@copy($file_source, $file_dest);

		return $cfg;

	}

}


