<?php
defined('is_running') or die('Not an entry point...');

gpPlugin::incl('MultiSiteSearch.php');

class MultiSiteSearch_Search extends MultiSiteSearch {

	const GLOBALS = 'dataDir,dirPrefix,rootDir,config,gp_hooks,linkPrefix,gp_index,gp_titles,gp_menu,gpLayouts';
	const _SERVER = 'HTTP_HOST, SERVER_NAME';

	private $GLOBALS; // array
	private $_SERVER; // array

	// Current sub site
	private $path; // string
	private $site; // array

	public function __construct() {
		parent::__construct();
	}

	public function Search($mainsite_search_obj){

		global $config, $dataDir, $page, $addonFolderName;

		// Is MultiSite still installed?
		if ($this->installed === FALSE) {
			return;
		}

		// No sub sites created yet
		if (empty($this->siteData['sites'])) {
			return;
		}

		// Search pattern
		$search_pattern = $mainsite_search_obj->search_pattern;

		// Load the MultiSiteSearch_Special class
		gpPlugin::incl('Site/MultiSiteSearch_Special.php');

		// Save the global context of the main site	
		$this->_saveMainSiteContext();

		foreach ($this->siteData['sites'] as $this->path => $this->site) {

			// Search enabled?
			if(!isset($this->site['search_enabled']) || !$this->site['search_enabled']) {
				continue;
			}

			// Is installed?
			if(!@file_exists($this->path.'/data/_site/config.php')){
				continue;
			}

			// Create a global context for this subsite
			$this->_createSubSiteContext();

			// Perform subsite search
			$subsite_search_obj = new MultiSiteSearch_Special($search_pattern);

			// Merge sub-site results with main-site results
			$mainsite_search_obj->results = array_merge($mainsite_search_obj->results, $subsite_search_obj->results);

		}

		// Restore the global context of the main site
		$this->_restoreMainSiteContext();

	}

	private function _createSubSiteContext() {

		$GLOBALS['rootDir'] = $this->GLOBALS['rootDir'];
		$GLOBALS['dataDir'] = $this->path;
		$GLOBALS['dirPrefix'] = ($php_url_path = parse_url($this->site['url'], PHP_URL_PATH)) == '/' ? '' : $php_url_path;

		unset($GLOBALS['gp_hooks']);

		$_SERVER['HTTP_HOST'] = parse_url($this->site['url'], PHP_URL_HOST);

		common::GetConfig();
		common::SetLinkPrefix();

	}

	private function _saveMainSiteContext() {

		foreach(explode(',', self::GLOBALS) as $global) $this->GLOBALS[$global] = $GLOBALS[$global];

		foreach(explode(',', self::_SERVER) as $server) {
			if (isset($_SERVER[$server])) $this->_SERVER[$server] = $_SERVER[$server];
		}

	}

	private function _restoreMainSiteContext() {

		foreach(explode(',', self::GLOBALS) as $global) $GLOBALS[$global] = $this->GLOBALS[$global];

		foreach(explode(',', self::_SERVER) as $server) {
			if (isset($this->_SERVER[$server])) $_SERVER[$server] = $this->_SERVER[$server];
		}
	}

}


