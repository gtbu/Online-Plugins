<?php defined('is_running') or die('Not an entry point...');

gpPlugin::incl('MultiSiteSearch.php');

class MultiSiteSearch_GetHead extends MultiSiteSearch {

	public function __construct(){
		global $addonFolderName, $addonPathData, $addonPathCode, $page;

		parent::__construct();

		// Custom css file
		$file = $addonPathData.'/MultiSiteSearch.css';

		if (file_exists($file)) {
			$page->css_user[] = '/data/_addondata/'.$addonFolderName.'/MultiSiteSearch.css';
			return;
		}

		if (!$this->config['use_default_css']) {
			return;
		}

		// Default css file
		$file = $addonPathCode.'/Site/MultiSiteSearch.css';

		if (file_exists($file)) {
			$page->css_user[] = '/data/_addoncode/'.$addonFolderName.'/Site/MultiSiteSearch.css';
		}  

	}

}


