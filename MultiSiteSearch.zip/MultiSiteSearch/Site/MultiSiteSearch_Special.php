<?php
defined('is_running') or die('Not an entry point...');

class MultiSiteSearch_Special extends special_gpsearch {

	public function __construct($search_pattern) {
		$this->search_pattern = $search_pattern;
		$this->RunQuery();
	}

	public function RunQuery(){
		$this->SearchPages();
		gpPlugin::Action('Search',array($this));
	}


	public function FindString(&$content, $label, $slug, $link_query = ''){
		$this->search_count++;

		//search all of the content include html
		$content = $label.' '.$content;
		$match_count = preg_match_all($this->search_pattern,$content,$matches,PREG_OFFSET_CAPTURE);
		if( $match_count < 1 ){
			return;
		}
		$words = str_word_count($content);
		$strength = $this->Strength($matches,$words);


		//format content, remove html
		$label_len = strlen($label);
		$content = substr($content,$label_len);
		$content = str_replace('>','> ',$content);
		$content = preg_replace('/\s+/', ' ', $content);
		$content = strip_tags($content);
		preg_match($this->search_pattern,$content,$matches,PREG_OFFSET_CAPTURE);
		$start = 0;
		if( isset($matches[0][1]) ){
			$start = $matches[0][1];
		}

		//find a space at the beginning to start from
		$i = 0;
		do{
			$i++;
			$start_offset = $i*10;
			$start = max(0,$start-$start_offset);
			$trimmed = substr($content,$start,300);
			$space = strpos($trimmed,' ');
			if( $space < $start_offset ){
				$content = substr($trimmed,$space);
				break;
			}
		}while( ($start-$start_offset) > 0);


		//find a space at the end
		if( strlen($content) > 250 ){
			$space2 = strpos($content,' ',$space+220);
			if( $space2 > 0 ){
				$content = substr($content,0,$space2);
			}
		}

		$result = array();

		$result['label'] = $label;
		$result['slug'] = $slug;
		$result['query'] = $link_query;
		$result['content'] = preg_replace($this->search_pattern,'<b>\1\2</b>',$content);
		$result['words'] = $words;
		$result['matches'] = $match_count;
		$result['strength'] = $strength;

		// Added: build external url and link

		$result['url'] = common::AbsoluteUrl( $result['slug'], $result['query'] );
		$result['link'] = common::AbsoluteLink($result['slug'],$result['label'],$result['query']);

		$this->results[] = $result;
	}

}
