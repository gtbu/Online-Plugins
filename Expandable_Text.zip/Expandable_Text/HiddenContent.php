<?php
defined('is_running') or die('Not an entry point...');

class HiddenContent{

	public static function ToContent($section_data){
		global $addonFolderName, $page, $addonRelativeCode;
		static $added = false;

		if( !$added && strpos($section_data['content'],'toggle_hidden') ){
			$page->admin_js = true; //loads main.js
			$page->head_js[] = '/data/_addoncode/'.$addonFolderName.'/script.js';
			$page->css_user[] = '/data/_addoncode/'.$addonFolderName.'/style.css';
			$added = true;			
		}
		
		$section_data['content'] = '<div class="Hidden-container">'
		                           .$section_data['content']
                                   .'</div>';						
				
		return $section_data;
	}	
}
