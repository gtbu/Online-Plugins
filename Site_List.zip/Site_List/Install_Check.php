<?php
defined('is_running') or die('Not an entry point...');

function Install_Check(){
	global $config;
	//if current version was previosly installed
	if (array_key_exists('SiteListVersion',$config)){// && ($config['SiteListVersion']=='1.0')) {
		echo '<p style="color:green">Removing plugin previous old config key.</p>';
		unset($config['SiteListVersion']);
		admin_tools::SaveConfig();
	}

	$passed = true;
	if( !class_exists('SQLite3') ){
		echo '<p style="color:red">Cannot install this addon. SQLite3 Required.</p>';
		$passed = false;
	}else {
		$version = SQLite3::version();
		echo '<p style="color:green">SQLite version '.$version['versionString'].' found.</p>';
	}
	return $passed;
}
?>
