function gp_init_inline_edit(g){
	var h=!1,i="",f=gp_editing.get_path(g),e=gp_editing.get_edit_area(g);
	!1==e||!1==f||
	(ff=gpSiteListView.admin_link+"?"+strip_to(f,"?"),
	gp_editor={
		save_path:f,
		destroy:function(){
			e.html(h)},
		checkDirty:function(){
			return gp_editor.gp_saveData()!=i?!0:!1},
		gp_saveData:function(){return $("#gp_include_form").serialize()},
		resetDirty:function(){i=gp_editor.gp_saveData()},
		updateElement:function(){h=e.html()}
		},
	gp_editing.editor_tools(),
	//$gp.jGoTo(f+"&cmd=include_dialog"),
	//console.log(f),// /dev/gpeasy/360/?section=4&revision=1369732229
	$gp.jGoTo(ff+"&cmd=editview_dialog&title="+gpSiteListView.page_title),
	gpresponse.gp_include_dialog=function(c){
		$("#ckeditor_top").html(c.CONTENT);
		gp_editor.resetDirty();
		gp_editor.updateElement()
	},
	gpresponse.gp_autocomplete_include=function(c){
		var d;
		d="file"==c.SELECTOR?$("#gp_file_include"):$("#gp_gadget_include");
		eval(c.CONTENT);
//console.log(source);
		d.css({position:"relative",zIndex:12E3}).focus(function(){d.autocomplete("search",d.val())}).autocomplete({source:source,delay:100,minLength:0,open:function(){},select:function(b,a){
//	console.log(source,a,b,this);
			$("#gp_include_form .autocomplete").val("");
			if(a.item)return this.value=a.item[0],$(this).parent().find('input[name=index]').val(a.item[3]).end().find('input[name=viewindex]').val(a.item[2]),!1}
	
		})
var autocomplete_key = 'ui-autocomplete';//ui version 1.10
if( d.data(autocomplete_key)==undefined){
autocomplete_key = 'autocomplete';
}
		d.data(autocomplete_key)._renderItem=function(b,a){
//console.log(a,b,this);
			return $("<li></li>").data("item.autocomplete",
		a).append("<a>"+$gp.htmlchars(a[0])+"<span>"+$gp.htmlchars(a[1])+"</span></a>").appendTo(b)}
	},
	gplinks.gp_include_preview=function(c,d){
		d.preventDefault();
		loading();
		var b=gpSiteListView.admin_link,b=strip_from(b,"#"),a="";
		0<b.indexOf("?")&&(a=strip_to(b,"?")+"&");
		a+=gp_editor.gp_saveData();
		$gp.postC(b,a+"&cmd=editview_preview&title="+gpSiteListView.page_title)
	},
	gpresponse.gp_include_content=function(c){
		//console.log(e);
		e.html(c.CONTENT)
	}
	)
};
