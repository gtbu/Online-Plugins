<?php
defined('is_running') or die('Not an entry point...');

$texts = array();
$texts[] = 'Lists';
$texts[] = 'List Item';


/* this function can be used to update the addon once changes to the text values have been made */
/*
function OnTextChange(){
	gpPlugin::incl('SimpleBlogCommon.php','require_once');
	new SimpleBlogCommon();//regenerate the gadget and feed
}
*/
?>
