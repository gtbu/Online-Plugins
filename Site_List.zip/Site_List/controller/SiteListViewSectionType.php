<?php
defined('is_running') or die('Not an entry point...');
gpPlugin::incl('controller/SiteListCommon.php','require_once');

class SiteListViewSectionType{
	const version='1.0';
	const author='site';
	const SectionTypeKey='sitelist_view';

	static function SectionTypes($section_types){
		$section_types[self::SectionTypeKey] = array();
		$section_types[self::SectionTypeKey]['label'] = 'Site List Include';
		return $section_types;
	}

	static function DefaultContent($default_content='',$type=self::SectionTypeKey){
		if( $type !== self::SectionTypeKey ){
			return $default_content;
		}

		return '<p>Site List Include</p>';
	}

	static function SectionToContent($section_data){
		if( $section_data['type'] !== self::SectionTypeKey ){
			return $section_data;
		}

		//global $page;
		//self::AddComponents();
		if (isset($section_data['contentKey']) && !empty($section_data['contentKey'])) {
			$siteList = new SiteListCommon();
			$content=$siteList->cache->Read($section_data['contentKey']);
			$section_data['content']=$content;
		}else {
			$section_data['content']='Site List Content Type';
		}

		/*
		if (!empty($section_data['content_js'])) {
			$page->head.=$section_data['content_js'];
		}
		*/

		return $section_data;
	}

	static function SaveSection($return,$section,$type){
		if( $type !== self::SectionTypeKey ){
			return $return;
		}

		global $page;
		//$content= & $_POST['file_include'];
		//$page->file_sections[$section]['content'] = $content;

		gpPlugin::incl('controller/SiteListCommon.php','require_once');
		$siteList = new SiteListCommon();
		if (!empty($_REQUEST['file_include']) && ($listIndex=$siteList->GetListIndex()) && ($viewIndex=$siteList->GetViewIndex($listIndex))) {
			//$content = $siteList->RenderView($viewIndex, $listIndex);
			//$page->file_sections[$section]['content'] = $content;
			$page->file_sections[$section]['contentKey'] = $siteList->GetViewTemplateKey($listIndex,$viewIndex);
			$page->file_sections[$section]['index'] = $listIndex;
			$page->file_sections[$section]['view_index'] = $viewIndex;
		}else {
			//$page->file_sections[$section]['content'] = '';//'<p>Site List Include</p>';
			$page->file_sections[$section]['index'] = null;
			$page->file_sections[$section]['view_index'] = null;
			
		}

		
/*
		gpPlugin::incl('controller/AdminSiteList.php','require_once');
		$admin = new AdminSiteList();
		$page->file_sections[$section]['index'] = $admin->GetListIndex();
		$page->file_sections[$section]['view_index'] = $admin->GetViewIndex();
*/

		return true;
	}

	static function GenerateContent_Admin(){
		self::AddComponents();
	}

	static function AddComponents(){
		global $addonFolderName, $page, $addonRelativeCode;
		static $done = false;

		if( $done ) return;

		$page->admin_js = true; //loads main.js

		$page->head_js[] = $addonRelativeCode.'/view/js/jquery.tweet.js';
		$page->css_user[] = $addonRelativeCode.'/view/css/jquery.tweet.css';

		$done = true;
	}

	static function InlineEdit_Scripts($scripts,$type){
		if( $type !== self::SectionTypeKey ){
			return $scripts;
		}

		global $addonRelativeCode,$page;
		//includeFile('tool/ajax.php');
		//$scripts = gpAjax::InlineEdit_Include($scripts);
		$scripts[] = $addonRelativeCode.'/view/js/view_edit.js';
		
		$admin_link=common::GetUrl('Admin_SiteList');
		$page_index=$page->gp_index;
		$page_title=$page->title;
		echo 'var gpSiteListView={admin_link:"'.$admin_link.'",page_index:"'.$page_index.'",page_title:"'.$page_title.'"};';

		return $scripts;
	}

	public static function GetPageByTitle($title=null){
		if (is_null($title)) {
			if( !isset($_REQUEST['title']) ){
				message($langmessage['OOPS'].'(no title)');
				return;
			}
			$title=& $_REQUEST['title'];
		}

		$page = new display($title, $type = 0);  //missing $type
		if( !$page->SetVars() ){
			message($langmessage['OOPS'].'(bad title)');
			return;
		}

		$page->GetFile();
		return $page;
	}
	//function EditDialog($views){
	public static function EditDialog(){
		global $page,$langmessage,$config;

		$currentpage=self::GetPageByTitle();

		$section =& $_GET['section'];
		if( !isset($currentpage->file_sections[$section]) ){
			message($langmessage['OOPS'].'(bad section)');
			return;
		}
		gpPlugin::incl('controller/SiteListCommon.php','require_once');
		$siteList = new SiteListCommon();

		$file_content='';
		if (isset($currentpage->file_sections[$section]['index'])) {
			$file_content = $siteList->GetViewNameByIndex($currentpage->file_sections[$section]['index'],$currentpage->file_sections[$section]['view_index']);//& $currentpage->file_sections[$section]['content'];
		}
		$index =isset($currentpage->file_sections[$section]['index'])?$currentpage->file_sections[$section]['index']:'';
		$view_index =isset($currentpage->file_sections[$section]['view_index'])?$currentpage->file_sections[$section]['view_index']:'';

		ob_start();

		echo '<form id="gp_include_form">';

		echo '<div class="gp_inlude_edit">';
		echo '<span class="label">';
		echo 'List View';
		echo '</span>';
		echo '<input type="text" size="" id="gp_file_include" name="file_include" class="autocomplete" value="'.htmlspecialchars($file_content).'" />';
		echo '<input type="hidden" name="index" value="'.$index.'" />';
		echo '<input type="hidden" name="viewindex" value="'.$view_index.'" />';
		echo '</div>';

		echo '<div id="gp_option_area">';
		echo '<a href="#" name="gp_include_preview" class="ckeditor_control full_width">Preview</a>';
		echo '</div>';

		echo '</form>';

		$content = ob_get_clean();
		$page->ajaxReplace = array();
		$page->ajaxReplace[] = array('gp_include_dialog','',$content);

		//include autocomplete
		$code = 'var source='.json_encode( $siteList->GetViewsSource() ).';';
/*
		$code = 'var source=[';
		if( isset($config['gadgets']) ){
			foreach($config['gadgets'] as $uniq => $info){
				$code .= '["'.addslashes($uniq).'","'.addslashes($uniq).'"],';
			}
		}
		$code .= ']';
*/

		$page->ajaxReplace[] = array('gp_autocomplete_include','file',$code);
	}
	static function PreviewSection($section=null){
		global $page,$langmessage;

		gpPlugin::incl('controller/SiteListCommon.php','require_once');
		$siteList = new SiteListCommon();
		$content='<p>&nbsp;</p>';
		if (($listIndex=$siteList->GetListIndex()) && ($viewIndex=$siteList->GetViewIndex($listIndex))) {
			$content = $siteList->RenderView($viewIndex, $listIndex);
		}

/*
		$data = array();
		$data['type'] = self::SectionTypeKey;
		$data['content'] = 'preview'.$_POST['file_include'];
		$data['index'] = $_POST['index'];
		$data['viewindex'] = $_POST['viewindex'];

		includeFile('tool/SectionContent.php');
		$content = section_content::RenderSection($data,$section);//,$this->title,$this->file_stats);
*/

		$page->ajaxReplace = array();
		$page->ajaxReplace[] = array('gp_include_content','',$content);
	}
}
?>
