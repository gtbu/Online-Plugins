<?php
defined('is_running') or die('Not an entry point...');

gpPlugin::incl('controller/SiteListCommon.php','require_once');

//add copy link along side the delete link

class AdminSiteList extends SiteListCommon{
	function Init(){
		$this->InitVars();

		//install for first time use
		$this->Install();
		//load existing lists
		$this->load_site_lists();
		//initialze database
		$this->InitDB();
		global $page,$addonRelativeCode;
		$page->css_admin[] = $addonRelativeCode.'/view/css/admin.css';
	}
	function Install(){
		global $addonPathData,$addonPathCode,$config;
		if (array_key_exists(self::config_version_key,$config)){
			$this->installed=True;
			return True;
		}
		
		//setup data dir structure 
		gpFiles::CheckDir($addonPathData.$this->addonPathData_PathCurrent);
		gpFiles::CheckDir($addonPathData.$this->addonPathData_PathSnapshot);
		//install database
		$this->InitDB();
		$this->db->Install();
		//finish Install
		//install normal admin controller, remove install one
		$config[self::config_version_key]=self::version;
		admin_tools::SaveConfig();
		return True;
/*
		$current_controller=__FILE__;
		$sitelist_admin_controller=$addonPathCode.'/AdminSiteList_Installed.php';
		rename($current_controller,$addonPathCode.'/AdminSiteList_Install.php');
		rename($sitelist_admin_controller,$current_controller);
		return True;
*/
	}

	function __construct(){
		global $langmessage;
      	$this->Init();

		$cmd = common::GetCommand();
		switch($cmd){

			//list commands
			case 'save_lists':
				$this->SaveLists();
				$this->AdminRedirect();
				return;
			break;
			case 'new_list':
				$this->NewList();
			return;
			case 'save_new_list':
				$this->SaveNewList();
				$this->AdminRedirect();
				return;
			break;
			case 'delete_list':
				$this->DeleteList();
				$this->AdminRedirect();
				return;
			break;
			case 'export_list':
				if (($index=$this->GetListIndex())!==false){
					$this->ExportList($index);
				}
			break;

			//field commands
			case 'edit_fields':
				if (($index=$this->GetListIndex())!==false){
					$this->EditFields($index);
					return;
				}
			break;
			case 'save_fields':
				if (($index=$this->GetListIndex())!==false){
					$this->SaveFields($index);    // -> 654
					$this->AdminRedirect();
					return;
				}
			break;
			case 'new_field':
				if (($index=$this->GetListIndex())!==false){
					$this->NewField($index);
				}
			return;
			case 'save_new_field':
				if (($index=$this->GetListIndex())!==false){
					$this->SaveNewField($index);
					$this->AdminRedirect('cmd=edit_fields&index='.$index);
					return;
				}
			break;
			case 'delete_field':
				if (($index=$this->GetListIndex())!==false){
					$this->DeleteField($index);
					$this->AdminRedirect('cmd=edit_fields&index='.$index);
					return;
				}
			break;

			//item commands
			case 'edit_items':
				if (($index=$this->GetListIndex())!==false){
					$this->EditItems($index);
					return;
				}
			break;
			case 'save_items':
				if (($index=$this->GetListIndex())!==false){
					$this->SaveItems($index);
					$this->AdminRedirect('cmd=edit_items&index='.$index);
					return;
				}
			break;
			case 'new_item':
				if (($index=$this->GetListIndex())!==false){
					$this->NewItem($index);
				}
			return;
			case 'save_new_item':
				if (($index=$this->GetListIndex())!==false){
					$this->SaveNewItem($index);
					$this->AdminRedirect('cmd=edit_items&index='.$index);
					return;
				}
			break;
			case 'delete_item':
				if (($index=$this->GetListIndex())!==false){
					$this->DeleteItem($index);
					$this->AdminRedirect('cmd=edit_items&index='.$index);
					return;
				}
			break;
			case 'edit_item':
				if (($index=$this->GetListIndex())!==false){
					$this->EditItem($index);
					return;
				}
			break;

			//view commands
			case 'edit_views':
				if (($index=$this->GetListIndex())!==false){
					$this->EditViews($index);
					return;
				}
			break;
			case 'save_views':
				if (($index=$this->GetListIndex())!==false){
					$this->SaveViews($index);
					$this->AdminRedirect();
					return;
				}
			break;
			case 'new_view':
				if (($index=$this->GetListIndex())!==false){
					$this->NewView($index);
				}
			return;
			case 'edit_view_listtemplate':
				if (($index=$this->GetListIndex())!==false){
					$this->EditViewListTemplate($index);
				//del	$this->AdminRedirect('cmd=edit_views&index='.$index);
					return;
				}
			return;
			case 'save_view_listtemplate':
				if (($index=$this->GetListIndex())!==false){
					$this->SaveViewListTemplate($index);
					$this->AdminRedirect('cmd=edit_views&index='.$index);
					return;
				}
			return;
			case 'edit_view_itemtemplate':
				if (($index=$this->GetListIndex())!==false){
					$this->EditViewItemTemplate($index);
					return;
				}
			return;
			case 'save_view_itemtemplate':
				if (($index=$this->GetListIndex())!==false){
					$this->SaveViewItemTemplate($index);
					$this->AdminRedirect('cmd=edit_views&index='.$index);
					return;
				}
			return;
			case 'save_new_view':
				if (($index=$this->GetListIndex())!==false){
					$this->SaveNewView($index);
					$this->AdminRedirect('cmd=edit_views&index='.$index);
					return;
				}
			break;
			case 'preview_view':
				if (($index=$this->GetListIndex())!==false){
					$this->PreviewView($index);
					return;
				}
			break;
			case 'delete_view':
				if (($index=$this->GetListIndex())!==false){
					$this->DeleteView($index);
					$this->AdminRedirect('cmd=edit_views&index='.$index);
					return;
				}
			break;
			case 'sitelist_browser':
				gpPlugin::incl('controller/lib/sitelist_browser.php','require_once');
				new sitelist_browser();
			return;

			//site list view type section commands
			case 'editview_dialog':
				gpPlugin::incl('controller/SiteListViewSectionType.php','require_once');
				SiteListViewSectionType::EditDialog();
			return;
			case 'editview_preview':
				gpPlugin::incl('controller/SiteListViewSectionType.php','require_once');
				SiteListViewSectionType::PreviewSection();
			return;

			//site list gadget
			case 'inlineedit':
				gpPlugin::incl('controller/SiteListGadget.php','require_once');
				SiteListGadget::InlineEdit();
			die();
			case 'gadget_dialog':
				gpPlugin::incl('controller/SiteListGadget.php','require_once');
				SiteListGadget::InlineEditDialog();
			return;
			case 'save':
				gpPlugin::incl('controller/SiteListGadget.php','require_once');
				SiteListGadget::InlineSave();
			return;
		}



		/*
		if( isset($_POST['save_items']) ){
			foreach( $this->lists as $catindex => $catdata){
				$clean = array( 'name'=>$catdata['name'], 'visible'=>$catdata['visible']);
				$this->lists[$catindex] = $clean; //clean lists
			}
			foreach( $this->itlist as $itemindex => $itemdata){
				if( isset($_POST['item'.$itemindex]) ){
					foreach ($_POST['item'.$itemindex] as $catindex){
						$this->lists[$catindex][$itemindex] = $itemdata['title'];
					}
				}
			}

			return $this->save_site_lists();
		}
		*/

		//$label = gpOutput::SelectText('List');
		echo '<h2>';
		//echo common::Link('SiteList',$label);
		//echo ' &#187; ';
		//echo common::Link('Admin_List','Configuration');
		//echo ' &#187; ';
		echo 'Site List</h2>';

		// print all lists and settings
		//echo '<h3>Existing Lists (empty field removes list)</h3>';

		echo '<form name="lists" action="'.common::GetUrl('Admin_SiteList').'" method="post">';
		echo '<table class="bordered">';
		echo '<tr><th>Name</th><th># of<br>Items</th><th># of<br>Views</th><th>Visible</th><th># of<br>Fields</th><th>Slug</th><th>Options</th></tr>';
		foreach( $this->lists as $catindex => $catdata ){
			echo '<tr><td>';
			echo '<input type="text" name="cattitle'.$catindex.'" value="'.$catdata['name'].'" class="gpinput" />';
			echo '</td><td>';
			if (count($catdata['fields'])>0){
				echo common::Link('Admin_SiteList',$this->db->ItemCount($catindex),'cmd=edit_items&index='.$catindex,' name="itemlink" ');
			}else{
				echo common::Link('Admin_SiteList','Add fields','cmd=edit_fields&index='.$catindex,' name="itemlink" ');
			}
			echo '</td><td>';
			echo common::Link('Admin_SiteList',count($catdata['views']),'cmd=edit_views&index='.$catindex,' name="itemlink" ');
			echo '</td><td>';
			echo ' <input type="checkbox" name="catvis'.$catindex.'"'.($catdata['visible']?' checked="checked"':'').' /> ';
			echo '</td><td>';
			echo common::Link('Admin_SiteList',count($catdata['fields']),'cmd=edit_fields&index='.$catindex,' name="itemlink" ');
			echo '</td><td>';
			echo '<input type="text" name="catslug'.$catindex.'" value="'.$catdata['slug'].'" class="gpinput" />';
			echo '</td><td>';
			echo common::Link('Admin_SiteList',$langmessage['delete'],'cmd=delete_list&index='.$catindex,' name="itemlink" class="gpconfirm" title="Delete this List?" ');
			echo '<br>';
			echo common::Link('Admin_SiteList','Export','cmd=export_list&index='.$catindex,' name="itemlink" ');
			echo '</td></tr>';
		}
		echo '</table>';
		echo '<p>';
		echo '<input type="hidden" name="cmd" value="save_lists" />';
		echo '<input type="submit" value="'.$langmessage['save_changes'].'" class="gpsubmit"/>';
		echo ' &nbsp; ';
		echo common::Link('Admin_SiteList','Add New List','cmd=new_list',' name="gpabox" data-cmd="gpabox" ');
		//echo common::Link('Admin_SiteList','Add New List','cmd=new_list',' name="admin_box" ');
		echo '</p>';
		echo '</form>';

		// print all items
		/*
		if( count($this->itlist) ){
			echo '<h3 onclick="$(this).next(\'form\').toggle()" style="cursor:pointer">All List Items</h3>';
			echo '<form name="allitems" action="'.common::GetUrl('Admin_SiteList').'" method="post" style="display:none">';
			echo '<table style="width:100%">';
			foreach( $this->itlist as $itemindex => $itemdata ){
				echo '<tr><td>'.$itemdata['title'].' ';
				echo common::Link('SiteList','&#187;','id='.$itemindex,'target="_blank"').'</td><td>';
				echo '<select id="item'.$itemindex.'" name="item'.$itemindex.'[]" multiple="multiple" class="gpselect">';
				foreach( $this->lists as $catindex => $catdata){
					echo '<option value="'.$catindex.'" '.(isset($catdata[$itemindex])? 'selected="selected"':'').'>'.$catdata['name'].'</option>';
				}
				echo '</select>';
				echo '</td></tr>';
			}
			echo '</table>';
			echo '<input name="save_items" type="submit" value="'.$langmessage['save'].'" class="gpsubmit" />';
			echo '</form>';
		}
		*/

		// archives
		//echo '<br/><h2>Export</h2>';
		//echo common::Link('Admin_SiteList','Fill archive with all items','cmd=fill_archive',' name="cnreq"').'<br/>';
		//echo common::Link('Admin_SiteList','Clear all items from archive','cmd=clear_archive',' name="cnreq"');
	}

	/*
	Prevent double form submission
	*/
	function AdminRedirect($query=''){
		global $wbMessageBuffer;
		if (!isset($wbMessageBuffer) ||(isset($wbMessageBuffer) && !count($wbMessageBuffer))) {
			common::Redirect(common::GetUrl('Admin_SiteList',$query,false));
		}
		//echo 'error'.$this->db->error();
	}

	function PreviewView($list_index){
		global $langmessage;
		$view_index=$this->GetIndex('viewindex',$this->lists[$list_index]['views']);
		if ($view_index===false) return;

		echo $this->RenderView($view_index,$list_index);
	}
	/**
	 * Add a new view to the list 
	 *
	 */
	function SaveViewItemTemplate($list_index){
		global $langmessage;
		$view_index=$this->GetIndex('viewindex',$this->lists[$list_index]['views']);
		if ($view_index===false) return;
		$item_index=$this->GetIndex('itemindex',$this->lists[$list_index]['views'][$view_index]['items']);
		if ($item_index===false) return;

		$content =& $_POST['gpcontent'];
		gpFiles::cleanText($content);

		$this->lists[$list_index]['views'][$view_index]['items'][$item_index]['table'] = $list_index;
		$this->lists[$list_index]['views'][$view_index]['items'][$item_index]['template'] = $content;
		if (!isset($this->lists[$list_index]['views'][$view_index]['items'][$item_index]['order']) || count($this->lists[$list_index]['views'][$view_index]['items'][$item_index]['order'])==0) {
			$this->lists[$list_index]['views'][$view_index]['items'][$item_index]['order']=array(0=>array(),1=>array());
		}
		$order=explode('.',$_POST['order0']);
		$this->lists[$list_index]['views'][$view_index]['items'][$item_index]['order'][0]['key'] = $order[0];
		$this->lists[$list_index]['views'][$view_index]['items'][$item_index]['order'][0]['asc'] = $order[1];
		$order=explode('.',$_POST['order1']);
		$this->lists[$list_index]['views'][$view_index]['items'][$item_index]['order'][1]['key'] = $order[0];
		$this->lists[$list_index]['views'][$view_index]['items'][$item_index]['order'][1]['asc'] = $order[1];
		$this->lists[$list_index]['views'][$view_index]['items'][$item_index]['limit'] = (int)$_POST['limit'];

		$this->WriteViewTemplateCache($list_index,$view_index);
		return $this->save_site_lists();
	}
	/**
	 * Add a new view to the list 
	 *
	 */
	function SaveViewListTemplate($list_index){
		global $langmessage;
		$view_index=$this->GetViewIndex($list_index);
		if (!$view_index) return;

		$content =& $_POST['gpcontent'];
		gpFiles::cleanText($content);

		$this->lists[$list_index]['views'][$view_index]['list'] = $content;
		$this->lists[$list_index]['views'][$view_index]['pagination_size'] = (int)$_POST['pagination_size'];
		$this->lists[$list_index]['views'][$view_index]['pagination_start'] = (int)$_POST['pagination_start'];

		$this->WriteViewTemplateCache($list_index,$view_index);
		return $this->save_site_lists();
	}
	/**
	 * Prompt user to create a new view 
	 *
	 */
	function EditViewItemTemplate($list_index){
		global $langmessage;
		$view_index=$this->GetIndex('viewindex',$this->lists[$list_index]['views']);
		if ($view_index===false) return;
		$item_index=$this->GetIndex('itemindex',$this->lists[$list_index]['views'][$view_index]['items']);
		if ($item_index===false) return;

		$data = $this->lists[$list_index]['views'][$view_index]['items'][$item_index];
		echo '<div class="inline_box">';
		echo '<h3>Edit View Item Template</h3>';
		echo '<form name="addview" action="'.common::GetUrl('Admin_SiteList').'" method="post">';
		echo '<p>';
		echo '<input type="hidden" name="cmd" value="save_view_itemtemplate" />';
		echo '<input type="hidden" name="index" value="'.$list_index.'" />';
		echo '<input type="hidden" name="viewindex" value="'.$view_index.'" />';
		echo '<input type="hidden" name="itemindex" value="'.$item_index.'" />';
		echo 'Placeholders: ';
		foreach ($this->lists[$list_index]['fields'] as $key=>$column) {
			echo '{{'.$column['slug'].'}},';
		}
		//what about abreviation
		$template=isset($data['template'])?$data['template']:'&nbsp;';//default template
		gp_edit::UseCK( $template );
		//gp_edit::UseCK( $data['template'] );
		echo '</p>';
		echo '<p>';
		echo 'Order:';
		echo '<select name="order0">';
			echo '<option value=".">Select Order 1</option>';
			$order_key=null;
			if (isset($data['order'][0])) {
				$order_key=$data['order'][0]['key'];
				$order_asc=$data['order'][0]['asc'];
			}
		//foreach ($this->lists[$list_index]['fields'] as $key=>$column) {
		foreach (array('id'=>array('name'=>'ID'))+$this->lists[$list_index]['fields'] as $key=>$column) {
			$selected='';
			if ($order_key==$key && $order_asc) {
				$selected=' selected';
			}
			echo '<option value="'.$key.'.1"'.$selected.'>'.$column['name'].' ASC</option>';
			$selected='';
			if ($order_key==$key && !$order_asc) {
				$selected=' selected';
			}
			echo '<option value="'.$key.'.0"'.$selected.'>'.$column['name'].' DESC</option>';
		}
		echo '</select>,';
		echo '<select name="order1">';
			echo '<option value=".">Select Order 2</option>';
			$order_key=null;
			if (isset($data['order'][1])) {
				$order_key=$data['order'][1]['key'];
				$order_asc=$data['order'][1]['asc'];
			}
		foreach (array('id'=>array('name'=>'ID'))+$this->lists[$list_index]['fields'] as $key=>$column) {
			$selected='';
			if ($order_key==$key && $order_asc) {
				$selected=' selected';
			}
			echo '<option value="'.$key.'.1"'.$selected.'>'.$column['name'].' ASC</option>';
			$selected='';
			if ($order_key==$key && !$order_asc) {
				$selected=' selected';
			}
			echo '<option value="'.$key.'.0"'.$selected.'>'.$column['name'].' DESC</option>';
		}
		echo '</select>,';
		echo '</p>';
		echo '<p>';
		echo 'Limit:';
		echo '<select name="limit">';
			echo '<option value="">All</option>';
			$limit=null;
			if (!empty($data['limit'])) {
				$limit=$data['limit'];
			}
		for($i=0;$i<=50;$i++) {
			$selected='';
			if ($limit==$i) {
				$selected=' selected';
			}
			echo '<option value="'.$i.'"'.$selected.'>'.$i.'</option>';
		}
		echo '</select> ';
		echo 'items';
		echo '</p>';

		echo '<p>';
		echo ' <input type="submit" value="'.$langmessage['save'].'" class="gpitem gpsubmit"/>';
		echo ' <input type="submit" name="cmd" value="'.$langmessage['cancel'].'" class="admin_box_close gpcancel"/>';
		echo '</p>';
		echo '</form>';
		echo '</div>';
	}
	/**
	 * Prompt user to create a new view 
	 *
	 */
	function EditViewListTemplate($list_index){
		global $langmessage;
		$view_index=$this->GetViewIndex($list_index);
		if (!$view_index) return;

		$data = $this->lists[$list_index]['views'][$view_index];
		echo '<div class="inline_box">';
		echo '<h3>Edit View List Template</h3>';
		echo '<form name="addview" action="'.common::GetUrl('Admin_SiteList').'" method="post">';
		echo '<p>';
		echo '<input type="hidden" name="cmd" value="save_view_listtemplate" />';
		echo '<input type="hidden" name="index" value="'.$list_index.'" />';
		echo '<input type="hidden" name="viewindex" value="'.$view_index.'" />';
		echo 'Placeholders: {{list}}, {{pagination}}, ';//{{comments}}
		//what about abreviation
		gp_edit::UseCK( $data['list'] );
		echo '</p>';
		echo '<p>';
		echo 'Pagination:';
		echo '</p>';
		echo '<p>';
		//echo 'Items per page (-1 for all):<input type="text" name="pagination_size" value="'.$data['pagination_size'].'" class="gpinput" />';
		echo 'Items per page:';
		echo '<select name="pagination_size">';
		for($i=-1;$i<=50;$i++) {
			$selected='';
			if ($data['pagination_size']==$i) {
				$selected=' selected';
			}
			echo '<option value="'.$i.'"'.$selected.'>'.($i==-1?'All':$i).'</option>';
		}
		echo '</select> ';
		echo '</p>';
		echo '<p>';
		//echo 'Start on page:<input type="text" name="pagination_start" value="'.($data['pagination_start']+1).'" class="gpinput" />';
		echo 'Start on page:';
		echo '<select name="pagination_start">';
		for($i=0;$i<50;$i++) {
			$selected='';
			if ($data['pagination_start']==$i) {
				$selected=' selected';
			}
			echo '<option value="'.$i.'"'.$selected.'>'.($i+1).'</option>';
		}
		echo '</select> ';
		echo '</p>';

		echo '<p>';
		echo ' <input type="submit" value="'.$langmessage['save'].'" class="gpitem gpsubmit"/>';
		echo ' <input type="submit" name="cmd" value="'.$langmessage['cancel'].'" class="admin_box_close gpcancel"/>';
		echo '</p>';
		echo '</form>';
		echo '</div>';
	}

	/**
	 * Save changes to the list of existing lists
	 *
	 */
	function SaveLists(){

		foreach( $this->lists as $catindex => $catdata ){
			if( isset($_POST['cattitle'.$catindex]) ){
				$this->lists[$catindex]['visible'] = isset($_POST['catvis'.$catindex]);
				$title = trim($_POST['cattitle'.$catindex]);
				if( !empty($title) ){
					$this->lists[$catindex]['name'] = htmlspecialchars($title);
				}
				$slug = trim($_POST['catslug'.$catindex]);
				if( !empty($slug) ){
					$this->lists[$catindex]['slug'] = htmlspecialchars($slug);
				}
			}
		}

		return $this->save_site_lists();
	}
	/**
	 * Save changes to the fields of an existing list
	 *
	 */
	function SaveViews($list_index){

		foreach( $this->lists[$list_index]['views'] as $index => $data ){
			if( isset($_POST['name'.$index]) ){
				$this->lists[$list_index]['views'][$index]['visible'] = isset($_POST['vis'.$index]);
				$name = trim($_POST['name'.$index]);
				if( !empty($name) ){
					$this->lists[$list_index]['views'][$index]['name'] = htmlspecialchars($name);
				}
				$slug = trim($_POST['slug'.$index]);
				if( !empty($slug) ){
					$this->lists[$list_index]['views'][$index]['slug'] = htmlspecialchars($slug);
				}
			}
		}

		return $this->save_site_lists();
	}
	/**
	 * Save changes to the items of an existing list
	 *
	 */
	function SaveItems($list_index){
		$ids=explode(',',$_REQUEST['ids']);
		foreach($ids as $id){
			$this->SaveItem($list_index,$id);
		}
	}
	/**
	 * Save changes to the items of an existing list
	 *
	 */
	function SaveItem($list_index,$id){
		$values=array();
		//$columns=array_keys($this->lists[$list_index]['fields']);
		//array_unshift($columns,'id');
		//$slugs=array();
		foreach ($this->lists[$list_index]['fields'] as $index=>$data) {
			if (isset($_REQUEST[$data['slug'].$id])) {
				$values[$index]=$_REQUEST[$data['slug'].$id];
			}
		}
		$this->db->UpdateItem($id,$values,$this->lists[$list_index]['fields']);
		//message('saving');
	}
	/**
	 * Save changes to the fields of an existing list
	 *
	 */
	function SaveFields($list_index){

		foreach( $this->lists[$list_index]['fields'] as $index => $data ){
			if( isset($_POST['title'.$index]) ){
				$this->lists[$list_index]['fields'][$index]['visible'] = isset($_POST['vis'.$index]);
				$title = trim($_POST['title'.$index]);
				if( !empty($title) ){
					$this->lists[$list_index]['fields'][$index]['name'] = htmlspecialchars($title);
				}
				$slindex = 'slug'.$index ?? null; //Undefined array key "$slindex"
				$slug = trim($_POST[''.'$slindex']);   // Undefined array key "sluga" (also slugb slugc slugd) --> line 89
				if( !empty($slug) ){
					$this->lists[$list_index]['fields'][$index]['slug'] = htmlspecialchars($slug);
				}
				$slug = trim($_POST['tip'.$index]);
				if( !empty($slug) ){
					$this->lists[$list_index]['fields'][$index]['tip'] = htmlspecialchars($slug);
				}
			}
		}

		return $this->save_site_lists();
	}


	/**
	 * Add a new item to the list 
	 *
	 */
	function SaveNewItem($table){
		global $langmessage;
		//set defaults
		if (empty($_POST['date'])) {//date
			$_POST['date']=date("Y-m-d H:i:s");
		}
		if (empty($_POST['slug'])) {//slug
			$_POST['slug']=$this->GetSlug($_POST['title']);
		}

		//gather values
		$columns=array_keys($this->lists[$table]['fields']);
		$fields=$this->lists[$table]['fields'];
		$values=array();
		foreach($columns as $key=>$colkey){
			$values[$colkey]=trim($_POST[$fields[$colkey]['slug']]) OR 'NULL';
		}

		//save
		$this->db->AddItem($table,$fields,$values);
		//if ($this->db->query('INSERT INTO '.$table.' ('.implode(',',$columns).') VALUES (\''.implode('\',\'',$values).'\') ') or message($this->db->error())){
		//}
	}
	/**
	 * Add a new view to the list 
	 *
	 */
	function SaveNewView($list_index){
		global $langmessage;

		//find free index
		$new_index = $this->NewViewIndex($list_index);

		$new_title = htmlspecialchars(trim($_POST['new_view']));
		if( empty($new_title) ){
			message($langmessage['OOPS'].' (Empty view name)');
			return false;
		}

		$this->lists[$list_index]['views'][$new_index]['name'] = $new_title;
		//$this->lists[$list_index]['views'][$new_index]['type'] = $_POST['new_type'];
		$this->lists[$list_index]['views'][$new_index]['slug'] = $this->GetSlug($new_title);
		$this->lists[$list_index]['views'][$new_index]['visible'] = true;
		$this->lists[$list_index]['views'][$new_index]['list'] = '';
		$this->lists[$list_index]['views'][$new_index]['pagination_size'] = -1;
		$this->lists[$list_index]['views'][$new_index]['pagination_start'] = 0;
		$this->lists[$list_index]['views'][$new_index]['items'] = array(array());
		//$this->db->AddView($list_index,$new_index, $this->lists[$list_index]['views'][$new_index]['type']);

		return $this->save_site_lists();
	}
	/**
	 * Add a new field to the list 
	 *
	 */
	function SaveNewField($list_index){
		global $langmessage;

		//find free index
		$new_index = $this->NewFieldIndex($list_index);

		$new_title = htmlspecialchars(trim($_POST['new_field']));
		if( empty($new_title) ){
			message($langmessage['OOPS'].' (Empty field name)');
			return false;
		}

		$this->lists[$list_index]['fields'][$new_index]['name'] = $new_title;
		$this->lists[$list_index]['fields'][$new_index]['type'] = (int)$_POST['new_type'];
		$this->lists[$list_index]['fields'][$new_index]['slug'] = $this->GetSlug($new_title);
		$this->lists[$list_index]['fields'][$new_index]['visible'] = true;
		$this->lists[$list_index]['fields'][$new_index]['tip'] = '';
		$this->lists[$list_index]['fields'][$new_index]['validation'] = array();
		$this->lists[$list_index]['fields'][$new_index]['table'] = $list_index;
		$this->db->AddField($list_index,$new_index, $this->lists[$list_index]['fields'][$new_index]['type']);

		return $this->save_site_lists();
	}
	/**
	 * Add a new list to the configuration
	 *
	 */
	function SaveNewList(){
		global $langmessage;

		//find free index
		$new_index = $this->NewCatIndex();

		$new_title = htmlspecialchars(trim($_POST['new_list']));
		if( empty($new_title) ){
			message($langmessage['OOPS'].' (Empty list name)');
			return false;
		}

		$this->lists[$new_index] = array();
		$this->lists[$new_index]['name'] = $new_title;
		$this->lists[$new_index]['slug'] = $this->GetSlug($new_title);
		$this->lists[$new_index]['visible'] = true;
		$this->lists[$new_index]['items'] = array();
		$this->lists[$new_index]['fields'] = $this->db->DefaultListFields;//array();
		$this->lists[$new_index]['views'] = $this->GetDefaultViews();// array(0=>array());
		
		$this->db->CreateTable($new_index);

		return $this->save_site_lists();
	}



	/**
	 * Prompt user to edit an item
	 *
	 */
	function EditItem($list_index){
		global $page;
		if( !isset($_GET['itemindex']) ){
			message($langmessage['OOPS'].' (Invalid Index)');
			return false;
		}
		$itemIndex = (int)$_GET['itemindex'];
		$columns=array_keys($this->lists[$list_index]['fields']);
		$rows=$this->db->SelectItem($list_index,$itemIndex,$columns);
		$row=$this->db->fetch_row($rows);
		$id=$row[0];
		global $langmessage;

		$template=array();
		$template[]='';//'<span title="%2$d">%3$d</span>';//ID
		$browserinit=false;
		foreach( $this->lists[$list_index]['fields'] as $index => $data ){
			switch($data['type']){
				case 1:	
					ob_start();
					echo $data['name'].': ';
					gp_edit::UseCK( '%2$s', $data['slug'].'%1$s' );
					$template[]=ob_get_clean();
				break;
				case 2:
					//$template[]=$data['name'].': <input type="text" name="'.$data['slug'].'%1$s" value="%2$s" class="gpinput" /> <a target="new" name="gpabox" data-cmd="gpabox" href="'.common::GetUrl('Admin_Browser').'?type=all'.'">Select</a>';
					//$browserid='browserlink'.count($browserinit).'';
					//$template[]=$data['name'].': <input id="'.$browserid.'input" type="text" name="'.$data['slug'].'%1$s" value="%2$s" class="gpinput" /> <a id="'.$browserid.'" target="new" href="'.common::GetUrl('Admin_Browser').'?type=all'.'">Select</a>';
					//$browserinit[]=$browserid;
					//$template[]=$data['name'].': <input type="text" name="'.$data['slug'].'%1$s" value="%2$s" class="gpinput" /> <a target="new" href="'.common::GetUrl('Admin_SiteList').'?cmd=sitelist_browser&type=all'.'">Select</a>';
					//$template[]=$data['name'].': <input id="browserlink%1$sinput" style="width:75%%" type="text" name="'.$data['slug'].'%1$s" value="%2$s" class="gpinput" /> <a id="browserlink%1$s" class="browserinit" target="new" href="'.common::GetUrl('Admin_Browser').'?type=all'.'">Select</a>';
					$template[]=$data['name'].': <input id="browserlink%3$s-%4$sinput" style="width:75%%" type="text" name="'.$data['slug'].'%1$s" value="%2$s" class="gpinput" /> <a id="browserlink%3$s-%4$s" class="browserinit" target="new" href="'.common::GetUrl('Admin_Browser').'?type=all'.'">Select</a>';
					$browserinit=true;
				break;
				default:
					$template[]=$data['name'].': <input type="text" name="'.$data['slug'].'%1$s" value="%2$s" class="gpinput" />';
			}
		}

		echo '<div class="inline_box">';
		echo '<h3>Edit Item ('.$id.')</h3>';
		echo '<form name="addfield" action="'.common::GetUrl('Admin_SiteList').'" method="post">';
		echo '<input type="hidden" name="cmd" value="save_items" />';
		echo '<input type="hidden" name="index" value="'.$list_index.'" />';
		echo ' <input type="hidden" name="ids" value="'.$id.'" />';
			$colcount=1;
			foreach ($row as $index=>$col){
				echo '<p>';
				echo sprintf($template[$index],$id,$col,1,$colcount);
				echo '</p>';
				$colcount++;
			}
		echo '<p>';
		echo ' <input type="submit" value="'.$langmessage['save'].'" class="gpitem gpsubmit"/>';
		echo ' <input type="submit" name="cmd" value="'.$langmessage['cancel'].'" class="admin_box_close gpcancel"/>';
		echo '</p>';
		echo '</form>';
		echo '</div>';

		//browser init
		if ($browserinit) {
			$page->head_script .= "\n".'
function browserinit(){
	if (!window.CKEDITOR){
		window.CKEDITOR={functions:[],tools:{callFunction:function (index,params){var g=CKEDITOR.functions[index];return g&&g.apply(window,[[params]]);},addFunction:function(func,g){return CKEDITOR.functions.push(function(params){return func.apply(g||this,params);})-1;}}}
	}
	$(".browserinit").each(function(){
		var ref = CKEDITOR.tools.addFunction( function(a) {
			this.val(a);
		},$("#"+$(this).prop("id")+"input") );
		var href=$(this).prop("href");
		$(this).prop("href",href+"&CKEditorFuncNum="+ref);
	});
}
jQuery(function($){
	browserinit();
});
';
		}
		$this->db->free_result($rows);
	}

	function GetDefaultViews(){
		return array();
	}

	function GetSlug($name){
		return strtolower(str_replace(' ','-',$name));
	}

	var $FieldTypes=array(0=>'Text',1=>'Text Area',2=>'Site File',3=>'Hidden',4=>'Date/Time',5=>'Number',6=>'Decimal');
	var $ViewTypes=array(0=>'Display');//,1=>'Form');

	function UseCKPrep($options=array()){
		global $page;
		$page->head .= "\n".'<script type="text/javascript" src="'.common::GetDir('/include/thirdparty/ckeditor_34/ckeditor.js').'?'.rawurlencode(gpversion).'"></script>';
		$page->head .= "\n".'<script type="text/javascript" src="'.common::GetDir('/include/js/ckeditor_config.js').'?'.rawurlencode(gpversion).'"></script>';

		ob_start();
		echo "\n\n";

		// extra plugins
		$config = gp_edit::CKConfig( $options, 'json', $plugins );
		foreach($plugins as $plugin => $plugin_path){
			echo 'CKEDITOR.plugins.addExternal('.json_encode($plugin).','.json_encode($plugin_path).');';
			echo "\n";
		}

		echo 'window.sitelist_loadck =function () {$(".CKEDITAREA").each(function(){';
		echo 'CKEDITOR.replace( this, '.$config.' );';
		echo '});}';

		echo "\n\n";
		$page->jQueryCode .= ob_get_clean();
	}
	/**
	 * Prompt user to edit list views 
	 *
	 */
	function EditViews($list_index){
		global $langmessage;
		//$this->UseCKPrep();
		echo '<h2>';
		echo common::Link('Admin_SiteList','Site List');
		echo ' &#187; ';
		echo $this->lists[$list_index]['name'];
		echo ' &#187; ';
		echo ' Views</h2>';

		echo '<form name="lists" action="'.common::GetUrl('Admin_SiteList').'" method="post">';
		echo '<table class="bordered">';
		echo '<tr><th>Name</th><th>Slug</th><th>Visible</th><th>List<br>Template</th><th>Item Templates</th><th>Options</th></tr>';
		foreach( $this->lists[$list_index]['views'] as $index => $data ){
			echo '<tr><td>';
			echo '<input type="text" name="name'.$index.'" value="'.$data['name'].'" class="gpinput" />';
			echo '</td><td>';
			echo '<input type="text" name="slug'.$index.'" value="'.$data['slug'].'" class="gpinput" />';
			echo '</td><td>';
			echo '<input type="checkbox" name="vis'.$index.'"'.($data['visible']?' checked="checked"':'').' /> ';
			//echo '</td><td>';
			//echo $this->ViewTypes[$data['type']];
			echo '</td><td>';
			echo common::Link('Admin_SiteList','Edit','cmd=edit_view_listtemplate&index='.$list_index.'&viewindex='.$index,' name="itemlink" ');
			echo '</td><td>';
			echo common::Link('Admin_SiteList','Edit','cmd=edit_view_itemtemplate&index='.$list_index.'&viewindex='.$index.'&itemindex=0',' name="itemlink" ');
			echo '</td><td>';
			echo common::Link('Admin_SiteList',$langmessage['delete'],'cmd=delete_view&index='.$list_index.'&viewindex='.$index,' name="itemlink" class="gpconfirm" title="Delete this View?" ');
			echo '<br>';
			echo common::Link('Admin_SiteList','Preview','cmd=preview_view&index='.$list_index.'&viewindex='.$index,' name="itemlink" ');
			echo '</td></tr>';
		}
		echo '</table>';
		echo '<p>';
		echo '<input type="hidden" name="cmd" value="save_views" />';
		echo '<input type="hidden" name="index" value="'.$list_index.'" />';
		echo '<input type="submit" value="'.$langmessage['save_changes'].'" class="gpsubmit"/>';
		echo ' &nbsp; ';
		echo common::Link('Admin_SiteList','Add New View','cmd=new_view&index='.$list_index,' data-cmd="gpabox" ');
		//echo common::Link('Admin_SiteList','Add New View','cmd=new_view',' name="admin_box" ');
		echo ' &nbsp; ';
		echo common::Link('Admin_SiteList','< Back');
		echo '</p>';
		echo '</form>';
	}

	/**
	 * Prompt user to edit list fields
	 *
	 */
	//paginate
	function EditItems($list_index){
		global $langmessage,$page;
		echo '<h2>';
		echo common::Link('Admin_SiteList','Site List');
		echo ' &#187; ';
		echo $this->lists[$list_index]['name'];
		echo ' &#187; ';
		echo ' Items</h2>';

		$header='<tr><th>ID</th>';
		$template=array();
		$template[]='<span title="%2$d">%3$d</span>';//ID
		$browserinit=false;
		foreach( $this->lists[$list_index]['fields'] as $index => $data ){
			$header.='<th>'.$data['name'].'</th>';
			switch($data['type']){
				case 1:	
					ob_start();
				//	gp_edit::UseCK( '%1$s', $data['slug'].'%2$s' );
					$template[]=ob_get_clean();
				break;
				case 2:
					$template[]=$data['name'].': <input id="browserlink%3$s-%4$sinput" type="text" name="'.$data['slug'].'%1$s" value="%2$s" class="gpinput" /> <a id="browserlink%3$s-%4$s" class="browserinit" target="new" href="'.common::GetUrl('Admin_Browser').'?type=all'.'">Select</a>';
					$browserinit=true;
				break;
				default:
					$template[]='<input type="text" name="'.$data['slug'].'%1$s" value="%2$s" class="gpinput" />';
			}
		}
		$header.='<th>Options</th></tr>';
		echo '<form name="lists" action="'.common::GetUrl('Admin_SiteList').'" method="post">';
		echo '<div class="tablewrapper"><table class="bordered" id="sitelist-items-table">';
		echo $header;

		$columns=array_keys($this->lists[$list_index]['fields']);
		$rows=$this->db->SelectItems($list_index,$columns);//,implode(',',$columns),0);
		$rowcount=1;
		$ids=array();
		while($row = $this->db->fetch_row($rows)){
			echo '<tr>';
			$id=$row[0];
			$ids[]=$id;
			$colcount=1;
			foreach ($row as $index=>$col){
				echo '<td>';
				echo sprintf($template[$index],$id,$col,$rowcount,$colcount);
				echo '</td>';
				$colcount++;
			}
			echo '<td>';
			echo common::Link('Admin_SiteList',$langmessage['delete'],'cmd=delete_item&index='.$list_index.'&itemindex='.$id,' name="itemlink" class="gpconfirm" title="Delete this Field?" ');
			echo '<br/>';
			echo common::Link('Admin_SiteList',$langmessage['edit'],'cmd=edit_item&index='.$list_index.'&itemindex='.$id,' name="itemlinkedit" title="Edit this item." ');
			echo '</td></tr>';
			$rowcount++;
		}
/*
			echo '<tr id="sitelist-new-item">';
			foreach ($columns as $index=>$col){
				echo '<td>';
				echo sprintf($template[$index],$index,'');
				echo '</td>';
			}
			echo '<td>';
			echo common::Link('Admin_SiteList',$langmessage['delete'],'',' name="itemlink" class="gpconfirm delete-item" title="Delete this Field?" ');
			echo '</td></tr>';
*/
		echo '</table></div>';
		echo '<p>';
		echo '<input type="hidden" name="cmd" value="save_items" />';
		echo '<input type="hidden" name="index" value="'.$list_index.'" />';
		echo '<input type="hidden" name="ids" value="'.implode(',',$ids).'" />';
		echo '<input type="submit" value="'.$langmessage['save_changes'].'" class="gpsubmit"/>';
		echo ' &nbsp; ';
		//echo '<a id="sitelist-add-new-item" href="#">Add New Item</a>';
		echo common::Link('Admin_SiteList','Add New Item','cmd=new_item&index='.$list_index);
		//echo common::Link('Admin_SiteList','Add New Item','cmd=new_item&index='.$list_index,' data-cmd="gpabox" ');
		//echo common::Link('Admin_SiteList','Add New Item','cmd=new_item',' name="admin_box" ');
		echo ' &nbsp; ';
		echo common::Link('Admin_SiteList','< Back');
		echo '</p>';
		echo '</form>';
/*
		echo '<script>$(function(){
$("#sitelist-add-new-item").on("click",function(){
	$("#sitelist-items-table tbody").append($("#sitelist-new-item").clone());
	return false;
});
}); </script>';
*/
		//browser init
		if ($browserinit) {
			$page->head_script .= "\n".'
function browserinit(){
	if (!window.CKEDITOR){
		window.CKEDITOR={functions:[],tools:{callFunction:function (index,params){var g=CKEDITOR.functions[index];return g&&g.apply(window,[[params]]);},addFunction:function(func,g){return CKEDITOR.functions.push(function(params){return func.apply(g||this,params);})-1;}}}
	}
	$(".browserinit").each(function(){
		var ref = CKEDITOR.tools.addFunction( function(a) {
			this.val(a);
		},$("#"+$(this).prop("id")+"input") );
		var href=$(this).prop("href");
		$(this).prop("href",href+"&CKEditorFuncNum="+ref);
	});
}
jQuery(function($){
	browserinit();
});
';
		}
		$this->db->free_result($rows);
	}


	/**
	 * Prompt user to edit list fields
	 *
	 */
	function EditFields($list_index){
		global $langmessage;
		echo '<h2>';
		echo common::Link('Admin_SiteList','Site List');
		echo ' &#187; ';
		echo $this->lists[$list_index]['name'];
		echo ' &#187; ';
		echo ' Fields</h2>';

		echo '<form name="lists" action="'.common::GetUrl('Admin_SiteList').'" method="post">';
		echo '<div class="tablewrapper"><table class="bordered">';
		echo '<tr><th>Name</th><th>Slug</th><th>Visible</th><th>Validation</th><th>Type</th><th>Tip</th><th>Options</th></tr>';
		foreach( $this->lists[$list_index]['fields'] as $index => $data ){
			if (isset($data['table']) && $data['table']==AdminSiteListModel::SiteListTableName) {
			echo '<tr><td>';
			echo '<input type="text" name="title'.$index.'" value="'.$data['name'].'" class="gpinput" />';
			echo '</td><td>';
			echo $data['slug'];
			echo '</td><td>';
			echo '<input type="checkbox" name="vis'.$index.'"'.($data['visible']?' checked="checked"':'').' /> ';
			echo '</td><td>';
			echo '<input type="checkbox" name="vis'.$index.'"'.($data['visible']?' checked="checked"':'').' /> ';
			echo '</td><td>';
			echo $this->FieldTypes[$data['type']];
			echo '</td><td>';
			echo '<input type="text" name="tip'.$index.'" value="'.$data['tip'].'" class="gpinput" />';
			echo '</td><td>';
			echo '</td></tr>';
				
			}else {
				
			echo '<tr><td>';
			echo '<input type="text" name="title'.$index.'" value="'.$data['name'].'" class="gpinput" />';
			echo '</td><td>';
			echo '<input type="text" name="slug'.$index.'" value="'.$data['slug'].'" class="gpinput" />';
			echo '</td><td>';
			echo '<input type="checkbox" name="vis'.$index.'"'.($data['visible']?' checked="checked"':'').' /> ';
			echo '</td><td>';
			echo '<input type="checkbox" name="vis'.$index.'"'.($data['visible']?' checked="checked"':'').' /> ';
			echo '</td><td>';
			echo $this->FieldTypes[$data['type']];
			echo '</td><td>';
			echo '<input type="text" name="tip'.$index.'" value="'.$data['tip'].'" class="gpinput" />';
			echo '</td><td>';
			echo common::Link('Admin_SiteList',$langmessage['delete'],'cmd=delete_field&index='.$list_index.'&fieldindex='.$index,' name="itemlink" class="gpconfirm" title="Delete this Field?" ');
			echo '</td></tr>';
			}
		}
		echo '</table></div>';
		echo '<p>';
		echo '<input type="hidden" name="cmd" value="save_fields" />';
		echo '<input type="hidden" name="index" value="'.$list_index.'" />';
		echo '<input type="submit" value="'.$langmessage['save_changes'].'" class="gpsubmit"/>';
		echo ' &nbsp; ';
		echo common::Link('Admin_SiteList','Add New Field','cmd=new_field&index='.$list_index,' data-cmd="gpabox" ');
		echo ' &nbsp; ';
		echo common::Link('Admin_SiteList','< Back');
		//echo common::Link('Admin_SiteList','Add New Field','cmd=new_field',' name="admin_box" ');
		echo '</p>';
		echo '</form>';
	}

	/**
	 * Prompt user to create a new field 
	 *
	 */
	function NewItem($list_index){
		global $langmessage;
		echo '<div class="inline_box">';
		echo '<h3>Add New Item</h3>';
		echo '<form name="addfield" action="'.common::GetUrl('Admin_SiteList').'" method="post">';
		echo '<input type="hidden" name="cmd" value="save_new_item" />';
		echo '<input type="hidden" name="index" value="'.$list_index.'" />';
		$browserinit=array();
		foreach( $this->lists[$list_index]['fields'] as $index => $data ){
			echo '<p>';
			echo $data['name'].':';
			switch($data['type']){
				case 1:
					gp_edit::UseCK( isset($data['list'])?$data['list']:'', $data['slug'] );
				break;
				case 2:
					//echo sprintf('<input type="text" name="'.$data['slug'].'%s" value="%s" class="gpinput" />select','','');
					$template = '<input id="browserlink%1$sinput" style="width:75%%" type="text" name="'.$data['slug'].'" value="%2$s" class="gpinput" /> <a id="browserlink%1$s" target="new" href="'.common::GetUrl('Admin_Browser').'?type=all'.'">Select</a>';
					echo sprintf($template,count($browserinit),'',1);
					$browserinit[]=count($browserinit);
				break;
				case 4://datetime
				default:
					echo sprintf('<input type="text" name="'.$data['slug'].'%s" value="%s" class="gpinput" />','','');
			}
			echo '</p>';
		}

		echo '<p>';
		echo ' <input type="submit" value="'.$langmessage['save'].'" class="gpitem gpsubmit"/>';
		echo ' <input type="submit" name="cmd" value="'.$langmessage['cancel'].'" class="admin_box_close gpcancel"/>';
		echo '</p>';
		echo '</form>';
		echo '</div>';
		//browser init
		if (count($browserinit)) {
			global $page;
			$page->head_script .= "\n".'
function browserinit(ids){
	if (!window.CKEDITOR){
		window.CKEDITOR={functions:[],tools:{callFunction:function (index,params){var g=CKEDITOR.functions[index];return g&&g.apply(window,[[params]]);},addFunction:function(func,g){return CKEDITOR.functions.push(function(params){return func.apply(g||this,params);})-1;}}}
	}
	for(var id in ids){
		var ref = CKEDITOR.tools.addFunction( function(a) {
			this.val(a);
		},$("#browserlink"+ids[id]+"input") );
		var href=$("#browserlink"+ids[id]).prop("href");
		$("#browserlink"+ids[id]).prop("href",href+"&CKEditorFuncNum="+ref);
	}
}
jQuery(function($){
	browserinit('.json_encode($browserinit).');
});
';
		}
	}
	/**
	 * Prompt user to create a new view 
	 *
	 */
	function NewView($list_index){
		global $langmessage;
		echo '<div class="inline_box">';
		echo '<h3>Add New View</h3>';
		echo '<form name="addview" action="'.common::GetUrl('Admin_SiteList').'" method="post">';
		echo '<p>';
		echo '<input type="hidden" name="cmd" value="save_new_view" />';
		echo '<input type="hidden" name="index" value="'.$list_index.'" />';
		echo 'Name: <input type="text" name="new_view" value="" class="gpinput" />';
		echo '</p>';
/*
		echo '<p>';
		echo 'Type: <select name="new_type">';
		foreach( $this->ViewTypes as $index => $data ){
			echo '<option value="'.$index.'">'.$data.'</option>';
		}
		echo '</select>';
		echo '</p>';
*/

		echo '<p>';
		echo ' <input type="submit" value="'.$langmessage['save'].'" class="gpitem gpsubmit"/>';
		echo ' <input type="submit" name="cmd" value="'.$langmessage['cancel'].'" class="admin_box_close gpcancel"/>';
		echo '</p>';
		echo '</form>';
		echo '</div>';
	}

	/**
	 * Prompt user to create a new field 
	 *
	 */
	function NewField($list_index){
		global $langmessage;
		echo '<div class="inline_box">';
		echo '<h3>Add New Field</h3>';
		echo '<form name="addfield" action="'.common::GetUrl('Admin_SiteList').'" method="post">';
		echo '<p>';
		echo '<input type="hidden" name="cmd" value="save_new_field" />';
		echo '<input type="hidden" name="index" value="'.$list_index.'" />';
		echo 'Name: <input type="text" name="new_field" value="" class="gpinput" />';
		echo '</p>';
		echo '<p>';
		echo 'Type: <select name="new_type">';
		foreach( $this->FieldTypes as $index => $data ){
			echo '<option value="'.$index.'">'.$data.'</option>';
		}
		echo '</select>';
		echo '</p>';

		echo '<p>';
		echo ' <input type="submit" value="'.$langmessage['save'].'" class="gpitem gpsubmit"/>';
		echo ' <input type="submit" name="cmd" value="'.$langmessage['cancel'].'" class="admin_box_close gpcancel"/>';
		echo '</p>';
		echo '</form>';
		echo '</div>';
	}

	/**
	 * Prompt user to create a new list
	 *
	 */
	function NewList(){
		global $langmessage;
		echo '<div class="inline_box">';
		echo '<h3>Add New List</h3>';
		echo '<form name="addlist" action="'.common::GetUrl('Admin_SiteList').'" method="post">';
		echo '<p>';
		echo '<input type="hidden" name="cmd" value="save_new_list" />';
		echo 'Name: <input type="text" name="new_list" value="" class="gpinput" />';
		echo '</p>';

		echo '<p>';
		echo ' <input type="submit" value="'.$langmessage['save'].'" class="gpitem gpsubmit"/>';
		echo ' <input type="submit" name="cmd" value="'.$langmessage['cancel'].'" class="admin_box_close gpcancel"/>';
		echo '</p>';
		echo '</form>';
		echo '</div>';
	}


	/**
	 * Return a new index
	 *
	 */
	function NewViewIndex($list_index){
		$num_index = count($this->lists[$list_index]['views']);
		do{
			$index = base_convert($num_index,10,36);
			$num_index++;
		}while( ctype_digit($index) || isset($this->lists[$list_index]['views'][$index]) );
		return $index;
	}
	/**
	 * Return a new index
	 *
	 */
	function NewFieldIndex($list_index){
		$num_index = 37+count($this->lists[$list_index]['fields']);
		do{
			$index = base_convert($num_index,10,36);
			$num_index++;
		}while( !ctype_alpha($index) || isset($this->lists[$list_index]['fields'][$index]) );
		return $index;
	}

	/**
	 * Return a new non-numeric index
	 *
	 */
	function NewCatIndex(){
		$num_index = count($this->lists);
		do{
			$index = base_convert($num_index,10,36);
			$num_index++;
		}while( !ctype_alpha($index) || isset($this->lists[$index]) );

		return $index;
	}

	/**
	 * Remove Item 
	 *
	 */
	function DeleteItem($list_index){
		global $langmessage;

		if( !isset($_GET['itemindex']) ){
			message($langmessage['OOPS'].' (Invalid Index)');
			return false;
		}

		$index = (int)$_GET['itemindex'];

		return $this->db->DeleteItem($list_index,$index);
	}
	/**
	 * Remove view
	 *
	 */
	function DeleteView($list_index){
		global $langmessage;

		if( !isset($_GET['viewindex']) ){
			message($langmessage['OOPS'].' (Invalid Index)');
			return false;
		}

		$index = $_GET['viewindex'];
		if( !isset($this->lists[$list_index]['views'][$index]) ){
			message($langmessage['OOPS'].' (Index Not Found)');
			return false;
		}

		unset($this->lists[$list_index]['views'][$index]);
		//$this->db->DropView($list_index,$index,$this->lists[$list_index]['views']);

		return $this->save_site_lists();
	}
	/**
	 * Remove field
	 *
	 */
	function DeleteField($list_index){
		global $langmessage;

		if( !isset($_GET['fieldindex']) ){
			message($langmessage['OOPS'].' (Invalid Index)');
			return false;
		}

		$index = $_GET['fieldindex'];
		if( !isset($this->lists[$list_index]['fields'][$index]) ){
			message($langmessage['OOPS'].' (Index Not Found)');
			return false;
		}

		unset($this->lists[$list_index]['fields'][$index]);
		$this->db->DropField($list_index,$index,$this->lists[$list_index]['fields']);

		return $this->save_site_lists();
	}

	/**
	 * Remove a list
	 *
	 */
	function DeleteList(){
		global $langmessage;
		//$this->addmessage($_POST);
		//$this->addmessage($_GET);

		if( !isset($_GET['index']) ){
			message($langmessage['OOPS'].' (Invalid Index)');
			return false;
		}

		$index = $_GET['index'];
		if( !isset($this->lists[$index]) ){
			message($langmessage['OOPS'].' (Index Not Found)');
			return false;
		}

		unset($this->lists[$index]);
		$this->db->DropTable($index);

		return $this->save_site_lists();
	}
	function ExportList($list_index){
		$list_name=$this->lists[$list_index]['name'];
		
		$header=array(); 
		$header[]='ID';
		foreach( $this->lists[$list_index]['fields'] as $index => $data ){
			$header[]=$data['name'];
		}

		$columns=array_keys($this->lists[$list_index]['fields']);
		$rows=$this->db->SelectItems($list_index,$columns);//,implode(',',$columns),0);
        //print_r($rows); -> SQLite3Result Object ( ) 
		if (!$rows || count(get_class_methods($rows))==0) {   //get_class_methods
			msg('No '.$list_name.' list items to export.');
			return;
		}

		msg('Exporting '.count(get_class_methods($rows)).' '.$list_name.' list items.'); // get_class_methods
		$this->CSVExport($rows,$header,$list_name);
	}
	function CSVExport($rows,$header=null,$filename='export'){
		$output = fopen('php://output', 'w');
		ob_start();
		fputcsv($output, $header);
		while($row = $this->db->fetch_row($rows)){
			fputcsv($output, $row);
		}
		fclose($output);
		$out = ob_get_clean();

		header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
		header('Content-Length: ' . strlen($out));
		header('Content-type: text/x-csv');
		header('Content-Disposition: attachment; filename='.$filename.'.csv');
		echo $out;
		exit;
	}
}
?>
