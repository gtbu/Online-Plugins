<?php
defined('is_running') or die('Not an entry point...');

gpPlugin::incl('controller/SiteListCommon.php','require_once');

/**
 * Class for displaying the Special_List page and performing it's actions
 *
 */
class SiteList extends SiteListCommon{

	function __construct(){
		global $page, $langmessage, $addonFolderName;
        parent::__construct();
		$this->Init();

		$cmd = common::GetCommand();
		$show = true;
		if( common::LoggedIn() ){

			switch($cmd){

				/* inline editing */
				case 'inlineedit':
					$this->InlineEdit();
				die();
				case 'save':
					$this->SaveInline();
				break;


				//delete prompts
				case 'deleteentry':
					$this->DeleteEntryPrompt();
				return;
				case 'delete_comment_prompt':
					$this->DeleteCommentPrompt();
				return;

				//delete
				case 'delete':
					if( $this->Delete() ){
						$this->GenStaticContent();
					}
				break;

				//editing
				case 'save_edit':
					if( $this->SaveEdit() ){
						$this->GenStaticContent();
						break;
					}
				case 'edit':
					$this->EditItem();
					$show = false;
				break;

				//creating
				case 'save_new';
					if( $this->SaveNew() ){
						$this->GenStaticContent();
						break;
					}
				case 'new_form':
					$this->NewForm();
					$show = false;
				break;

			}


			$page->admin_links[] = array('Special_List','List Home');

			$page->admin_links[] = array('Special_List','New List Item','cmd=new_form');

			$page->admin_links[] = array('Admin_List','Configuration');

			$page->admin_links[] = array('Admin_Theme_Content',$langmessage['editable_text'],'cmd=addontext&addon='.urlencode($addonFolderName),' name="gpabox" ');

		//	$label = 'Number of Items: '. $this->listData['item_count'];
		//	$page->admin_links[$label] = '';
		}

		if( $show ){
			if( empty($cmd) && isset($_REQUEST['id']) && ctype_digit($_REQUEST['id']) ){
				$cmd = 'item';
			}
			switch($cmd){
				case 'opencomments':
				case 'closecomments':
				case 'delete_comment':
				case 'Add Comment':
				case 'save_edit':
				case 'item':
		//			$this->ShowItem($cmd);
				break;
				case 'page':
				default:
		//			$this->ShowPage();
				break;
			}

			if( common::LoggedIn() && !file_exists($this->indexFile) ){
				echo '<p>Congratulations on successfully installing Simple List for gpEasy.</p> ';
				echo '<p>You\'ll probably want to get started by '.common::Link('Special_List','creating a list item','cmd=new_form').'.</p>';
			}

		}

	}


	/**
	 * Prompt the user if they want to delete the list comment
	 *
	 */
	function DeleteCommentPrompt(){
		global $langmessage;

		echo '<div class="inline_box">';

		echo '<form method="post" action="'.common::GetUrl('Special_List').'">';
			echo $langmessage['delete_confirm'];
			echo ' <input type="hidden" name="id" value="'.$_GET['id'].'" />';
			echo ' <input type="hidden" name="comment_id" value="'.$_GET['comment'].'" />';
			echo  ' <input type="hidden" name="cmd" value="delete_comment" />';
			echo  ' <input type="submit" name="aaa" value="'.$langmessage['delete'].'" />';
		echo '</form>';
		echo '</div>';

	}

	/**
	 * Prompt the user if they want to delete the list item
	 *
	 */
	function DeleteEntryPrompt(){
		global $langmessage;

		echo '<div class="inline_box">';
		echo '<form method="post" action="'.common::GetUrl('Special_List').'">';
		echo $langmessage['delete_confirm'];
		echo ' <input type="hidden" name="id" value="'.htmlspecialchars($_GET['del_id']).'" />';
		echo  ' <input type="hidden" name="cmd" value="delete" />';

		echo '<p>';
		echo ' <input type="submit" name="aaa" value="'.$langmessage['delete'].'" />';
		echo ' <input type="submit" value="'.$langmessage['cancel'].'" class="admin_box_close" /> ';
		echo '</p>';

		echo '</form>';
		echo '</div>';
	}


	/**
	 * Output the html for a single list item
	 * Handle comment actions
	 */
	function ShowItem($cmd){
		global $langmessage,$page;

		if( !isset($_REQUEST['id']) ){
			message($langmessage['OOPS']);
			return;
		}

		$item_index = $_REQUEST['id'];
		$items = $this->GetItemFile($item_index,$item_file);
		if( $items === false ){
			message($langmessage['OOPS']);
			return;
		}


		if( !isset($items[$item_index]) ){
			message($langmessage['OOPS']);
			return;
		}

		$commentSaved = false;
		switch($cmd){

			//close comments
			case 'closecomments':
				$this->CloseComments($item_index);
			break;
			case 'opencomments':
				$this->OpenComments($item_index);
			break;


			//commments
			case 'Add Comment':
				if( $this->AddComment($item_index) ){
					$commentSaved = true;
				}else{
					echo '<div class="comment_container">';
					$this->CommentForm($item_index,true);
					echo '</div>';
					return;
				}
			break;
			case 'delete_comment':
				$this->DeleteComment($item_index);
			break;
		}



		$item =& $items[$item_index];
		$this->ShowItemContent($item,$item_index);

		$page->label = SiteListCommon::Underscores( $item['title'] );
		$this->ItemLinks($item_index);

		//comments
		if( $this->listData['allow_comments'] ){
			echo '<div class="comment_container">';
			$this->ShowComments($item_index);
			if( !$commentSaved ){
				$this->CommentForm($item_index);
			}
			echo '</div>';
		}
	}


	/**
	 * Show the comments for a single list item
	 *
	 */
	function ShowComments($item_index){

		$data = $this->GetCommentData($item_index);
		if( empty($data) ){
			return;
		}

		echo '<h3>';
		echo gpOutput::GetAddonText('Comments');
		echo '</h3>';

		$this->GetCommentHtml($data,$item_index,true);

	}

	/**
	 * Close the comments for a list item
	 *
	 */
	function CloseComments($item_index){
		global $langmessage;

		$this->listData['item_info'][$item_index]['closecomments'] = true;
		if( !$this->SaveIndex() ){
			message($langmessage['OOPS']);
		}else{
			message($langmessage['SAVED']);
		}
	}

	/**
	 * Allow commenting for a list item
	 *
	 */
	function OpenComments($item_index){
		global $langmessage;

		unset($this->listData['item_info'][$item_index]['closecomments']);
		if( !$this->SaveIndex() ){
			message($langmessage['OOPS']);
		}else{
			message($langmessage['SAVED']);
		}
	}

	/**
	 * Display the visitor form for adding comments
	 *
	 */
	function CommentForm($item_index,$showCaptcha=false){

		if( isset($this->listData['item_info'][$item_index]) && isset($this->listData['item_info'][$item_index]['closecomments']) ){
			echo '<div class="comments_closed">';
			echo gpOutput::GetAddonText('Comments have been closed.');
			echo '</div>';
			return;
		}


		$_POST += array('name'=>'','website'=>'http://','comment'=>'');

		echo '<h3>';
		echo gpOutput::GetAddonText('Leave Comment');
		echo '</h3>';


		echo '<form method="post" action="'.common::GetUrl('Special_List','id='.$item_index).'">';
		echo '<ul>';
		echo '<li>';
			echo '<label>';
			echo gpOutput::GetAddonText('Name');
			echo '</label><br/>';
			echo '<input type="text" name="name" class="text" value="'.htmlspecialchars($_POST['name']).'" />';
			echo '</li>';

		if( !empty($this->listData['commenter_website']) ){
			echo '<li>';
				echo '<label>';
				echo gpOutput::GetAddonText('Website');
				echo '</label><br/>';
				echo '<input type="text" name="website" class="text" value="'.htmlspecialchars($_POST['website']).'" />';
				echo '</li>';
		}

		echo '<li>';
			echo '<label>';
			echo gpOutput::ReturnText('Comment');
			echo '</label><br/>';
			echo '<textarea name="comment" cols="30" rows="7" >';
			echo htmlspecialchars($_POST['comment']);
			echo '</textarea>';
			echo '</li>';


		if( $showCaptcha && $this->listData['comment_captcha'] && gp_recaptcha::isActive() ){
			echo '<input type="hidden" name="anti_spam_submitted" value="anti_spam_submitted" />';
			echo '<li>';
			echo '<label>';
			echo gpOutput::ReturnText('captcha');
			echo '</label><br/>';
			gp_recaptcha::Form();
			echo '</li>';
		}

		echo '<li>';
			echo '<input type="hidden" name="cmd" value="Add Comment" />';
			$html = '<input type="submit" name="" class="submit" value="%s" />';
			echo gpOutput::GetAddonText('Add Comment',$html);
			echo '</li';

		echo '</ul>';
		echo '</form>';

	}

	/**
	 * Display the links at the bottom of a item
	 *
	 */
	function ItemLinks($item_index){

		$item_key = $this->KeyFromIndex($item_index);

		echo '<p class="list_nav_links">';

		//check for older items
		$prev_index = $this->IndexFromKey($item_key+1);
		if( $prev_index ){
			$html = common::Link('Special_List','%s','id='.$prev_index,'class="list_older"');
			echo gpOutput::GetAddonText('Older Entry',$html);
			echo '&nbsp;';
		}

		//list home
		$html = common::Link('Special_List','%s');
		echo gpOutput::GetAddonText('List Home',$html);
		echo '&nbsp;';

		// check for newer items
		if( $item_key > 0 ){
			$next_index = $this->IndexFromKey($item_key-1);
			$html = common::Link('Special_List','%s','id='.$next_index,'class="list_newer"');
			echo gpOutput::GetAddonText('Newer Entry',$html);
		}

		if( common::LoggedIn() ){
			echo '&nbsp;';
			echo common::Link('Special_List','New Item','cmd=new_form');
		}

		echo '</p>';
	}




	/**
	 * Display a list page with multiple list items
	 *
	 */
	function ShowPage(){

		$per_page = $this->listData['per_page'];
		$page = 0;
		if( isset($_GET['page']) && is_numeric($_GET['page']) ){
			$page = (int)$_GET['page'];
		}
		$start = $page * $per_page;

		$show_items = $this->WhichItems($start,$per_page);

		$items = array();
		foreach($show_items as $item_index){

			//get $items
			if( !isset($items[$item_index]) ){
				$items = $this->GetItemFile($item_index,$item_file);
			}

			$item =& $items[$item_index];

			$this->ShowItemContent( $item, $item_index, $this->listData['item_abbrev'] );
		}

		echo '<p class="list_nav_links">';
		if( $page > 0 ){
			$html = common::Link('Special_List','%s','page='.($page-1),'class="list_newer"');
			echo gpOutput::GetAddonText('Newer Entries',$html);
			echo '&nbsp;';

			$html = common::Link('Special_List','%s');
			echo gpOutput::GetAddonText('List Home',$html);
			echo '&nbsp;';
		}

		if( ( ($page+1) * $per_page) < $this->listData['item_count'] ){
			$html = common::Link('Special_List','%s','page='.($page+1),'class="list_older"');
			echo gpOutput::GetAddonText('Older Entries',$html);
		}

		if( common::LoggedIn() ){
			echo '&nbsp;';
			echo common::Link('Special_List','New Item','cmd=new_form');
		}

		echo '</p>';

	}

	/**
	 * Get a list of item indeces
	 *
	 */
	function WhichItems($start,$len){
		$items = array();
		$end = $start+$len;
		for($i = $start; $i < $end; $i++){
			$index = $this->IndexFromKey($i);
			if( $index ) $items[] = $index;
		}
		return $items;
	}


	/**
	 * Display a list page with multiple list items
	 *
	 */
	function ShowPageOld(){

		$items = array();
		foreach($show_items as $item_index){

			//get $items
			if( !isset($items[$item_index]) ){
				$items = $this->GetItemFile($item_index,$item_file);
			}

			$item =& $items[$item_index];

			$this->ShowItemContent($item,$item_index);
		}
	}

	/**
	 * Display the html for a single list item
	 *
	 */
	function ShowItemContent( &$item, &$item_index, $limit = 0){
		global $langmessage;

		$id = $class = '';
		if( common::LoggedIn() ){

			//$edit_link = gpOutput::EditAreaLink($edit_index,'Special_List',$langmessage['edit'],'cmd=edit&id='.$item_index);
			$edit_link = gpOutput::EditAreaLink($edit_index,'Special_List',$langmessage['edit'].' (TWYSIWYG)','id='.$item_index,'name="inline_edit_generic" rel="text_inline_edit"');
			echo '<span style="display:none;" id="ExtraEditLnks'.$edit_index.'">';
			echo $edit_link;

			echo common::Link('Special_List',$langmessage['edit'].' (All)','cmd=edit&id='.$item_index,' style="display:none"');
			echo common::Link('Special_List',$langmessage['delete'],'cmd=deleteentry&del_id='.$item_index,' name="gpabox" style="display:none"');

			if( $this->listData['allow_comments'] ){
				if( isset($this->listData['item_info'][$item_index]) && isset($this->listData['item_info'][$item_index]['closecomments']) ){
					$label = gpOutput::SelectText('Open Comments');
					echo common::Link('Special_List',$label,'cmd=opencomments&id='.$item_index,'name="creq" style="display:none"');
					//echo common::Link('Special_List','%s','cmd=opencomments&id='.$item_index,'name="creq"');
					//echo gpOutput::GetAddonText('Open Comments',$html);
				}else{
					$label = gpOutput::SelectText('Close Comments');
					echo common::Link('Special_List',$label,'cmd=closecomments&id='.$item_index,'name="creq" style="display:none"');
					//echo common::Link('Special_List','%s','cmd=closecomments&id='.$item_index,'name="creq"');
					//echo gpOutput::GetAddonText('Close Comments',$html);
				}
			}

			echo common::Link('Special_List','New List Item','cmd=new_form',' style="display:none"');
			echo common::Link('Admin_List',$langmessage['configuration'],'',' style="display:none"');
			echo '</span>';
			$class .= ' editable_area';
			$id = 'id="ExtraEditArea'.$edit_index.'"';
		}

		//echo '<div class="list_item">';
		echo '<div class="list_item'.$class.'" '.$id.'>';

		$header = '<h2 id="list_item_'.$item_index.'">';
		$label = SiteListCommon::Underscores( $item['title'] );
		$header .= common::Link('Special_List',$label,'id='.$item_index);
		$header .= '</h2>';

		$this->ListHead($header,$item_index,$item);

		echo '<div class="twysiwygr">';
		echo $this->AbbrevContent( $item['content'], $item_index, $limit);
		echo '</div>';

		echo '</div>';

		echo '<br/>';

		//echo showArray($item);
		echo '<div class="clear"></div>';

	}

	/**
	 * Abbreviate $content if a $limit greater than zero is given
	 *
	 */
	function AbbrevContent( $content, $item_index, $limit = 0 ){

		if( !is_numeric($limit) || $limit == 0 ){
			return $content;
		}

		$content = strip_tags($content);

		if( SiteListCommon::strlen($content) < $limit ){
			return $content;
		}

		$pos = SiteListCommon::strpos($content,' ',$limit-5);

		if( ($pos > 0) && ($limit+20 > $pos) ){
			$limit = $pos;
		}
		$content = SiteListCommon::substr($content,0,$limit).' ... ';
		$label = gpOutput::SelectText('Read More');
		return $content . common::Link('Special_List',$label,'id='.$item_index);
	}



	/* comments */


	/**
	 * Get the comment data for a single item
	 *
	 */
	function GetCommentData($item_index){

		$data = array();
		$commentDataFile = $this->addonPathData.'/comments_data_'.$item_index.'.txt';
		if( file_exists($commentDataFile) ){
			$dataTxt = file_get_contents($commentDataFile);
			if(  !empty($dataTxt) ){
				$data = unserialize($dataTxt);
			}
		}
		return $data;
	}

	/**
	 * Remove a comment entry from the comment data
	 *
	 */
	function DeleteComment($item_index){
		global $langmessage;

		$data = $this->GetCommentData($item_index);

		$comment = $_POST['comment_id'];
		if( !isset($data[$comment]) ){
			message($langmessage['OOPS']);
			return;
		}

		unset($data[$comment]);

		if( $this->SaveCommentData($item_index,$data) ){
			message($langmessage['SAVED']);
			return true;
		}else{
			message($langmessage['OOPS']);
			return false;
		}

	}

	/**
	 * Add a comment to the comment data for a item
	 *
	 */
	function AddComment($item_index){
		global $langmessage;

		if( isset($this->listData['item_info'][$item_index]) && isset($this->listData['item_info'][$item_index]['closecomments']) ){
			return;
		}

		$data = $this->GetCommentData($item_index);

		//need a captcha?
		if( $this->listData['comment_captcha'] && gp_recaptcha::isActive() ){

			if( !isset($_POST['anti_spam_submitted']) ){
			//if( !isset($_POST['recaptcha_challenge_field']) ){
				return false;

			}elseif( !gp_recaptcha::Check() ){
				return false;

			}
		}

		if( empty($_POST['name']) ){
			$field = gpOutput::SelectText('Name');
			message($langmessage['OOPS_REQUIRED'],$field);
			return false;
		}

		if( empty($_POST['comment']) ){
			$field = gpOutput::SelectText('Comment');
			message($langmessage['OOPS_REQUIRED'],$field);
			return false;
		}


		$temp = array();
		$temp['name'] = htmlspecialchars($_POST['name']);
		$temp['comment'] = nl2br(strip_tags($_POST['comment']));
		$temp['time'] = time();

		if( !empty($_POST['website']) && ($_POST['website'] !== 'http://') ){
			$website = $_POST['website'];
			if( SiteListCommon::strpos($website,'://') === false ){
				$website = false;
			}
			if( $website ){
				$temp['website'] = $website;
			}
		}

		$data[] = $temp;

		if( $this->SaveCommentData($item_index,$data) ){
			message($langmessage['SAVED']);
			return true;
		}else{
			message($langmessage['OOPS']);
			return false;
		}
	}

	/**
	 * Save the comment data for a list item
	 *
	 */
	function SaveCommentData($item_index,$data){
		global $langmessage;

		$dataTxt = serialize($data);
		$commentDataFile = $this->addonPathData.'/comments_data_'.$item_index.'.txt';
		if( !gpFiles::Save($commentDataFile,$dataTxt) ){
			return false;
		}

		$this->listData['item_info'][$item_index]['comments'] = count($data);
		$this->SaveIndex();

		return true;
	}


	/**
	 * Output the html for a list item's comments
	 *
	 */
	function GetCommentHtml( $data, $item_index ){
		global $langmessage;

		if( !is_array($data) ){
			continue;
		}

		foreach($data as $key => $comment){
			echo '<div class="comment_area">';
			echo '<p class="name">';
			if( ($this->listData['commenter_website'] == 'nofollow') && !empty($comment['website']) ){
				echo '<b><a href="'.$comment['website'].'" rel="nofollow">'.$comment['name'].'</a></b>';
			}elseif( ($this->listData['commenter_website'] == 'link') && !empty($comment['website']) ){
				echo '<b><a href="'.$comment['website'].'">'.$comment['name'].'</a></b>';
			}else{
				echo '<b>'.$comment['name'].'</b>';
			}
			echo ' &nbsp; ';
			echo '<span>';
			echo strftime($this->listData['strftime_format'],$comment['time']);
			echo '</span>';


			if( common::LoggedIn() ){
				echo ' &nbsp; ';
				echo common::Link('Special_List',$langmessage['delete'],'cmd=delete_comment_prompt&id='.$item_index.'&comment='.$key,' name="gpabox"');
			}


			echo '</p>';
			echo '<p class="comment">';
			echo $comment['comment'];
			echo '</p>';
			echo '</div>';
		}
	}
}
?>
