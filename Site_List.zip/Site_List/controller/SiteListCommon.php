<?php
defined('is_running') or die('Not an entry point...');

//includeFile('tool/recaptcha.php');
gpPlugin::incl('model/AdminSiteList.php','require_once');

if( function_exists('mb_internal_encoding') ){
	mb_internal_encoding('UTF-8');
}

class SiteListReplace{
	
	function __construct($func,$args){
		$this->func=$func;
		$this->args=$args;
	}
	function args_before(){
		return call_user_func_array($this->func,array_merge($this->args,func_get_args()));
	}
	static function Before(){
		$args=func_get_args();
		$func=$args[0];
		array_shift($args);
		$a=new SiteListReplace($func,$args);
		return array($a,'args_before');
	}

}
class SiteListReplaceFunctions{
	function SiteListReplaceFunctions(){
		//compile available functions
		$this->functions=array();
		foreach (get_class_methods(get_class()) as $classMethod) {
			$this->functions[substr($classMethod,1)]=array(get_class(),$classMethod);
		}
		//prepare preg patterns
		$implodedCommands=implode('|',array_keys($this->functions));
		$this->findFunctionsPattern='/(?:\.(?:('.$implodedCommands.')\(([^)]*)\)))/';
		$this->findFunctionArgumentsPattern='/(?:(?:"((?:\\"|[^"])*?)")|(?:\'((?:\\\'|[^\'])*?)\')|([^,]+))[,]?/';
	}
	function Apply($functions,$value){
		//search for functions
		$functionsCount=preg_match_all($this->findFunctionsPattern,$functions,$functionMatches);
		if ($functionsCount===false){
			return $value;
		}

		//apply functions
		for ($i = 0; $i < $functionsCount; $i++) {
			//does function exist?
			$function=$functionMatches[1][$i];
			if (!array_key_exists($function,$this->functions)) {
				continue;
			}
			//get arguments
			unset($args);
			$args=array($value);
			$arguments=$functionMatches[2][$i];
			$argumentsCount=preg_match_all($this->findFunctionArgumentsPattern,$arguments,$argumentMatches);
			for ($j = 0; $j < $argumentsCount; $j++) {
				//working with empty strings or values found
				if($argumentMatches[0][$j]==''){
					$args[]=null;
				}else if(($argumentMatches[1][$j]!='')){
					$args[]=$argumentMatches[1][$j];
				}else if(($argumentMatches[2][$j]!='')){
					$args[]=$argumentMatches[2][$j];
				}else {
					$args[]=$argumentMatches[3][$j];
				}
			}
			//call function with arguments
			$value=call_user_func_array($this->functions[$function],$args);
		}
/*
ob_start();
print_r($matches);
$a=ob_get_clean();
return $value.$a;
*/
		return $value;
/*
Example $argumentMatches:
Array
(
    [0] => Array
        (
            [0] => 0,
            [1] => '-'
        )

    [1] => Array
        (
            [0] => 
            [1] => 
        )

    [2] => Array
        (
            [0] => 
            [1] => -
        )

    [3] => Array
        (
            [0] => 0
            [1] => 
        )

)
$functionMatches:
Array
(
    [0] => Array
        (
            [0] => .dateFormat('Y-m-d')
            [1] => .shorten(0,'-')
        )

    [1] => Array
        (
            [0] => dateFormat
            [1] => shorten
        )

    [2] => Array
        (
            [0] => 'Y-m-d'
            [1] => 0,'-'
        )

)
*/
	}
	static function _dateFormat($value,$format){
		return date($format,strtotime($value));
	}
	static function _stringFormat($value,$format){
		return sprintf($format,$value);
	}
	static function _shorten($value,$length,$nearest=' ',$reverse='false'){
		$content=strip_tags($value);
		if (strtolower($reverse)=='false') {
			if (strtolower($nearest)!='false') {
				if ($length>strlen($content)) {
					$length=strlen($content);
				}
				$position=strpos($content,$nearest, $length);
				if ($position!==false) {
					$length=$position;
				}
			}
			return mb_substr($content,0,$length);
		}
		//reverse
		if (strtolower($nearest)!='false') {
			$position=strrpos($content,$nearest);
			if ($position!==false) {
				$length=strlen($content)-$position-1;
			}
		}
		return mb_substr($content,-1*$length);
	}
	static function _split($value,$delimeter,$index){
		$array=explode($delimeter,$value);
		if (isset($array[$index])) {
			return $array[$index];
		}
		return '';//'Index '.$index.' not found.';
	}
	static function _stripHTML($value){
		return strip_tags($value);
	}
	static function _blank($value,$blank){
		if (empty($value)) {
			return $blank;
		}
		return $value;
	}
	static function _notBlank($value,$blank){
		if (!empty($value)) {
			return $blank;
		}
		return $value;
	}
	static function _moneyFormat($value,$format){
		if (function_exists('money_format')) {
			return money_format($format,$value);
		}
		return $value;
	}
}

class SiteListCache{	
	var $cacheName='cache';	
   // $this->addonPathDataCurrent=$addonPathData.'/current';		
	var $defaults=array('expire'=>0,'timeout'=>0,'content'=>'','args'=>array(),'call'=>array());
	
    function SiteListCache($path){
		return $this->directory = $path.'/'.$this->cacheName;
	}
	function GetHash($key){
		return md5($key);
	}
    function GetFile($hashkey){
		global $addonPathData;
		$dirfile = $this->directory = $addonPathData.'/current'; //Undefined property: SiteListCache::$directory ->line214,209,477
        return $dirfile.'/'.$hashkey.'.php';	
	}
	function Write($key,$call,$args=array(),$timeout=0){
		return $this->WriteKey($key,array('call'=>$call,'args'=>$args,'expire'=>time(),'timeout'=>$timeout),False);
		//return $this->WriteHashKey($this->GetHash($key),$content);
	}
	function WriteKey($key,$cache,$updateExpire=True){
		$hashkey=$this->GetHash($key);
		$file=$this->GetFile($hashkey);
		//save space, unset default values
		$cache=array_merge($this->defaults,$cache);
		foreach ($cache as $index=>$item) {
			if ($this->defaults[$index]==$cache[$index]) {
				unset($cache[$index]);
			}
		}
		if ($updateExpire && isset($cache['timeout'])) {
			$cache['expire']=$cache['timeout']+time();
		}

		//write to file
		if (gpFiles::SaveArray($file,'cache',$cache)){
			return $file;
		}
		message('Failed saving to cache.');
		return false;
	}
	function WriteHashKey($hashkey,$content){
		$file=$this->GetFile($hashkey);
		if( !gpFiles::Save($file,$content) ){
			return false;
		}
		return $file;
	}
	function Read($key){
		$cache=$this->ReadKey($key);
		if ($cache){
			//check if content expired
			if ($cache['expire']==0 || time()<$cache['expire']) {
				return $cache['content'];
			}

			//generate new content and save
			unset($cache['expire']);
			$cache['content']=$this->GetCacheContent($cache);
			$this->WriteKey($key,$cache);
			return $cache['content'];
		}
		return false;
	}
	function Expire($key){
		$cache=$this->ReadKey($key);
		if ($cache) {
			$cache['expire']=time();
			$this->WriteKey($key,$cache,False);
		}
	}
	function GetCacheContent($cache){
		if ($cache['call'] && is_array($cache['call']) && count($cache['call'])==2) {
			if (class_exists($cache['call'][0])) {
				$object=new $cache['call'][0];
				return call_user_func_array(array($object,$cache['call'][1]),$cache['args']);
			}
		}
		return 'Unable to reload cache.';
	}
	function ReadKey($key){
		$hashkey=$this->GetHash($key);
		$file=$this->GetFile($hashkey);
		if (!file_exists($file)){
			return false;
		}

		include($file);
		if (isset($cache) && is_array($cache)) {
			$cache=array_merge($this->defaults,$cache);
		}else {
			$cache=$this->defaults;
		}
		return $cache;
	}
	//return $this->ReadHashKey($this->GetHash($key));
	function ReadHashKey($hashkey){
		$file=$this->GetFile($hashkey);
		if (!file_exists($file)){
			return false;
		}

		ob_start();
			readfile($file);
		return ob_get_clean();
	}
}
class SiteListArray{
	public $array;
	function SiteListArray($path,$name){
		$this->path=$path;
		$this->name=$name;
		$this->file=$path.'/'.$name.'.php';
		$this->Load();
	}
	function Save(){
		return gpFiles::SaveArray($this->file,'array',$this->array); //save
	}
	function GetDefault(){
		return array();
	}
	function Load(){
		if( file_exists($this->file) ){
			include($this->file);
			$this->array= $array;
		}else{
			$this->array = $this->GetDefault();
		}
	}
	
}

class SiteListCommon{
	var $indexFile;
	var $listData = array();

	var $installed = false;
	var $addonPathDataCurrent;
	var $addonPathData_PathCurrent='/current';
	var $addonPathData_PathSnapshot='/snapshot';

	var $lists;
	var $listsFile;
	const version='1.0';
	const config_version_key='SiteListVersion';
	protected $db;

	var $archives;
	var $archivesFile;
	var $months = array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');

	/**
	 * When SiteListCommon is created as an object, it will regenerate the static files
	 */
	function SiteListCommon(){
		$this->Init();
		//$this->GenStaticContent();
	}

	/**
	 * Set variables for list display
	 */
	function Init(){
		$this->InitVars();
		//SiteListCommon::AddCSS();

		//load existing lists
		$this->load_site_lists();
		//initialze database
		$this->InitDB();
	}
	function InitVars(){
		global $addonPathData;
		$this->addonPathDataCurrent=$addonPathData.$this->addonPathData_PathCurrent;
		$this->listsFile = $this->addonPathDataCurrent.'/lists.php';

		$this->cache=new SiteListCache($this->addonPathDataCurrent);
	}
	function InitDB(){
		if (empty($this->db)) {
			//$this->db=new fsqlAdminSiteListModel();
			$this->db=new sqliteAdminSiteListModel();
			$this->db->Init($this->addonPathDataCurrent);
		}
	}

	function AddCSS(){
		global $addonFolderName,$page;
		static $added = false;
		if( $added ) return;

		//$page->head_script .= 'gplinks.list_gadget = function(){$(this).next(".nodisplay").toggle();};';
		$page->jQueryCode .= '$(".list_gadget_link").click(function(){$(this).next(".nodisplay").toggle();});';
		$page->css_user[] = '/data/_addoncode/'.$addonFolderName.'/style.css';
		$added = true;
	}

	function save_site_lists(){
		return gpFiles::SaveArray($this->listsFile,'lists',$this->lists); //save
	}
	/**
	 * Get all the lists in use by the list
	 *
	 */
	function load_site_lists(){
		if( file_exists($this->listsFile) ){
			include($this->listsFile);
			$this->lists = $lists;
		}else{
			//$this->lists = array( 'a' => array( 'ct'=>'Unsorted items', 'visible'=>false,'items'=>array() ) );
			$this->lists = array();
			$this->save_site_lists();
		}
	}

	/**
	 * Remove a list entry from a list
	 *
	 */
	function delete_item_from_lists($item_index){
		$this->load_list_lists();
		foreach ($this->lists as $catindex => $catdata){
			if (isset($catdata['items'][$item_index]))	{
				unset($this->lists[$catindex]['items'][$item_index]);
			}
		}
		$this->save_site_lists();
	}


	/**
	 * Update a list when a list entry is edited
	 */
	function update_item_in_lists($item_index,$title){
		$this->load_list_lists();
		foreach( $this->lists as $catindex => $catdata ){
			$selected = false;
			if( isset($_POST['list']) ){
				foreach( $_POST['list'] as $catindex1 ){
					if( $catindex == $catindex1 ){
						$selected = true;
					}
				}
			}

			if( $selected ){
				$this->lists[$catindex]['items'][$item_index] = $title;
			}elseif( isset($catdata['items'][$item_index]) ){
				unset($this->lists[$catindex]['items'][$item_index]);
			}
		}
		$this->save_site_lists();
	}


	static function ReplaceViewItems($slugs,$row,$replaceFunctions,$matches){
		//find var
		$slug=$matches[1];
		$index=array_search($slug,$slugs)+3;//account for offset
		//var not found
		if ($index===false) {
			return 'Not Found:'.$slug;
		}

		//any functions to apply?
		$value=$row[$index];
		$functions=$matches[2];
		if (empty($functions)){
			return $value;
		}
		//apply functions
		return $replaceFunctions->Apply($functions,$value);
	}
	static function ReplaceViewList($slugs,$row,$matches){
		$slug=$matches[1];
		$index=array_search($slug,$slugs);
		return $row[$index];
	}
	function GetViewTemplateKey($list_index,$view_index){
		return 'view-'.$list_index.'-'.$view_index;
	}
	function WriteViewTemplateCache($list_index,$view_index){
		$key=$this->GetViewTemplateKey($list_index,$view_index);
		//$content=$this->RenderView($view_index,$list_index);
		//$this->cache->write($key,$content);	
		$this->cache->Write($key,array('SiteListCommon','RenderView'),array($view_index,$list_index));	
	}
	/**
	 * Render the selected view
	 */
	//protected $renderCommands=array('stripHTML','shorten','dateFormat','stringFormat','blank','moneyFormat');
	function RenderView($view_index,$list_index){
		$rows=$this->db->SelectViewItems($this->lists[$list_index]['views'][$view_index],$this->lists);
		$slugs=array();
		foreach ($this->lists[$list_index]['fields'] as $key=>$column) {
			$slugs[]=$column['slug'];
		}
		$slugs[]='listitem_even';
		$slugs[]='listitem_odd';
		$slugs[]='listitem_index';
		$slugs[]='listitem_id';

		//ITEMS
		//$implodedCommands=implode('|',$this->renderCommands);
		//$implodedSlugs=implode('|',$slugs);
		$implodedSlugs='[^\.\}]*';
		//$pregPattern='/\{('.$implodedSlugs.')(?:(\.)(?:('.$implodedCommands.')\((?:(?:(?:"((?:\\"|[^"])*?)")|(?:\'((?:\\\'|[^\'])*?)\')|([^,\)]+))[,]?)*(\))))*\}/';
		$pregPattern='/\{\{('.$implodedSlugs.')([^}]*)\}\}/';
		$replaceFunctions=new SiteListReplaceFunctions();
		ob_start();
//print $pregPattern;
		$index=0;
		$item_even=false;
		while($row = $this->db->fetch_row($rows)){
			$row_table_index=$row[0];
			$item_index=$row[1];
			if ($item_even) {
				$row[]='even';
				$row[]='';
			} else {
				$row[]='';
				$row[]='odd';
			}
			$row[]=$index;
			$row[]=$row[2];

			echo preg_replace_callback($pregPattern,SiteListReplace::Before(array('SiteListCommon','ReplaceViewItems'),$slugs,$row,$replaceFunctions),html_entity_decode($this->lists[$row_table_index]['views'][$view_index]['items'][$item_index]['template'],ENT_QUOTES));
			$index++;
			$item_even=!$item_even;
		}
		$rows_html=ob_get_clean();

		//LIST TEMPLATE
		$slugs=array('list');
		$row=array($rows_html);
		return preg_replace_callback('/\{\{('.implode('|',$slugs).')\}\}/',SiteListReplace::Before(array('SiteListCommon','ReplaceViewList'),$slugs,$row),$this->lists[$list_index]['views'][$view_index]['list']);
	}



	function GetIndex($index_key,$array=null){
		global $langmessage;

		if( !isset($_REQUEST[$index_key]) ){
			message($langmessage['OOPS'].' (Invalid Index: '.$index_key.')');
			return false;
		}

		$index = $_REQUEST[$index_key];
		if( $array && is_array($array) && !isset($array[$index]) ){
			message($langmessage['OOPS'].' (Index Not Found: '.$index_key.')');
			return false;
		}

		return $index;
	}
	function GetViewIndex($list_index){
		return $this->GetIndex('viewindex',$this->lists[$list_index]['views']);

		global $langmessage;

		if( !isset($_REQUEST['viewindex']) ){
			message($langmessage['OOPS'].' (Invalid Index)');
			return false;
		}

		$index = $_REQUEST['viewindex'];
		if( !isset($this->lists[$list_index]['views'][$index]) ){
			message($langmessage['OOPS'].' (Index Not Found)');
			return false;
		}

		return $index;
	}
	function GetFieldIndex($list_index){
		return $this->GetIndex('fieldindex',$this->lists[$list_index]['fields']);
		global $langmessage;

		if( !isset($_GET['fieldindex']) ){
			message($langmessage['OOPS'].' (Invalid Index)');
			return false;
		}

		$index = $_GET['fieldindex'];
		if( !isset($this->lists[$list_index]['fields'][$index]) ){
			message($langmessage['OOPS'].' (Index Not Found)');
			return false;
		}

		return $index;
	}
	function GetListIndex(){
		return $this->GetIndex('index',$this->lists);
		global $langmessage;

		if( !isset($_REQUEST['index']) ){
			message($langmessage['OOPS'].' (Invalid Index)');
			return false;
		}

		$index = $_REQUEST['index'];
		if( !isset($this->lists[$index]) ){
			message($langmessage['OOPS'].' (Index Not Found)');
			return false;
		}
		return $index;
	}
	function GetListNameByIndex($listIndex){
		if (array_key_exists($listIndex,$this->lists)) {
			return $this->lists[$listIndex]['name'];
		}
		return '';
	}
	function GetViewNameByIndex($listIndex,$viewIndex){
		if (array_key_exists($listIndex,$this->lists)) {
			if (array_key_exists($viewIndex,$this->lists[$listIndex]['views'])) {
				return $this->lists[$listIndex]['views'][$viewIndex]['name'];
			}
		}
		return '';
	}
	function GetViewsSource(){
		$source=array();
		foreach ((array)$this->lists as $listIndex=>$list) {    //foreach() argument must be of type array|object, null given
			foreach ($list['views']as $viewIndex=>$view) {
				$source[]=array($view['name'],$list['name'],$viewIndex,$listIndex);
			}
		}
		return $source;
	}
}
?>
