<?php
defined('is_running') or die('Not an entry point...');

includeFile('admin/admin_uploaded.php');

class sitelist_browser extends admin_uploaded{
	
	function __construct(){
		global $page;

		//$_REQUEST += array('gpreq' => 'body'); //force showing only the body as a complete html document
		$page->get_theme_css = false;

		$page->head .= '<style type="text/css">';
		$page->head .= 'html,body{padding:0;margin:0;background-color:#ededed !important;background-image:none !important;border:0 none !important;}';
		$page->head .= '#gp_admin_html{padding:5px 0 !important;}';
		$page->head .= '</style>';

		$this->Finder();
	}

	function Finder(){
		global $page, $GP_INLINE_VARS, $config, $dataDir;

		$GP_INLINE_VARS['admin_resizable'] = false;

		$page->head .= "\n".'<link rel="stylesheet" type="text/css" media="screen" href="'.common::GetDir('/include/thirdparty/finder/css/finder.css').'">';
		$page->head .= "\n".'<link rel="stylesheet" type="text/css" media="screen" href="'.common::GetDir('/include/thirdparty/finder/style.css').'">';

		$page->head .= "\n".'<script type="text/javascript" src="'.common::GetDir('/include/thirdparty/finder/js/finder.js').'"></script>';
		//$page->head .= "\n".'<script type="text/javascript" src="'.common::GetDir('/include/thirdparty/finder/config.js').'"></script>';


		echo '<div id="finder"></div>';

		common::LoadComponents('selectable,draggable,droppable,resizable,dialog,slider,button');



		//get the finder language
		$language = $config['langeditor'];
		if( $language == 'inherit' ){
			$language = $config['language'];
		}
		$lang_file = '/include/thirdparty/finder/js/i18n/'.$language.'.js';
		$lang_full = $dataDir.$lang_file;
		if( file_exists($lang_full) ){
			$page->head .= "\n".'<script type="text/javascript" src="'.common::GetDir($lang_file).'"></script>';
		}else{
			$language = 'en';
		}
		$this->finder_opts['lang'] = $language;


		$this->FinderPrep();
		$page->head_script .= "\n".'var finder_opts = '.json_encode($this->finder_opts).';';
	}
	function FinderPrep(){
		$this->finder_opts['url'] = common::GetUrl('Admin_Finder');
		$this->finder_opts['getFileCallback'] = true;
	}

}
?>
