<?php
defined('is_running') or die('Not an entry point...');

gpPlugin::incl('controller/SiteListCommon.php','require_once');

class SiteListGadget extends SiteListCommon{

	function __construct(){
		$this->InitVars();
	//	$this->load_list_archives();
		$this->Run();
	//	SiteListCommon::AddCSS();
	}
	function InitVars($position=0){
		parent::InitVars();
		$this->position=$position;
		$this->gadgets=new SiteListArray($this->addonPathDataCurrent,'gadgets');
		if (!isset($this->gadgets->array[$this->position])) {
			$this->gadgets->array[$this->position]=array();
		}
		$this->array=&$this->gadgets->array[$this->position];
	}

	/**
	 *  Print all archives and their contents on gadget
	 *
	 */
	function Run(){
		global $page,$langmessage;

		$siteList = new SiteListCommon();
		$content=!empty($this->array['contentKey'])?$siteList->cache->Read($this->array['contentKey']):'Site List Gadget';
		$wrap = gpOutput::ShowEditLink('Admin_SiteList');
		$permission = class_exists('admin_tools') && admin_tools::HasPermission('Admin_SiteList');
		if( $wrap && $permission ){
		$page_index=$page->gp_index;
		$page_title=$page->title;
			ob_start();
			$edit_link = gpOutput::EditAreaLink($edit_index,'Admin_SiteList',$langmessage['edit'],'file='.$page_title.'&position='.$this->position.'&page_index='.$page_index.'&page_title='.$page_title,' title="Site List Gadget" name="inline_edit_generic" data-cmd="inline_edit_generic" ');
			echo '<span class="nodisplay" id="ExtraEditLnks'.$edit_index.'">';
			echo $edit_link;
			echo '</span>';
			gpOutput::$editlinks .= ob_get_clean();

			echo '<div class="editable_area" id="ExtraEditArea'.$edit_index.'">'; 
			echo !empty($content)?$content:'<p>&nbsp;</p';
			echo '</div>';
		}else{
			echo $content;
		}
	}
	static function InlineEdit(){
		global $addonPathCode,$page;
		
		$admin_link=common::GetUrl('Admin_SiteList');
		$page_index=$_REQUEST['page_index'];//$page->gp_index;
		$page_title=$_REQUEST['page_title'];//$page->title;
		echo 'var gpSiteListView={admin_link:"'.$admin_link.'",page_index:"'.$page_index.'",page_title:"'.$page_title.'"};';

		$data = array();
		$data['type'] = 'sitelist_gadget';
		$data['content'] = '<p> </p>';

		$script= $addonPathCode.'/view/js/gadget_edit.js';
		readfile($script);
		echo ';';

		includeFile('tool/ajax.php');
		gpAjax::InlineEdit($data);
	}
	static function InlineEditDialog(){
		global $page,$langmessage,$config;

		//$position=& $_GET['position'];
		$gadget=new SiteListGadget();
		$listIndex = isset($gadget->array['index'])?$gadget->array['index']:'';
		$viewIndex = isset($gadget->array['view_index'])?$gadget->array['view_index']:'';

		$siteList = new SiteListCommon();

		$file_content = $siteList->GetViewNameByIndex($listIndex,$viewIndex);

		ob_start();
		echo '<form id="gp_include_form">';

		echo '<div class="gp_inlude_edit">';
		echo '<span class="label">';
		echo 'List View';
		echo '</span>';
		echo '<input type="text" size="" id="gp_file_include" name="file_include" class="autocomplete" value="'.htmlspecialchars($file_content).'" />';
		echo '<input type="hidden" name="index" value="'.$listIndex.'" />';
		echo '<input type="hidden" name="viewindex" value="'.$viewIndex.'" />';
		echo '</div>';

		echo '<div id="gp_option_area">';
		echo '<a href="#" name="gp_include_preview" class="ckeditor_control full_width">Preview</a>';
		echo '</div>';

		echo '</form>';

		$content = ob_get_clean();
		$page->ajaxReplace = array();
		$page->ajaxReplace[] = array('gp_include_dialog','',$content);

		//include autocomplete
		$code = 'var source='.json_encode( $siteList->GetViewsSource() ).';';

		$page->ajaxReplace[] = array('gp_autocomplete_include','file',$code);
	}
	static function InlineSave(){
		global $page;

		//$position=& $_REQUEST['position'];
		$gadget=new SiteListGadget();
		$siteList = new SiteListCommon();

		if (!empty($_REQUEST['file_include']) && ($listIndex=$siteList->GetListIndex()) && ($viewIndex=$siteList->GetViewIndex($listIndex))) {
			//$content = $siteList->RenderView($viewIndex, $listIndex);
			//$gadget->array['content']=$content;
			$gadget->array['contentKey']=$siteList->GetViewTemplateKey($listIndex,$viewIndex);
			$gadget->array['index']=$listIndex;
			$gadget->array['view_index']=$viewIndex;
		}else {
		//	$gadget->array['content']='';//'<p>Site List Include</p>';
			$gadget->array['index']=null;
			$gadget->array['view_index']=null;
		}
		$gadget->gadgets->Save();

		$page->ajaxReplace[] = array('ck_saved','','');
		return true;
	}
}
?>
