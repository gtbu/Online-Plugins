<?php
defined('is_running') or die('Not an entry point...');

//gpPlugin::incl('model/lib/fSQL/fSQL.php','require_once');

abstract class AdminSiteListModel{
	
	public $DbName='SiteList';
	const SiteListTableName='SiteList';
	
	public $DefaultListFields=array(
	      'a' => 
	      array (
		'name' => 'Date',
		'type' => 4,
		'slug' => 'date',
		'visible' => true,
		'tip' => '',
		'validation' => 
		array (
		),
		'table' => 'SiteList',
		),
	      'b' => 
	      array (
		'name' => 'Title',
		'type' => 0,
		'slug' => 'title',
		'visible' => true,
		'tip' => '',
		'validation' => 
		array (
		),
		'table' => 'SiteList',
		),
	      'c' => 
	      array (
		'name' => 'Slug',
		'type' => 0,
		'slug' => 'slug',
		'visible' => false,
		'tip' => '',
		'validation' => 
		array (
		),
		'table' => 'SiteList',
		),
	      'd' => 
	      array (
		'name' => 'Content',
		'type' => 1,
		'slug' => 'content',
		'visible' => true,
		'tip' => '',
		'validation' => 
		array (
		),
		'table' => 'SiteList',
		),
	);
	abstract protected function Init($path);
	abstract protected function Install();
	abstract protected function query($sql);
	abstract protected function error();
	abstract protected function fetch_row($resource);//index
	abstract protected function fetch_array($resource);//both
	abstract protected function free_result($resource);
	abstract protected function insert_id();
	abstract protected function real_escape_string($string);
}

class sqliteAdminSiteListModel extends AdminSiteListModel{
	function Init($path=null){
		if (is_null($path)) {
			global $addonPathData;
			$this->path=$addonPathData;
		}else {
			$this->path=$path;
		}
		$DatabaseFilename=$this->path.'/'.$this->DbName.'.db';
		$this->handle = new SQLite3($DatabaseFilename);
	}
	
	//assuming already Init'ed -- AdminSiteListModel::Install
	function Install(){
		$this->CreateListTable();
	} 

	//basic db functions
	function query($sql){
		return $this->handle->query($sql);
	}
	function error($sql=''){
		return $sql.$this->handle->lastErrorMsg();
		return $sql.$this->handle->lastErrorCode().$this->handle->lastErrorMsg();
	}
	function fetch_row($resource){
		if ($resource)
		return $resource->fetchArray(SQLITE3_NUM);
	}
	function fetch_array($resource){
		if ($resource)
		return $resource->fetchArray(SQLITE3_BOTH);
	}
	function free_result($resource){
		if ($resource)
		return $resource->finalize();
	}
	function insert_id(){
		return $this->handle->lastInsertRowID();
	}
	function real_escape_string($string){
		return $this->handle->escapeString($string);
	}

	//specialized data functions
	function ItemCount($table){
		$sql='SELECT COUNT (*) FROM '.$table;
		$result=$this->handle->query($sql) or message($this->error($sql));
		$row=$this->fetch_row($result);
		if ($row)
			return $row[0];
		else {
			return 0;
		}
	}
	function ConvertTypeToDefinition($type){
		switch($type){
			default:
			case 0://text
			case 2://site file
			case 3://hidden
				$def=' VARCHAR(255) ';
			break;
			case 1://text area
				$def=' TEXT ';
			break;
			case 4://datetime
				$def=' DATETIME ';
			break;
			case 5://number
				$def=' INTEGER ';
			break;
			case 6://number
				$def=' FLOAT ';
			break;
		}
		return $def;
	}
	function isOk($return,$sql){
		if ($return){
			return $return;
		}else {
			message($this->error($sql));
			return False;
		}
	}
	function FindAuthor($values,$create=False){
		$where=array();
		foreach ($values as $key=>$value) {
			if (!empty($value)) {
				$where[]=sprintf('%s = \'%s\'',$key,$this->real_escape_string($value));
				//$where[]=sprintf('%s = \'%s\' COLLATE NOCASE',$key,$this->real_escape_string(trim($value)));
			}
		}
		$sql='SELECT id FROM '.self::SiteListTableName.'Author WHERE '.implode(' AND ',$where);
		$result=$this->handle->query($sql);
		$row=$this->fetch_row($result);
		if ($row && isset($row[0])) {
			return $row[0];
		}

		//not found, create?
		if (!$create) {
			return False;
		}

		$columns=array_keys($values);
		$sql='INSERT INTO '.self::SiteListTableName.'Author ('.implode(',',$columns).') VALUES (\''.implode('\',\'',$values).'\') ';
		if($this->isOk($this->handle->query($sql),$sql)){
			return $this->insert_id();
		}else {
			return False;
		}
	}
	function AddItem($table,$fields,$values){
		//find author id
		global $gpAdmin;
		$author_values=array(
			'ip' => \gp\tool\Session::clientIP(true),   // gpsession --- self::clientIP ?
			'username' =>  $gpAdmin['username'],
			'client' => $_SERVER['HTTP_USER_AGENT'],//gpsession::auth_browseruid(), 
			);
		$author_id=$this->FindAuthor($author_values,True);

		//save savelist table data
		$columns=array_keys($this->FilteredFields(self::SiteListTableName,$fields,False));
		$sqlvalues=array();
		foreach ($columns as $key) {
			$sqlvalues[]=$this->real_escape_string($values[$key]);
		}
		$columns[]='f';
		$sqlvalues[]=$table;
		$columns[]='g';
		$sqlvalues[]=$author_id;
		$sql='INSERT INTO '.self::SiteListTableName.' ('.implode(',',$columns).') VALUES (\''.implode('\',\'',$sqlvalues).'\') ';
		if($this->isOk($this->handle->query($sql),$sql)){
			$id=$this->insert_id();

			//save custom table data
			$columns=array_keys($this->FilteredFields($table,$fields));
			$sqlvalues=array();
			foreach ($columns as $key) {
				$sqlvalues[]=$this->real_escape_string($values[$key]);
			}
			$columns[]='id';
			$sqlvalues[]=$id;
			$sql='INSERT INTO '.$table.' ('.implode(',',$columns).') VALUES (\''.implode('\',\'',$sqlvalues).'\') ';
			return $this->isOk($this->handle->query($sql),$sql);
		}else {
			return False;
		}
	}
	function AddField($table,$field,$type){
		$sql='ALTER TABLE '.$this->real_escape_string($table).' ADD COLUMN '.$field.' '.$this->ConvertTypeToDefinition($type);
		return $this->isOk($this->handle->query($sql),$sql);
	}
	function DeleteItem($table,$id){
		$sql='DELETE FROM '.$this->real_escape_string($table).' WHERE id='.$this->real_escape_string($id);
		if($this->isOk($this->handle->query($sql),$sql)){
			$sql='DELETE FROM '.self::SiteListTableName.' WHERE id='.$this->real_escape_string($id);
			return $this->isOk($this->handle->query($sql),$sql);
		}
		return False;
	}
	//cannot alter table drop column
	function DropField($table,$field,$fields){
		$table=$this->real_escape_string($table);
		$columns=array_keys($this->FilteredFields($table,$fields));
//		if (count($columns)) {
			array_unshift($columns,'id');
			$columns=implode(',',$columns);
			$temptable=$table.'TEMP';
			$this->CreateTable($temptable,$fields);
			$sql='INSERT INTO '.$temptable.' SELECT '.$columns.' FROM '.$table;
			if ($this->handle->query($sql) or message($this->error($sql))){
				if ($this->RenameTable($table,$table.'MOVING')){
					if ($this->RenameTable($temptable,$table)){
						$this->DropTable($table.'MOVING');
						return True;
					}
				}else{
					message('DB not syncd');
				}
			}
			$this->DropTable($temptable);
			return False;
/*
		}else {
			$this->DropTable($table);
			$this->CreateTable($table,$fields);
		}
*/
		//return $this->handle->query('ALTER TABLE '.$table.' DROP COLUMN '.$field) or message($this->error());
	}
	function DropTable($table){
		$sql='DROP TABLE '.$this->real_escape_string($table);
		return $this->handle->query($sql) or message($this->error($sql));
	}
	function GetColumnLength($view,$lists){
		$max=0;
		foreach ($view['items'] as $array) {
			$count=count($lists[$array['table']]['fields']);
			if ($count>$max) {
				$max=$count;
			}
		}
		return $max;
	}
	function SelectViewItems($view,$lists,$page=null){
		//$length=$this->GetColumnLength($view,$lists);
		$sql=array();
		foreach($view['items'] as $key=>$data){
			$table=$data['table'] ?? null;  //Undefined array key "table"
    	$columns=array();		//$columns=array('\''.$table.'\'','a1.id')+array_keys($lists[$table]['fields']);
			 if(isset($lists[$table]['fields'])) {
			 $columns=array_keys($lists[$table]['fields']); }//Undefined array key ""
			
			array_unshift($columns,'a1.id');
			array_unshift($columns,'\''.$key.'\'');
			array_unshift($columns,'\''.$table.'\'');
			$columns=implode(',',$columns);
			//ORDER BY
			$order=array();
			foreach ($data['order']??[] as $orderrow) {   //Undefined array key "order"
				if ($orderrow['key']) {
					$order[]='a2.'.$orderrow['key'].($orderrow['asc']?' ASC ':' DESC ');
				}
			}
			$order=implode(',',$order);
			if ($order) {
				$order=' ORDER BY '.$order;
			}
			//LIMIT
			$limit='';
			if (!empty($data['limit']) && $data['limit']>-1) {
				$limit=' LIMIT '.$data['limit'];
			}

			$sql[]=' SELECT '.$columns.' FROM '.self::SiteListTableName.' a1 LEFT OUTER JOIN '.$table.' a2 ON a1.id=a2.id WHERE f=\''.$table.'\''.$order.$limit.' ';
		}
		//PAGINATION
		$pagination='';
		if (!empty($view['pagination_size']) && $view['pagination_size']>-1) {
			$pagination.=' LIMIT '.$view['pagination_size'];

			if ($view['pagination_start'] && is_null($page)) {
				$pagination.=' OFFSET '.($view['pagination_size']*$view['pagination_start']);
			}else {
				$pagination.=' OFFSET '.($view['pagination_size']*$page);
			}
		}
		$sql='SELECT * FROM ( '.implode(' UNION ALL ',$sql).' ) '.$pagination;
		return $this->isOk($this->handle->query($sql),$sql);  //SQLite3::query(): Unable to prepare statement: 1, no such table: a2
	}
	function SelectItems($table,$columns=null,$page=0){
		if (is_null($columns)) {
			$columns=array('*');
		}else {
			array_unshift($columns,'a1.id');
		}
		$sql='SELECT '.implode(',',$columns).' FROM '.self::SiteListTableName.' a1 LEFT OUTER JOIN '.$this->real_escape_string($table).' a2 ON a1.id=a2.id WHERE f=\''.$this->real_escape_string($table).'\'';
		//$sql='SELECT '.self::SiteListTableName.'.id,'.$columns.' FROM '.self::SiteListTableName.' a1 LEFT OUTER JOIN '.$table.' a2 ON '.self::SiteListTableName.'.id='.$table.'.id ';
		return $this->isOk($this->handle->query($sql),$sql);
	}
	function SelectItem($table,$id,$columns=null){
		if (is_null($columns)) {
			$columns=array('*');
		}else {
			array_unshift($columns,'a1.id');
		}
		$sql='SELECT '.implode(',',$columns).' FROM '.self::SiteListTableName.' a1 LEFT OUTER JOIN '.$this->real_escape_string($table).' a2 ON a1.id=a2.id WHERE f=\''.$this->real_escape_string($table).'\' AND a1.id='.(int)$id;
		//$sql='SELECT '.self::SiteListTableName.'.id,'.$columns.' FROM '.self::SiteListTableName.' a1 LEFT OUTER JOIN '.$table.' a2 ON '.self::SiteListTableName.'.id='.$table.'.id ';
		return $this->isOk($this->handle->query($sql),$sql);
	}
	function GetFieldValue($value,$type){
		if (empty($value)) {
			return ' NULL ';
		}
		switch($type){
			case 6://number
				$value=(float) $value;
			break;
			case 5://number
				$value=(int) $value;
			break;
			default:
				$value='\''.$this->real_escape_string($value).'\'';
		}
		return $value;
	}
	function UpdateItem($id,$values,$fields){
		$tables=array();
		foreach ($values as $column=>$value) {
			$field=$fields[$column];
			if (!isset($tables[$field['table']])) {
				$tables[$field['table']]=array();
			}
			//$tables[$field['table']][$column]=$this->GetFieldValue($values[$index],$field['type']);
			$tables[$field['table']][]=$column.' = '.$this->GetFieldValue($value,$field['type']);
		}
		$ok=True;
		//do a transaction
		foreach ($tables as $table=>$settings) {
			$sql='UPDATE '.$table.' SET '.implode(',',$settings).' WHERE id='.(int)$id;
			//$sql='SELECT '.self::SiteListTableName.'.id,'.$columns.' FROM '.self::SiteListTableName.' a1 LEFT OUTER JOIN '.$table.' a2 ON '.self::SiteListTableName.'.id='.$table.'.id ';
			$ok=$ok && $this->isOk($this->handle->query($sql),$sql);
		}
		return $ok;
	}
	
	function RenameTable($table,$newtable){
		$sql='ALTER TABLE '.$this->real_escape_string($table).' RENAME TO '.$this->real_escape_string($newtable);
		return $this->handle->query($sql) or message($this->error($sql));
	}
	
	function FilteredFields($table,$fields,$assumeUnsetIsSameTable=True){
		$filtered=array();
		foreach($fields as $name=>$data){
			if ((isset($data['table']) && $data['table']!=$table) || !$assumeUnsetIsSameTable && !isset($data['table'])) {
				continue;
			}
			$filtered[$name]= $data;
		}
		return $filtered;
	}
	
	function CreateTable($table,$fields=array()){
		$sql_fields=array(' id INTEGER ');
		foreach($this->FilteredFields($table,$fields) as $name=>$data){
			$type = $data['type'];
			$sql_fields[]=$name.$this->ConvertTypeToDefinition($type);
		}
		
		$sql='CREATE TABLE '.$table.'(
		   '.implode(',',$sql_fields).', 
		   PRIMARY KEY(id)
		)';
		return $this->handle->query($sql) or message($this->error($sql));
	}
	
	function CreateListTable(){
		$sql='CREATE TABLE '.self::SiteListTableName.'Author (
			id INTEGER,
			username VARCHAR(255),
			ip VARCHAR(255),
			client VARCHAR(255),
			PRIMARY KEY(id)
		)';
		$this->handle->query($sql) or message($this->error($sql));  //table SiteListAuthor already exists -> line 86,33,13,51

/*

			id BIGINT,
			date DATETIME,
			title TEXT,
			slug VARCHAR(200),
			content LONGTEXT,
			status VARCHAR(20),
			type VARCHAR(20),
			author INTEGER,
			PRIMARY KEY(id)
*/
		$sql='CREATE TABLE '.self::SiteListTableName.'(
			id INTEGER,
			a DATETIME,
			b TEXT,
			c VARCHAR(200),
			d LONGTEXT,
			e VARCHAR(20),
			f VARCHAR(20),
			g INTEGER,
			PRIMARY KEY(id)
		)';
		return $this->handle->query($sql) or message($this->error($sql));
	}
}

class fsqlAdminSiteListModel extends AdminSiteListModel{

	function Init($path){
		global $addonPathData;
		$this->fsql = new fSQLEnvironment;
		$this->fsqlDB ='SiteList';
		$this->fsql->define_db($this->fsqlDB, $addonPathData);//.'/DB/SiteList');
		$this->fsql->select_db($this->fsqlDB);
	}
	
	function Install(){
	}
	
	function query($sql){
		return $this->fsql->query($sql);
	}
	
	function error(){
		return $this->fsql->error();
	}
	function fetch_row($resource){
		return $this->fsql->fetch_row($resource);
	}
	function fetch_array($resource){
		return $this->fsql->fetch_row($resource);
	}
	
	function free_result($resource){
		return $this->fsql->free_result($resource);
	}
	
	function insert_id(){
	}
	
	function real_escape_string($string){
	}

	function AddField($table,$field,$type){
		$temptable=$table.'TEMP';
		$columns=array_keys($this->lists[$table]['fields']);
		$columns=implode(',',array_pop($columns));
		$this->CreateTable($temptable,$this->lists[$table]['fields']);
		if ($this->fsql->query('INSERT INTO '.$temptable.' SELECT '.$columns.' FROM '.$table) or message($this->fsql->error())){
			if ($this->RenameTable($table,$table.'MOVING')){
				if ($this->RenameTable($temptable,$table)){
					$this->DropTable($table.'MOVING');
				}
			}else{
				$this->DropTable($temptable);
				message('DB not syncd');
			}
		}
	
	}
	//fsql doesn't support alter columns
	function AddField1($table,$field,$type){
		switch($type){
			default:
			case 0://text
			case 2://site file
			case 3://hidden
				$def=' VARCHAR(255) ';
			break;
			case 1://text area
				$def=' TEXT ';
			break;
		}
		$this->fsql->query('ALTER TABLE `'.$this->fsqlDB.'`.`'.$table.'` ADD COLUMN `'.$field.'` '.$def.';') or message($this->fsql->error());
	}
	
	function DropField($table,$field){
		$temptable=$table.'TEMP';
		$columns=array_keys($this->lists[$table]['fields']);
		$columns=implode(',',$columns);
		$this->CreateTable($temptable,$this->lists[$table]['fields']);
		if ($this->fsql->query('INSERT INTO '.$temptable.' SELECT '.$columns.' FROM '.$table) or message($this->fsql->error())){
			if ($this->RenameTable($table,$table.'MOVING')){
				if ($this->RenameTable($temptable,$table)){
					$this->DropTable($table.'MOVING');
				}
			}else{
				$this->DropTable($temptable);
				message('DB not syncd');
			}
		}
	
	}
	function DropField1($table,$field){
		$this->fsql->query('ALTER TABLE '.$this->fsqlDB.'.'.$table.' DROP '.$field.'
		') or message($this->fsql->error());
	}
	function DropTable($table){
		$this->fsql->query('DROP TABLE '.$table) or message($this->fsql->error());
	}
	function SelectItems($table,$columns='*',$page=0){
		return $this->fsql->query('SELECT '.$columns.' FROM '.$table) or message($this->fsql->error());
	}

	function RenameTable($table,$newtable){
		return $this->fsql->query('ALTER TABLE '.$table.' RENAME TO '.$newtable) or message($this->fsql->error());
	}
	function CreateTable($table,$fields=array()){
		$sql='';
		foreach($fields as $name=>$data){
			$type = $data['type'];
			switch($type){
				default:
				case 0://text
				case 2://site file
				case 3://hidden
					$sql.=$name.' VARCHAR(255), ';
				break;
				case 1://text area
					$sql.=$name.' TEXT, ';
				break;
				case 4://datetime
					$sql.=$name.' DATETIME, ';
				break;
				case 5://number
					$sql.=$name.' INT, ';
				break;
				case 6://number
					$sql.=$name.' FLOAT, ';
				break;
			}
		}
		$this->fsql->query('CREATE TABLE '.$table.'(
		   id INT NOT NULL AUTO_INCREMENT, '.$sql.'
		   PRIMARY KEY(id)
		)') or message($this->fsql->error());
	}
}
?>
