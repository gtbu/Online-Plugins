<?php

defined('is_running') or die('Not an entry point...');

class Event_Calendar_Admin
{
	function  __construct()
	{
		global $langmessage, $addonPathData, $addonPathCode;
		
		include_once $addonPathCode.'/Event_Calendar_Lib.php';
		include_once $addonPathCode.'/Event_Calendar_Common.php';

		$datefile = '/date_data';
		$configfile = '/config_data';
		
		$datesdata = '';
		$event_settings = array();

		if (isset($_POST['sendbutton'])) //settings
		{
			if (is_numeric($_POST['language']))
			{
				$event_settings['language'] = (int)$_POST['language'];
			}
			
			$event_settings['event_list_page_show_past'] = (string)$_POST['event_list_page_show_past'];
			
			$event_settings['event_list_page_tile'] = (string)$_POST['event_list_page_tile'];
			
			if (isset($_POST['show_event_list_page_tile']))
			{
				$event_settings['show_event_list_page_tile'] = true;
			}
			else
			{
				$event_settings['show_event_list_page_tile'] = false;
			}
			
			$event_settings['event_yearly_view_page_tile'] = (string)$_POST['event_yearly_view_page_tile'];
			
			if (isset($_POST['show_event_yearly_view_page_tile']))
			{
				$event_settings['show_event_yearly_view_page_tile'] = true;
			}
			else
			{
				$event_settings['show_event_yearly_view_page_tile'] = false;
			}
			
			if (isset($_POST['highlight_today']))
			{
				$event_settings['highlight_today'] = true;
			}
			else
			{
				$event_settings['highlight_today'] = false;
			}
			
			if (isset($_POST['show_gadget_header']))
			{
				$event_settings['show_gadget_header'] = true;
			}
			else
			{
				$event_settings['show_gadget_header'] = false;
			}
			
			if (isset($_POST['show_gadget_footer']))
			{
				$event_settings['show_gadget_footer'] = true;
			}
			else
			{
				$event_settings['show_gadget_footer'] = false;
			}

			if (isset($_POST['show_half_day']))
			{
				$event_settings['show_half_day'] = true;
			}
			else
			{
				$event_settings['show_half_day'] = false;
			}
			
			if (isset($_POST['half_day_angle']))
			{
				$event_settings['half_day_angle'] = $_POST['half_day_angle'];
			}
			else
			{
				$event_settings['half_day_angle'] = 45;
			}
			
			if (isset($_POST['occupancy_plan_mode']))
			{
				$event_settings['occupancy_plan_mode'] = true;
			}
			else
			{
				$event_settings['occupancy_plan_mode'] = false;
			}
						
			$event_settings['occupancy_plan_replacement_text'] = (string)$_POST['occupancy_plan_replacement_text'];
			
			$event_settings['calendars_cache_lifetime'] = (string)$_POST['calendars_cache_lifetime'];
			
			$event_settings['calendars'] = (string)$_POST['calendars'];
			
			gpFiles::SaveArray($addonPathData.$configfile, 'event_settings', $event_settings);
			
			if (isset($_POST['dates']))
			{
				$datesdata = (string)$_POST['dates'];
				gpFiles::Save($addonPathData.$datefile, $datesdata);
			}
			message($langmessage['SAVED']);
		}
		
		if ( file_exists($addonPathData.$configfile) )
		{
			require($addonPathData.$configfile);
		}
		else
		{
			require($addonPathCode.$configfile);
		}		

		if ($event_settings['calendars_cache_lifetime'] == '')
		{
			$event_settings['calendars_cache_lifetime'] = 3600;
		}

		if ( file_exists($addonPathData.$datefile) )
		{
			$datesdata = file_get_contents($addonPathData.$datefile);
		}
		
		echo '<form name="date_input" action="'.common::GetUrl('Admin_Event_Calendar').'" method="post">';
		
		echo '<table style="width:100%" class="bordered">';
		
		echo '<tr>';
			echo '<th>';
			echo 'Option';
			echo '</th>';
			echo '<th>';
			echo 'Value';
			echo '</th>';
		echo '</tr>';

		echo '<tr>';
			echo '<td>';
			echo 'Language';
			echo '</td>';
			echo '<td>';
			echo '<select name="language" class="gpselect">';
				if ($event_settings['language'] == 0)
				{
					echo '<option value="1">English</option>';
					echo '<option value="0" selected="selected">Deutsch</option>';
					echo '<option value="2">Francais</option>';
				}
				elseif ($event_settings['language'] == 2)
				{
					echo '<option value="1">English</option>';
					echo '<option value="0">Deutsch</option>';
					echo '<option value="2" selected="selected">Francais</option>';
				}
				else
				{
					echo '<option value="1" selected="selected">English</option>';
					echo '<option value="0">Deutsch</option>';
					echo '<option value="2">Francais</option>';
				}
			echo '</select>';
			echo '</td>';
		echo '</tr>';

		echo '<tr>';
			echo '<td>';
			echo 'Event List Page Show Past Events (0 = No Past Events, 1..9999 = Show Events expired since x days)';
			echo '</td>';
			echo '<td>';
			echo '<input type="text" name="event_list_page_show_past" size="5" value="'.$event_settings['event_list_page_show_past'].'" class="gpinput" />';
			echo '</td>';
		echo '</tr>';		
				
		echo '<tr>';
			echo '<td>';
			echo 'Event List Page Title';
			echo '</td>';
			echo '<td>';
			echo '<input type="text" name="event_list_page_tile" size="40" value="'.$event_settings['event_list_page_tile'].'" class="gpinput" />';
			echo '</td>';
		echo '</tr>';
		
		echo '<tr>';
			echo '<td>';
			echo 'Show Event List Page Title';
			echo '</td>';
			echo '<td>';
			if($event_settings['show_event_list_page_tile'] == true)
			{
				echo '<input type="checkbox" name="show_event_list_page_tile" value="allow" checked="checked" />';
			}
			else
			{
				echo '<input type="checkbox" name="show_event_list_page_tile" value="allow" />';
			}
			echo '</td>';
		echo '</tr>';
		
		echo '<tr>';
			echo '<td>';
			echo 'Event Yearly View Page Title';
			echo '</td>';
			echo '<td>';
			echo '<input type="text" name="event_yearly_view_page_tile" size="40" value="'.$event_settings['event_yearly_view_page_tile'].'" class="gpinput" />';
			echo '</td>';
		echo '</tr>';
		
		echo '<tr>';
			echo '<td>';
			echo 'Show Event Yearly View Page Title';
			echo '</td>';
			echo '<td>';
			if($event_settings['show_event_yearly_view_page_tile'] == true)
			{
				echo '<input type="checkbox" name="show_event_yearly_view_page_tile" value="allow" checked="checked" />';
			}
			else
			{
				echo '<input type="checkbox" name="show_event_yearly_view_page_tile" value="allow" />';
			}
			echo '</td>';
		echo '</tr>';
		
		echo '<tr>';
			echo '<td>';
			echo 'Highlight today in Gadget';
			echo '</td>';
			echo '<td>';
			if($event_settings['highlight_today'] == true)
			{
				echo '<input type="checkbox" name="highlight_today" value="allow" checked="checked" />';
			}
			else
			{
				echo '<input type="checkbox" name="highlight_today" value="allow" />';
			}
			echo '</td>';
		echo '</tr>';
		
		echo '<tr>';
			echo '<td>';
			echo 'Show Header with Link to List View in Gadget';
			echo '</td>';
			echo '<td>';
			if($event_settings['show_gadget_header'] == true)
			{
				echo '<input type="checkbox" name="show_gadget_header" value="allow" checked="checked" />';
			}
			else
			{
				echo '<input type="checkbox" name="show_gadget_header" value="allow" />';
			}
			echo '</td>';
		echo '</tr>';
		
		echo '<tr>';
			echo '<td>';
			echo 'Show Footer with Link to Yearly View in Gadget';
			echo '</td>';
			echo '<td>';
			if($event_settings['show_gadget_footer'] == true)
			{
				echo '<input type="checkbox" name="show_gadget_footer" value="allow" checked="checked" />';
			}
			else
			{
				echo '<input type="checkbox" name="show_gadget_footer" value="allow" />';
			}
			echo '</td>';
		echo '</tr>';

		echo '<tr>';
			echo '<td>';
			echo 'Show Half Days in Calendar / Half Day Angle';
			echo '</td>';
			echo '<td>';
			if($event_settings['show_half_day'] == true)
			{
				echo '<input type="checkbox" name="show_half_day" value="allow" checked="checked" />';
			}
			else
			{
				echo '<input type="checkbox" name="show_half_day" value="allow" />';
			}
			echo ' / <select name="half_day_angle" class="gpselect">';
				if ($event_settings['half_day_angle'] == 0)
				{
					echo '<option value="0" selected="selected">0 deg.</option>';
					echo '<option value="23">23 deg.</option>';
					echo '<option value="45">45 deg.</option>';
					echo '<option value="67">67 deg.</option>';
					echo '<option value="90">90 deg.</option>';
				}
				elseif ($event_settings['half_day_angle'] == 23)
				{
					echo '<option value="0">0 deg.</option>';
					echo '<option value="23" selected="selected">23 deg.</option>';
					echo '<option value="45">45 deg.</option>';
					echo '<option value="67">67 deg.</option>';
					echo '<option value="90">90 deg.</option>';
				}
				elseif ($event_settings['half_day_angle'] == 67)
				{
					echo '<option value="0">0 deg.</option>';
					echo '<option value="23">23 deg.</option>';
					echo '<option value="45">45 deg.</option>';
					echo '<option value="67" selected="selected">67 deg.</option>';
					echo '<option value="90">90 deg.</option>';
				}
				elseif ($event_settings['half_day_angle'] == 90)
				{
					echo '<option value="0">0 deg.</option>';
					echo '<option value="23">23 deg.</option>';
					echo '<option value="45">45 deg.</option>';
					echo '<option value="67">67 deg.</option>';
					echo '<option value="90" selected="selected">90 deg.</option>';
				}
				else
				{
					echo '<option value="0">0 deg.</option>';
					echo '<option value="23">23 deg.</option>';
					echo '<option value="45" selected="selected">45 deg.</option>';
					echo '<option value="67">67 deg.</option>';
					echo '<option value="90">90 deg.</option>';
				}
			echo '</select>';
			echo '</td>';
		echo '</tr>';
		
		echo '<tr>';
			echo '<td>';
			echo 'Occupancy Plan Mode';
			echo '</td>';
			echo '<td>';
			if($event_settings['occupancy_plan_mode'] == true)
			{
				echo '<input type="checkbox" name="occupancy_plan_mode" value="allow" checked="checked" />';
			}
			else
			{
				echo '<input type="checkbox" name="occupancy_plan_mode" value="allow" />';
			}
			echo '</td>';
		echo '</tr>';
		
		echo '<tr>';
			echo '<td>';
			echo 'Generic replacement text for Occupancy Plan Events';
			echo '</td>';
			echo '<td>';
			echo '<input type="text" name="occupancy_plan_replacement_text" size="40" value="'.$event_settings['occupancy_plan_replacement_text'].'" class="gpinput" />';
			echo '</td>';
		echo '</tr>';

		echo '<tr>';
			echo '<th>';
			echo 'List of ICS-Calendars';
			echo '</th>';
			echo '<th>';
			echo '';
			echo '</th>';
		echo '</tr>';

		echo '<tr>';
			echo '<td>';
			echo 'Calendar Cache Lifetime in Seconds';
			echo '</td>';
			echo '<td>';
			echo '<input type="text" name="calendars_cache_lifetime" size="10" value="'.$event_settings['calendars_cache_lifetime'].'" class="gpinput" />';
			echo '</td>';
		echo '</tr>';
				
		echo '<tr>';
			echo '<td colspan="2">';
			echo 'Format: Url-Link to ICS-File|(Optional:RGB-Color)|(Optional:Special Replacement Text for Events)<br>';
			echo 'Example: http://www.link.com/to/calendar.ics -> Calendar with standard color<br>';
			echo 'Example: http://www.link.com/to/calendar.ics|#FFDD00 -> Calendar with special color<br>';
			echo 'Example: http://www.link.com/to/calendar.ics|#FFDD00|Already Booked -> Calendar with special color and special replacement text<br>';
			echo 'Example: http://www.link.com/to/calendar.ics||Already Booked -> Calendar with standard color and special replacement text<br>';
			echo '</td>';
		echo '</tr>';
		
		echo '<tr>';
			echo '<td colspan="2">';
			echo '<textarea name="calendars" type="text" cols="80" rows="3" class="text" wrap="virtual">';
			echo $event_settings['calendars'];
			echo '</textarea>';
			echo '</td>';
		echo '</tr>';
				
		echo '<tr>';
			echo '<th>';
			echo 'List of Event Entrys';
			echo '</th>';
			echo '<th>';
			echo '';
			echo '</th>';
		echo '</tr>';
		
		echo '<tr>';
			echo '<td colspan="2">';
			echo 'Format: Beginning|End|Description|Link<br>';
			echo 'Format: DD-MM-YYYY|DD-MM-YYYY|Event Title|Event Link<br>';
			echo 'Example: 20-08-2010|22-08-2010|This is my event|http://www.google.com<br>';
			echo 'The pipe |  is the seperator, each line represents a single event.<br>';
			echo 'Both dates has to be set, for single day Events use the same day.<br>';
			echo 'The link is an optional field and has not to be set.<br>';
			echo 'A link starting with http is openend in a new window, a internal link is opened in the same window.';
			echo '</td>';
		echo '</tr>';
		
		echo '<tr>';
			echo '<td colspan="2">';
			echo '<textarea name="dates" type="text" cols="80" rows="15" class="text" wrap="virtual">';
			echo $datesdata;
			echo '</textarea>';
			echo '</td>';
		echo '</tr>';
		
		echo '</table><br>';
		
		echo '<input type="submit" name="sendbutton" value="'.$langmessage['save'].'" class="gpsubmit"/>';
		
		echo '</form>';
	}
}
?>
