<?php

defined('is_running') or die('Not an entry point...');

function strcontains($haystack, $needle)
{  
  if (strpos($haystack, $needle)!== false)  
    return true;  
  else  
    return false;  
}

function date_compare($a, $b)
{
  if ($a['0'] == $b['0']) {
    return 0;
  }

  return ($a['0'] < $b['0']) ? -1 : 1;
}

function Calendar_Get_Array()
{
	global $addonPathData, $addonPathCode;

	require_once $addonPathCode.'/Event_Calendar_iCalReader.php';
	
	$configfile = '/config_data';
	$event_settings = array();
	if(file_exists($addonPathData.$configfile))
	{
		require($addonPathData.$configfile);
	}
	else
	{
		require($addonPathCode.$configfile);
	}
	
	$datefile = '/date_data';
	
	$datearray = array();
	
	$calendars = array();
	$calendars = explode(PHP_EOL, $event_settings['calendars']);
	
	foreach($calendars as $singlecalendar)
	{
		$trimmed_singlecalendar = '';
		$trimmed_calendarcolor = '';
		$trimmed_calendartext = '';
		$calendarentry = explode('|', $singlecalendar, 3);
		if (sizeof($calendarentry) == 3)
		{
			$trimmed_singlecalendar = trim($calendarentry[0]);
			$trimmed_calendarcolor = trim($calendarentry[1]);
			$trimmed_calendartext = trim($calendarentry[2]);
		}
	    else if (sizeof($calendarentry) == 2)
		{
			$trimmed_singlecalendar = trim($calendarentry[0]);
			$trimmed_calendarcolor = trim($calendarentry[1]);
		}
		else
		{
			$trimmed_singlecalendar = trim($calendarentry[0]);
		}
		
		if (!empty($trimmed_singlecalendar))
		{
			$filemtime = @filemtime($addonPathData.'/'.$trimmed_singlecalendar);
			if(!file_exists($addonPathData.'/'.$trimmed_singlecalendar) || (!$filemtime or (time() - $filemtime >= $event_settings['calendars_cache_lifetime'])))
			{
				$calendarcontents = file_get_contents($trimmed_singlecalendar);
				gpFiles::Save($addonPathData.'/'.$trimmed_singlecalendar, $calendarcontents);
			}
		    
			$ical = new ICal($addonPathData.'/'.$trimmed_singlecalendar);
			$events = $ical->events();
			foreach ($events as $event)
			{
				$enddatum = new DateTime($event['DTEND']);
				$enddatum->modify('-1 minute');			
				if ($event_settings['occupancy_plan_mode'] == true)
				{
				  if ($trimmed_calendartext == '')
				  {
				    $datearray[] = array(new DateTime($event['DTSTART']), $enddatum, $event_settings['occupancy_plan_replacement_text'], '', $trimmed_calendarcolor);
				  }
				  else
				  {
					$datearray[] = array(new DateTime($event['DTSTART']), $enddatum, $trimmed_calendartext, '', $trimmed_calendarcolor);
				  }
				}
				else
				{
				  if ($trimmed_calendartext == '')
				  {
				    $datearray[] = array(new DateTime($event['DTSTART']), $enddatum, @$event['SUMMARY'].' '.@$event['DESCRIPTION'], @$event['URL'], $trimmed_calendarcolor);
				  }
				  else
				  {
					$datearray[] = array(new DateTime($event['DTSTART']), $enddatum, $trimmed_calendartext, @$event['URL'], $trimmed_calendarcolor);
				  }
	            }
			}
		}
	}

	if(file_exists($addonPathData.$datefile))
	{
		$datesdata = file_get_contents($addonPathData.$datefile);
		
		$zeilen = explode("\n", $datesdata);
		
		foreach($zeilen as $zeile)
		{
			$dateentry = explode('|', $zeile, 4);
			if(sizeof($dateentry) >= 3 && preg_match('/^\d{2}-\d{2}-\d{4}/', $dateentry[0]) == 1 && preg_match('/^\d{2}-\d{2}-\d{4}/', $dateentry[1]) == 1)
			{
				try
				{
					if ($event_settings['occupancy_plan_mode'] == true)
					{
						$dateentry[2] = $event_settings['occupancy_plan_replacement_text'];
					}
					if(sizeof($dateentry) == 3)
					{
						$datearray[] = array(new DateTime($dateentry[0]), new DateTime($dateentry[1]), $dateentry[2], '', '');
					}
					else
					{
						$datearray[] = array(new DateTime($dateentry[0]), new DateTime($dateentry[1]), $dateentry[2], $dateentry[3], '');
					}
				}
				catch (Exception $e)
				{
				}
			}
		}
	}
	
	// Sort array
	if(sizeof($datearray) > 1)
	{
		usort($datearray, 'date_compare');
	}
	return $datearray;
}
?>