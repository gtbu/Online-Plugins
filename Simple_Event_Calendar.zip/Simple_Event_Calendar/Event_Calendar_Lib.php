<?php
    class calendarlib
    {
        private $language = 0;
        private $link     = 1;
        private $mydate   = NULL;
        private $tag,$monat,$jahr;
        private $getVariable = 'mydate';
        

        private $arr_monate = array(
            array ('Januar', 'Februar', 'Maerz', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'),
            array ('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'),
            array ('Janvier', 'Fevrier', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Aout', 'Septembre', 'Octobre', 'Novembre', 'Decembre')
        );
        
        private $arr_Tage   = array(
            array ('Mo','Di','Mi','Do','Fr','Sa','So'),
            array ('Mon','Tue','Wed','Thu','Fri','Sat','Sun'),
            array ('Lu','Ma','Me','Je','Ve','Sa','Di')
        );

        private $events = array();

                
        private function isEvent($date)
        {
            return array_key_exists($date, $this->events);
        }
        
        private function getspezialLink($date, $isNavlnk=false)
        {
           
            if ($this->isEvent($date) && !$isNavlnk)
            {
                    return ($this->events[$date]['link'] != '') ? $this->events[$date]['link'].'?'.$this->getVariable.'='.$date : '?'.$this->getVariable.'='.$date;
            }
            
            return '?'.$this->getVariable.'='.$date;
           
        }
        
        private function getspezialTitle($date, $isNavlnk=false)
        {
           
            if ($this->isEvent($date) && !$isNavlnk)
            {
            	return $this->events[$date]['title'];
            }
            
            return '';
           
        }

        private function getspezialType($date, $isNavlnk=false)
        {
            if ($this->isEvent($date) && !$isNavlnk)
            {
	            $returnarray = array();
            	$returnarray['typeFull'] = $this->events[$date]['typeFull'];
            	$returnarray['specialcolor'] = $this->events[$date]['specialcolor'];
            	$returnarray['typeStart'] = $this->events[$date]['typeStart'];
            	$returnarray['specialcolorStart'] = $this->events[$date]['specialcolorStart'];
            	$returnarray['typeEnd'] = $this->events[$date]['typeEnd'];
            	$returnarray['specialcolorEnd'] = $this->events[$date]['specialcolorEnd'];
            	return $returnarray;
            }
            return false;
        }
        
        private function check_date($date,$format,$sep){
            $pos1    = strpos($format, 'd');
            $pos2    = strpos($format, 'm');
            $pos3    = strpos($format, 'Y'); 
            $check    = explode($sep,$date);
            return checkdate($check[$pos2],$check[$pos1],$check[$pos3]);
        }
        
        private function datetest(){
            $arr_mydate = explode('-', $this->mydate);
            if($arr_mydate[0]>=1 && $arr_mydate[0]<=31 &&
               $arr_mydate[1]>0 && $arr_mydate[1]<13 && 
               $arr_mydate[2] > 1970 && $arr_mydate[2]< 2038){
                $this->tag   = $arr_mydate[0];
                $this->monat = $arr_mydate[1];
                $this->jahr  = $arr_mydate[2];    
            }
            
            //Defaultwerte, wenn kein Monat/Jahr �bergeben wurde
            $this->tag   = (isset($this->tag)!==true) ? date("d",time()) : $this->monat;    
            $this->monat = (isset($this->monat)!==true) ? date("n",time()) : $this->monat;
            $this->jahr  = (isset($this->jahr)!==true)  ? date("Y",time()) : $this->jahr;
        }        
        
        public function __construct()
        {
        }        
        
        public function addEvent($tdate, $title, $speziallnk=NULL, $typeFull=false, $specialcolor='', $typeStart=false, $specialcolorStart='', $typeEnd=false, $specialcolorEnd='')
        {
            if ($this->check_date($tdate,"dmY","-"))
            {
              $tmp = explode('-', $tdate);

              $tdate  = (($tmp[0][0]=='0') ? $tmp[0][1] : $tmp[0]).
                        '-'.(($tmp[1][0]=='0') ? $tmp[1][1] : $tmp[1]).
                        '-'.$tmp[2];
              
              if($this->isEvent($tdate))
              {
                $this->events[$tdate]['title'] .= '&#10;'.$title;
              }
              else
              {
                $this->events[$tdate]['title'] = $title;
              }
              $this->events[$tdate]['link'] = $speziallnk;
              if ($typeFull == true)
              {
              	$this->events[$tdate]['typeFull'] = $typeFull;
              	$this->events[$tdate]['specialcolor'] = $specialcolor;
          	  }
              if ($typeStart == true)
              {
              	$this->events[$tdate]['typeStart'] = $typeStart;
              	$this->events[$tdate]['specialcolorStart'] = $specialcolorStart;
          	  }
          	  if ($typeEnd == true)
              {
                $this->events[$tdate]['typeEnd'] = $typeEnd;
                $this->events[$tdate]['specialcolorEnd'] = $specialcolorEnd;
              }
              return true;
            }
            else
            {
              return false;
            }
        }
        
        public function addEventData($eventdata)
        {
	        global $addonPathData, $addonPathCode;
            
            $configfile = '/config_data';
			$event_settings = array();
			if(file_exists($addonPathData.$configfile))
			{
				require($addonPathData.$configfile);
			}
			else
			{
				require($addonPathCode.$configfile);
			}
			
			foreach($eventdata as $singleevent)
			{
				for ($i = 0; $singleevent[0]->format("U") + (86400 * $i) <= $singleevent[1]->format("U"); $i++)
				{
					$date_to_entry = new DateTime();
					$date_to_entry = clone $singleevent[0];
					$date_to_entry->modify('+'.$i.' day');
					$typeFull = false;
					$specialcolor = '';
					$typeStart = false;
					$specialcolorStart = '';
					$typeEnd = false;
					$specialcolorEnd = '';
					if ($event_settings['show_half_day'] == false)
					{
						$typeFull = true;
						$specialcolor = $singleevent[4];
					}
					else if ($singleevent[0]->format("dmY") == $singleevent[1]->format("dmY"))
					{
						$typeFull = true;
						$specialcolor = $singleevent[4];
					}
					else if ($singleevent[0]->format("dmY") == $date_to_entry->format("dmY"))
					{
						$typeStart = true;
						$specialcolorStart = $singleevent[4];
					}
					else if ($singleevent[1]->format("dmY") == $date_to_entry->format("dmY"))
					{
						$typeEnd = true;
						$specialcolorEnd = $singleevent[4];
					}
					else
					{
						$typeFull = true;
						$specialcolor = $singleevent[4];
					}
					$this->addEvent($date_to_entry->format("d-m-Y"), $singleevent[2], common::GetUrl('Event_Calendar_List_Page'), $typeFull, $specialcolor, $typeStart, $specialcolorStart, $typeEnd, $specialcolorEnd);
				}
			}
		}
        
        public function setDate($caldate){
            $this->mydate = $caldate;
        }
        
        public function setDateWithGET(){
            if(isset($_GET[$this->getVariable]))
                $this->mydate = $_GET[$this->getVariable];
        }        
        
        public function setLinkTyp($lnk=1){
            $this->link = $lnk;
        }        
        
        public function setGETVariableName($newName){
          $this->getVariable = $newName;
        }
        
        
        public function setLanguage($lang)
        {
            if($lang>=0 && $lang<count($this->arr_monate))
            {
                $this->language = $lang;
        	}
        	else 
        	{
	        	$this->language = 1;
        	}
        }
        
        public function showCAL($imagePath)
        {
	        ob_start();
            $this->datetest();
            
            $actual_date = getdate();
            
            global $addonPathData, $addonPathCode;
            
            $configfile = '/config_data';
			$event_settings = array();
			if(file_exists($addonPathData.$configfile))
			{
				require($addonPathData.$configfile);
			}
			else
			{
				require($addonPathCode.$configfile);
			}
        
            $iWochenTag  = date("w", mktime(0, 0, 0, $this->monat, 1, $this->jahr));
            $iAnzahltage = date("t", mktime(0, 0, 0, $this->monat, 1, $this->jahr));
			$iZeilen1 =
            $iZeilen = (($iWochenTag==1 && $iAnzahltage==28) ? 4 : ( ($iAnzahltage == 31 && ($iWochenTag == 6 || $iWochenTag == 0)) || ($iWochenTag  == 0 && $iAnzahltage == 30)) ) ? 6 : 5; 

            //N�chster Monat
            if($this->monat==12){
                $nmonat=1;
                $njahr=$this->jahr+1;
            } else {
                $nmonat=$this->monat+1;
                $njahr=$this->jahr;  
            }

            //Vorheriger Monat    
            if($this->monat==1){
                $vmonat=12;
                $vjahr=$this->jahr-1;
            } else {
                $vmonat=$this->monat-1;
                $vjahr=$this->jahr;  
            }

            $iAnzahltageVormonat = date("t", mktime(0, 0, 0, $vmonat, 1, $vjahr));
            
            echo '<div align="center"><table id="cal"><tr>',
                  '<th>',
                  (($this->link==1 || $this->link==2 || $this->link==4) ? '<a href="'.$this->getspezialLink('1-'.$vmonat.'-'.$vjahr,true).'" name="Event_Calendar_Gadget_Nav"><img src="'.$imagePath.'/img/arrowp.gif" width="9" height="11" alt="&gt;"></a>' : '&nbsp;'),
				  '</th>',
  				  '<th colspan="5">',htmlentities($this->arr_monate[$this->language][$this->monat-1]),' ',$this->jahr,'</th>',
  				  '<th>',
  				  (($this->link==1 || $this->link==2 || $this->link==4) ? '<a href="'.$this->getspezialLink('1-'.$nmonat.'-'.$njahr,true).'" name="Event_Calendar_Gadget_Nav"><img src="'.$imagePath.'/img/arrown.gif" width="9" height="11"></a>': '&nbsp;'),
				  '</th>',
                  
                  
                  '</tr>
                    <tr>
                      <th >', htmlentities($this->arr_Tage[$this->language][0]) ,'</th>
                      <th >', htmlentities($this->arr_Tage[$this->language][1]) ,'</th>
                      <th >', htmlentities($this->arr_Tage[$this->language][2]) ,'</th>
                      <th >', htmlentities($this->arr_Tage[$this->language][3]) ,'</th>
                      <th >', htmlentities($this->arr_Tage[$this->language][4]) ,'</th>
                      <th >', htmlentities($this->arr_Tage[$this->language][5]) ,'</th>
                      <th >', htmlentities($this->arr_Tage[$this->language][6]) ,'</th>
                    </tr>';
            
            
            
            $iTag = 0; //Tag im Monat
            $i=0;
			$ntmp=0;
            do{ // while($i < $iZeilen);
                echo '<tr>';
            
                $j=1;
                do { //while($j <= 7);
            
                    //Hilfsvariable Mo=1, Di=2 .... So=7
                    $m = ($iWochenTag==0) ? 7 :  $iWochenTag;
            
                    //Nicht jeder Monat beginnt am Monat
                    if($m == $j && $j <= 7 && $iTag == 0){
                        $iTag = 1;
                    }
                    
                    
                    $preTag = ($iAnzahltageVormonat+$j-$m+1);
                    
                    if ($iTag == 0){
                      $tmpEvent = $this->isEvent($preTag.'-'.$vmonat.'-'.$vjahr);
                      echo '<td style="';
                      $spezialType = $this->getspezialType($preTag.'-'.$vmonat.'-'.$vjahr);
                      $colorStart = '#DDDDDD';
                      $colorStart2 = '#DDDDDD';
                      $colorEnd = '#DDDDDD';
					  $colorEnd2 = '#DDDDDD';
                      if($spezialType['typeStart'] ?? 'default value')
                      {
                        $colorStart = '#9DA6B0';
                      }
                      if($spezialType['typeEnd'] ?? 'default value')
                      {
                        $colorEnd = '#9DA6B0';
                      }
                      if($spezialType['typeFull'] ?? 'default value')
                      {
	                      $colorStart = '#9DA6B0';
	                      $colorStart2 = '#9DA6B0';
	                      $colorEnd = '#9DA6B0';
	                      $colorEnd2 = '#9DA6B0';
                      }
                      
                      if($event_settings['show_half_day'] == true)
                      {
                        echo $tmpEvent ? 'background-color: #9DA6B0; background: linear-gradient(-'.$event_settings['half_day_angle'].'deg, '.$colorStart.' 47%, '.$colorStart2.' 47%, '.$colorEnd2.' 53%, '.$colorEnd.' 53%);" id="aevent">' : '" id="amonat">';
                      }
                      else
                      {
	                    $color = '#9DA6B0';
                        echo $tmpEvent ? ' background-color: '.$color.';" id="aevent">' : '" id="amonat">';
                      }
                      echo ($this->link==1 || ($tmpEvent==true && ($this->link==3 || $this->link==4))) ? '<a href="'.$this->getspezialLink($preTag.'-'.$vmonat.'-'.$vjahr).'" title="'.$this->getspezialTitle($preTag.'-'.$vmonat.'-'.$vjahr).'">' : '';
                      echo $preTag;
                      echo ($this->link==1 || ($tmpEvent==true && ($this->link==3 || $this->link==4))) ? '</a>' : '';
                    }
                    
                    if ($iTag > $iAnzahltage){
                      ++$ntmp;
                      $tmpEvent = $this->isEvent($ntmp.'-'.$nmonat.'-'.$njahr);
                      echo '<td style="';
                      $spezialType = $this->getspezialType($ntmp.'-'.$nmonat.'-'.$njahr);
                      $colorStart = '#DDDDDD';
                      $colorStart2 = '#DDDDDD';
                      $colorEnd = '#DDDDDD';
					  $colorEnd2 = '#DDDDDD';
                      if(isset($spezialType['typeStart']))
                      {
                        $colorStart = '#9DA6B0';
                      }
                      if(isset($spezialType['typeEnd']))
                      {
                        $colorEnd = '#9DA6B0';
                      }
                      if(isset($spezialType['typeFull']))
                      {
	                      $colorStart = '#9DA6B0';
	                      $colorStart2 = '#9DA6B0';
	                      $colorEnd = '#9DA6B0';
	                      $colorEnd2 = '#9DA6B0';
                      }
                      
                      if($event_settings['show_half_day'] == true)
                      {
                        echo $tmpEvent ? ' background-color: #9DA6B0; background: linear-gradient(-'.$event_settings['half_day_angle'].'deg, '.$colorStart.' 47%, '.$colorStart2.' 47%, '.$colorEnd2.' 53%, '.$colorEnd.' 53%);" id="aevent">' : '" id="amonat">';
                      }
                      else
                      {
	                    $color = '#9DA6B0';
                        echo $tmpEvent ? ' background-color: '.$color.';" id="aevent">' : '" id="amonat">';
                      }
                      echo ($this->link==1 || ($tmpEvent==true && ($this->link==3 || $this->link==4))) ? '<a href="'.$this->getspezialLink($ntmp.'-'.$nmonat.'-'.$njahr).'" title="'.$this->getspezialTitle($ntmp.'-'.$nmonat.'-'.$njahr).'">' : '';
                      echo $ntmp;
                      echo ($this->link==1 || ($tmpEvent==true && ($this->link==3 || $this->link==4))) ? '</a>' : '';
                      echo '</td>';
                    }
                    
                    if ($iTag != 0 && $iTag <= $iAnzahltage){
                      $tmpEvent = $this->isEvent($iTag.'-'.$this->monat.'-'.$this->jahr);
                      echo '<td ';
					  // Hier das Highlight fuer den aktuellen Tag
					  if($event_settings['highlight_today'] == true && $iTag == $actual_date['mday'] && $this->monat == $actual_date['mon'] && $this->jahr == $actual_date['year'])
                      {
	                      echo 'style="border-width:1px; border-style:solid; border-color:Crimson;';
                      }
                      else
                      {
	                      echo 'style="';
                      }
                      
                      $spezialType = $this->getspezialType($iTag.'-'.$this->monat.'-'.$this->jahr);
                      $colorStart = '#FFFFFF';
                      $colorStart2 = '#FFFFFF';
                      $colorEnd = '#FFFFFF';
					  $colorEnd2 = '#FFFFFF';
                      if(isset($spezialType['typeStart']))
                      {
					  if(!isset($spezialType['specialcolorStart']))  //== '')
                        {
	                      $colorStart = '#4169e1';
                        }
                        else
                        {
						  $colorStart = $spezialType['specialcolorStart'];
                        }
                      }
                      if(isset($spezialType['typeEnd']))
                      {
	                     if(!isset($spezialType['specialcolorEnd']))
                        {
	                      $colorEnd = '#4169e1';
                        }
                        else
                        {
						  $colorEnd = $spezialType['specialcolorEnd'];
                        }
                      }
                      if(isset($spezialType['typeFull']))
                      { 
	                    if(!isset($spezialType['specialcolor']))  // == ''
                        {
	                      $colorStart = '#4169e1';
	                      $colorStart2 = '#4169e1';
	                      $colorEnd = '#4169e1';
	                      $colorEnd2 = '#4169e1';
                        }
                        else
                        {
	                      $colorStart = $spezialType['specialcolor'];
	                      $colorStart2 = $spezialType['specialcolor'];
	                      $colorEnd = $spezialType['specialcolor'];
	                      $colorEnd2 = $spezialType['specialcolor'];
                        }
                      }
                      
                      if($event_settings['show_half_day'] == true)
                      {
	                    if(!isset($spezialType['specialcolor']))  // == '')
	                    {
		                    if(!isset($spezialType['specialcolorStart'])) // == '')
		                    {
			                    if(!isset($spezialType['specialcolorEnd'])) // == '')
			                    {
				                    $color = '#4169e1';
			                    }
			                    else
			                    {
				                    $color = $spezialType['specialcolorEnd'];
			                    }
		                    }
		                    else
		                    {
			                    $color = $spezialType['specialcolorStart'];
		                    }		                    
	                    }
	                    else
	                    {
		                    $color = $spezialType['specialcolor'];
	                    }
                        echo $tmpEvent ? ' background-color: '.$color.'; background: linear-gradient(-'.$event_settings['half_day_angle'].'deg, '.$colorStart.' 47%, '.$colorStart2.' 47%, '.$colorEnd2.' 53%, '.$colorEnd.' 53%); color: #ffffff;" id="monatevent">' : '" id="monat">';
                      }
                      else
                      {
	                    if(!isset($spezialType['specialcolor']))  // == '')
	                    {
		                    $color = '#4169e1';
	                    }
	                    else
	                    {
		                    $color = $spezialType['specialcolor'];
	                    }
                        echo $tmpEvent ? ' background-color: '.$color.';" id="monatevent">' : '" id="monat">';
                      }
                  	  
                      echo ($this->link==1 || ($tmpEvent==true && ($this->link==3 || $this->link==4))) ? '<a href="'.$this->getspezialLink($iTag.'-'.$this->monat.'-'.$this->jahr).'" title="'.$this->getspezialTitle($iTag.'-'.$this->monat.'-'.$this->jahr).'">' : '';
                      echo $iTag;
                      echo ($this->link==1 || ($tmpEvent==true && ($this->link==3 || $this->link==4))) ? '</a>' : '';
                      echo '</td>';
                      ++$iTag;
                    }

                    
                } while(++$j <= 7);
            
                echo '</tr>';
            
            } while(++$i < $iZeilen);
            echo '</table></div>';
            $myStr = ob_get_contents();
			ob_end_clean();
			return $myStr;
        }
    } 
?>
