
$(function(){

	$gp.links.ToggleSettings = function(){
		$(this).closest('h3').next('div').slideToggle();
	}


});