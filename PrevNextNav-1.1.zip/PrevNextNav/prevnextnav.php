<?php
/**
 * name:      prevnextnav.php
 * date:      16.03.2013
 * author:    Folke Ashberg
 * copyright: Folke Ashberg <http://www.ashberg.de>
 */
defined('is_running') or die('Not an entry point...');

function PrevNextNav() {
    global $gp_menu, $page, $gp_index;
    global $gpmenu, $page;

    // search current level
    $thisLevel = -1;
    foreach($gp_menu as $index => $info){
	$level = $info['level'];
	$title = common::IndexToTitle($index);
	if ($title == $page->title) {
	    $thisLevel = $level;
	    break;
	}  
    }

    if ($thisLevel<0) return; /* not found ? */


    $upTitle = '';
    $parentLevel = -1;
    $lastLevel = -1;
    $lastTitle = '';
    $prevTitle = '';
    $nextTitle = '';

    $searchfornext=false;
    $hitcurrent=false;

    if( !isset($gp_menu) || !is_array($gp_menu) ) return false;
    //2.0+

    foreach($gp_menu as $index => $info){
	$level = $info['level'];

	$title = common::IndexToTitle($index);

	if ($title == $page->title) {
	    $searchfornext=true;
	    $hitcurrent=true;
	    continue;
	} 
	if (!$hitcurrent){
	    /* our page not found so far */
	    if ($level === $thisLevel){
		$prevTitle=$title;
	    }
	    if ($level === $thisLevel -1 ){
		$upTitle=$title;
	    }
	}
	if ($searchfornext){
	    if ($level < $thisLevel){
		/* wir sind raus aus dem business */
		break;
	    } else if ($thisLevel === $level){
		$searchfornext=false;
		$nextTitle=$title;
		break;
	    }
	}


	$lastLevel = $level;
	$lastTitle = $title;
    }

    //print "UT: $upTitle<br/>\n";
    //print "PT: $prevTitle<br/>\n";
    //print "NT: $nextTitle<br/>\n";

    function makelink($title, $pos){
	$label = common::GetLabel($title, false);
	echo common::Link($title, "&nbsp;", '', 'class="arrow '.$pos.'" title="'.common::Ampersands($label).'"');
    }

    //$label = common::GetLabel($output[$i], false);
    //echo common::Link($output[$i], $label);
    //echo gpOutput::GetAddonText(' &gt; ');
    print '<div id="prevnextnav">'."\n";
    print '<div id="prevnextnav_left">'."\n";
    if ($prevTitle!==''){
	makelink($prevTitle, 'left');
    } else if ($upTitle!==''){
	makelink($upTitle, 'up');
    }
    print '</div>'."\n";
    print '<div id="prevnextnav_right">'."\n";
    if ($nextTitle!==''){
	makelink($nextTitle, 'right');
    }
    print '</div>'."\n";
    print '</div>'."\n";
}

PrevNextNav();

?>
