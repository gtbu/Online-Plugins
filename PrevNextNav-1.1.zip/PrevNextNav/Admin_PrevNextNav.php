<?php
defined('is_running') or die('Not an entry point...');


class Admin_PrevNextNav{
	function __construct(){ 
		echo '<h2>
	Typesetter PrevNextNav Plugin</h2>
<p>
	This Plugin provides a Gadget. It outputs a &lt;div&gt;-Element with two arrows left and right for previous and next page from same menulevel. If no previous page exists the parent page is used</p>
	<p>
	Add such a line to your template.php:<br/>
	<pre>&nbsp;&nbsp;&lt;?php gpOutput::Get(\'Extra\',\'PrevNextNav\'); ?&gt;</pre>
	Then edit the appropriate template and insert Gadget \'PrevNextNav\' to the section.
	</p>
	<p>
	Plugin Homepage: <a target="_blank" href="http://www.ashberg.de">ashberg.de</a>
	</p>
';
	}
}
	

