<?php
defined('is_running') or die('Not an entry point...');


$texts = array();
$texts[] = 'All';
$texts[] = 'Next';
$texts[] = 'Previous';



