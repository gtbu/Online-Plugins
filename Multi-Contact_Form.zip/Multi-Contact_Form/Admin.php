<?php
defined('is_running') or die('Not an entry point...');

class MultiContactForm_Admin{

	function __construct(){
			
		global $addonCodeFolder;
		$contactsFile = $addonCodeFolder.'/contactsFile.php';  // this is where the file email addresses and usernames are stored
		
		echo '<h2>Multi-Contact Form Admin</h2>'; 
		
		// set up blank arrays
		$contacts = array();
		$newContactTest = array();
		$oldContacts = array();
		$numContacts = 0;
		$anyposts = false;
		
		if(file_exists($contactsFile))
		{
			require $contactsFile;
			// if file exists the blank $contacts array will be overwritten by one contained in $contactsFile (as may be $oldContacts)...
			$numContacts = count($contacts); // counts the number of contacts
		}		
		
		
		// Check for POST	
		if($_POST['contactName-1'] != null)  // if there was something posted it is stored in $newContactTest array
		{
			$newContactTest = $this->checkPost($numContacts);
			$anyposts = true;
		}

		// Checks Posts for New Items
		if(($_POST['contactNameAdd'] != null) && ($_POST['emailAdd'] != null))
		{
			$addkey = $_POST['contactNameAdd'];
			$emailAdd = $_POST['emailAdd'];
			$anyposts = true;
		}
		else
		{
			$addkey = null;
			$emailAdd = null;
		}
					
		// makes sure a New Contact doesn't already exist
		if(($addkey!=null) && (array_key_exists($addkey, $contacts)))
		{
			echo "The last NEW 'Contact Name' was NOT saved as it already exists => please edit this instead.";
		}
		else
		{
			$newContactTest[$addkey]= $emailAdd; // is added to array if it doesn't already exist
		}
		
		// Disguard any empty array items 
		unset($contacts['']);
		unset($newContactTest['']); 
		
		//Compare New Contact list with old and save if different (sends back up-to-date contacts array)
		$contacts = $this->saveIfContactsChanged($contacts, $newContactTest, $contactsFile, $anyposts);
		
		// Displays GUI			
		echo '<form method="POST">';
		$this->displayExistingContacts($contacts);
		$this->displayNewContactFields();
		echo '<br /><input type="submit" name="submit" value="   Save Changes   "/>';
		echo '</form>';
		
		$this->displayUserNotes(); 
			
			
	} // end of multiContactAdmin Function
	
	
	//--------------------------------------------------------------------------------------------------------------------//

	function displayNewContactFields(){
		echo '<div><input style="width:250px; padding:5px; margin:2px 5px;" name="contactNameAdd" />';
		echo '<input style="width:400px; padding:5px; margin: 2px 5px; " name="emailAdd" /><b> <= Add New Contact here</b></div>';		
	}
	
	
	function checkPost($numContacts)
	{
		$newContact = array(); 
		for ($i=1; $i <= $numContacts; $i++)
		{
			$presentName = 'contactName-'.$i;
			$presentEmail = 'contactEmail-'.$i;
			$nameKey = $_POST[$presentName];
			$emailVal = $_POST[$presentEmail];
			$newContact[$nameKey] = $emailVal; // adds new items to array
		}
		return $newContact; 
	}
	
	
	function saveIfContactsChanged($contacts, $newContactTest, $contactsFile, $anyposts)
	{
		if($anyposts == true)
		{
			if($contacts == $newContactTest) // if new and old Contacts arrays are the same but not necessarily in same order
			{
				if($contacts === $newContactTest) 
				{
					message("No changes were made."); // Contacts arrays identical
				}
				else  
				{	
					$contacts = $newContactTest;	// Contacts are in different different order, so Contacts are replaced from new array
					if ($this->saveToFile($contacts, $contactsFile)) 
					{
						message("The new order of the Contacts have been changed."); 
					}
					else
					{
						message("ERROR! Failed to save changed order in File. Please try again.");  // this should never happen
					}
				}
			}
			else
			{
				$contacts = $newContactTest;	// Contacts arrays are not the same, so Contacts are replaced from new array
				if ($this->saveToFile($contacts, $contactsFile))
				{
					message("The changes have been saved.");
				}
				else
				{
					message("ERROR! Failed to save changes in File. Please try again.");
				}
			}
		}
		return $contacts;
	}
	
	
	function displayExistingContacts($contacts)
	{
		echo '<div style="width:250px; padding:5px; margin: 1px 5px; font-weight:bold; float:left; " >Contact Name</div><div style="width:400px; padding:5px; margin:1px 5px; font-weight:bold; float:left;">Email Address</div><div style="clear:both"></div>';
			
		$counter = 1;
		foreach ($contacts as $nameKey => $emailVal)  
		{
			echo '<div><input style="width:250px; padding:5px; margin: 2px 5px; " name="contactName-'.$counter.'" value="'.$nameKey.'" />';
			echo '<input style="width:400px; padding:5px; margin: 2px 5px; " name="contactEmail-'.$counter.'" value="'.$emailVal.'" /></div>';	
			$counter++;	
		}
	}
	
	
	function saveToFile($contacts, $contactsFile)
	{
		if (gpFiles::SaveArray($contactsFile, 'contacts', $contacts)) {
			return true;
		}
		else {
			return false;
		}
	}
	
	
	function displayUserNotes()
	{
		echo "<br /><div style='color:#700; '><b>NOTES:</b><br />";
		echo "1) To remove a Contact just <b>delete</b> the <b>'Contact Name'</b> and <b>'Email Address'</b> from the form above and click <b>'Save Changes'</b><br />";
		echo "2) Email Addresses are allowed to be duplicated but <b>Contact Names must NOT be duplicated</b>.</div>";
	}	
	
	
} // end of Class


?>