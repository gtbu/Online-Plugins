<?php

defined('is_running') or die('Not an entry point...');


function plugin_function(){
    global $addonFolderName,$page;
    $page->css_admin[] = '/data/_addoncode/'.$addonFolderName.'/style.css';
    $page->head_js[] = '/data/_addoncode/'.$addonFolderName.'/form_validator.min.js';
}

?>