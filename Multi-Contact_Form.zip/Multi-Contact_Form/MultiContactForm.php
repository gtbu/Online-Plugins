<?php
defined('is_running') or die('Not an entry point...');

class MultiContactForm{
		
	var $contactsFile;
	var $contacts = array();
	
	function __construct(){
		
		global $page, $addonFolderName;
		$success = -1;
		
		$contacts = $this->getContacts();  // get email addresses for contacts
		
		if(isset($_POST['SendTo'])) 
		{
			$success = $this->processForm($contacts);
			header("Location: Munti_Contact_Form?mail=sent");
		}
		if(isset($_GET['mail']) && ($_GET['mail'] == "sent"))
		{
			$success = 1;
		}

		$this->displayForm($success, $contacts);
		 
	}  // end of MultiContactForm Function
	
	
	function displayForm($success, $contacts)
	{
		?>
		<form method="post" action="" name="Multi_Contact_Form" class="contactform" >
				<div>
					<h2>Email Contact Form</h2>
					
					<label class="description" for="yourName">Your Name </label>
					<div class="clear">
						<input name="yourName" class="input text" type="text" value=""/> <div id="Multi_Contact_Form_yourName_errorloc" class='error_strings'></div>
					</div> 
					<label class="description" for="Email">Your Email Address</label>
					<div class="clear">
						<input name="Email" class="input text" type="text" value=""/> <div id="Multi_Contact_Form_Email_errorloc" class='error_strings'></div>
					</div> 
					<label class="description" for="subject">Subject </label>
					<div class="clear">
						<input id="subject" name="subject" class="input text" type="text" maxlength="255" value=""/> <div id="Multi_Contact_Form_subject_errorloc" class='error_strings'></div>
					</div> 
					<label class="description" for="message">Message </label>
					<div class="clear">
						<textarea id="message" name="message" class="element textarea medium"></textarea>
						<div id="Multi_Contact_Form_message_errorloc" class='error_strings'></div> 
					</div>
					<div class="clear"></div>
					<br /><br />
					
					<label class="SendTo" for="SendTo">Send this to: </label>
					<div >
					<select class="element select medium" id="SendTo" name="SendTo">
						<option value="" >...please select one...</option>
							<?php 
							$this->displayContactNames($contacts); 
							?>
					</select>
					<div id="Multi_Contact_Form_SendTo_errorloc" class='error_strings'></div>
					</div>
					
					<br />
					<div class="clear">			   
						<input class="button_text" type="submit" name="submit" value="Submit" /> 
						<?php
							if($success == 1)
							{
								echo '<script>alert("The message has been sent successfully :)")</script>';
							}
							if ($success == 0)
							{
								echo '<span class="error_strings"> There appears to be a problem with sending messages :( </span>';
							}						
						?>
					</div>
				</div>
			</form>	
		
			<script type="text/javascript">
				var frmvalidator  = new Validator("Multi_Contact_Form");
				frmvalidator.EnableOnPageErrorDisplay();
				
				frmvalidator.addValidation("yourName","req"," <- This field is required.");
				frmvalidator.addValidation("yourName","minlength=2"," <- The entered value is too short for this field.");
				frmvalidator.addValidation("yourName","maxlength=70"," <- The entered value is too long for this field - max 70");
				frmvalidator.addValidation("Email","req"," <- You must enter a means of contacting you.");
				frmvalidator.addValidation("Email","email"," <- The entered value is too short for this field.");
				frmvalidator.addValidation("Email","maxlength=70"," <- The entered value is too long for this field - max 70");
				frmvalidator.addValidation("subject","req"," <- Please enter the subject of this email");
				frmvalidator.addValidation("subject","minlength=2"," <- The entered value is too short for this field.");
				frmvalidator.addValidation("subject","maxlength=70"," <- The entered value is too long for this field - max 70");
				frmvalidator.addValidation("message","req","The entered value is too short for the Message field.");
				frmvalidator.addValidation("message","minlength=6","The entered value is too short for the Message field.");
				frmvalidator.addValidation("SendTo","req"," <- please select one.");
				
			</script>
		<?php
	}
	
	
	function displayContactNames($contacts)
	{
		foreach ($contacts as $cName => $cEmail)
		{
			echo '<option value="'.$cName.'" >'.$cName.'</option>';				
		}
	}
	
	
	function getContacts()
	{
		global $addonDataFolder;
		$contactsFile = $addonDataFolder.'/contactsFile.php';
		$contacts = array();

		if(file_exists($contactsFile)){
			require($contactsFile);
		}
		return($contacts);
	}  // end of getContactsFile Function
	
	
	function processForm($contacts)
	{
		//as the form is validated in js we can minimise validation here
		if((isset($_POST[yourName])) && (isset($_POST[Email])) && (isset($_POST[subject])) && (isset($_POST[message]))) 
		{
			if(($_POST[SendTo] != null) && ($_POST[yourName] != null) && ($_POST[Email] != null) && ($_POST[subject] != null) && ($_POST[message] != null)) 
			{
				$sendTo = htmlentities($_POST[SendTo],ENT_QUOTES);
				$name = htmlentities($_POST[yourName],ENT_QUOTES);
				$email = htmlentities($_POST[Email],ENT_QUOTES);
				$subject = htmlentities($_POST[subject],ENT_QUOTES);
				$message = htmlentities($_POST[message],ENT_QUOTES);
			
				$to = $this->getEmailAddress($sendTo, $contacts);
				$header = $this->formatFrom($email, $name);
				
				$this->mailForm($to, $subject, $message, $header);
				unset($_POST[SendTo]);
				
				return 1;
			}
			else
			{
				return 0;
			}
		}
	}  // end of processForm Function
	
	
	function formatFrom($email, $name)
	{
		$from = "FROM:".$name;
		$from .= "<".$email;
		$from .= ">";
		return $from;
	}
	
	
	function getEmailAddress($sendTo, $contacts)
	{
		$to = $contacts[$sendTo];
		echo $to;
		return $to;
	}
	
	
	function mailForm($to, $subject, $message, $header)
	{	
		mail($to, $subject, $message, $header);	
	}  // end of mailForm Function
	

} // end of Class