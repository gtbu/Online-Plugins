<?php
defined('is_running') or die('Not an entry point...');

class RandomImageAdmin{
	var $configFile;
	var $config = array();

	function __construct(){

		if( !common::LoggedIn() ){
			return;
		}

		$this->init();
		$cmd = common::GetCommand();
		switch($cmd) {
			case 'save_config':
				$this->checkSave();
			break;
		}
		$this->configForm();
	}

	function init(){
		global $addonPathData;

		$this->configFile = $addonPathData.'/index.php';
		$this->getData();
	}

	function getData(){
		global $langmessage;

		if( file_exists($this->configFile) ){
			require($this->configFile);
			$this->config = $randomImageConfig;
		}else{
			$this->config = array('gadget_head'=>'RandomImage', 'folder_path'=>'random', 'gadget_enable'=>'enable');

	 		if( !$this->saveConfig() ){
				message($langmessage['OOPS']);
			}else{
				message($langmessage['SAVED']);
			}
		}
	}

	function checkSave(){
		global $langmessage;

		$this->config['gadget_head'] = htmlspecialchars($_POST['gadget_head']);
		$this->config['folder_path'] = htmlspecialchars($_POST['folder_path']);
		if (isset($_POST['gadget_enable'])) {
			$this->config['gadget_enable'] = $_POST['gadget_enable'];
		}else{
			$this->config['gadget_enable'] = '';
		}

		if (!$this->saveConfig()) {
			message($langmessage['OOPS']);
		}else {
			message($langmessage['SAVED']);
		}
	}

	function saveConfig(){
		return gpFiles::SaveArray($this->configFile, 'randomImageConfig', $this->config);
	}

	function configForm(){
		global $langmessage;
		$array =& $this->config;

		echo '<h2>Random Image Configuration</h2>';

		echo '<form action="'.common::getUrl('Admin_RandomImage').'" method="post">';
		echo '<table class="bordered">';
		echo '<tr><th>'.$langmessage['options'].'</th><th>&nbsp;</th></tr>';


		echo '<tr><td>Gadget Header</td>';
		echo '<td><input type="text" name="gadget_head" size="30" value="'.htmlspecialchars($array['gadget_head']).'" /></td>';
		echo '</tr>';


		echo '<tr><td>Image Folder</td>';
		echo '<td>/_uploaded/image/<input type="text" name="folder_path" size="30" value="'.htmlspecialchars($array['folder_path']).'" /></td>';
		echo '</tr>';


		echo '<tr><td>Enable Gadget</td>';
		echo '<td><input type="checkbox" name="gadget_enable" value="enable"';
		if( $array['gadget_enable'] == 'enable') echo ' checked="checked"';
		echo ' /></td>';
		echo '</tr>';


		echo '<tr><td></td>';
		echo '<td><input type="hidden" name="cmd" value="save_config" />';
		echo '<input type="submit" name="" value="'.$langmessage['save'].'" class="gpsubmit" /> ';
		echo '<input type="submit" name="cmd" value="'.$langmessage['cancel'].'" class="gpcancel" /></td>';
		echo '</tr>';
		echo '</table>';
		echo '</form>';
	}
}
