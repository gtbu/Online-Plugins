<?php
defined('is_running') or die('Not an entry point...');

class RandomImageGadget{
	var $header;
	var $username;
	var $is_working = false;

	function __construct(){
		$this->getData();

		if( !$this->is_working ){
			return;
		}

		$this->showImage();

		if( common::LoggedIn() ){
			echo '<p>'.common::Link('Admin_RandomImage', 'Random Image Admin').'</p>'."\n";
		}
	}

	function getData(){
		global $addonPathData;

		$configFile = $addonPathData.'/index.php';
		$randomImageConfig = array('gadget_head'=>'Random Image', 'folder_path'=>'random', 'gadget_enable'=>'enable');
		if( file_exists($configFile) ){
			require($configFile);
		}

		$this->header = $randomImageConfig['gadget_head'];
		$this->folder_path = $randomImageConfig['folder_path'];
		if( $randomImageConfig['gadget_enable'] == 'enable' ){
			$this->is_working = true;
		}
	}

	function showImage(){
		global $dataDir;

		$imglist='';
		$img_folder = $dataDir.'/data/_uploaded/image/'.$this->folder_path.'/' ; #Don't forget to put / in the end#

		mt_srand((double)microtime()*1000);

		if(!is_dir($img_folder)){
			echo '<h3>'.$this->header.'</h3>'."\n";
			echo "invalid folder";
			return;
		}


		//reads all the files from the folder and checks if they are images and then ads them to a list
		$files = scandir($img_folder);
		$img_list = array();
		foreach($files as $file){
			if( preg_match('#\.(gif|jpg|png|jpeg)$#',$file) ){
				$img_list[] = $file;
			}
		}

		//generate a random number between 0 and the number of images
		$random = array_rand($img_list);
		$image = $img_list[$random];


		//get absolute url
		if( isset($_SERVER['HTTP_HOST']) ){
			$server = '//'.$_SERVER['HTTP_HOST'];
		}else{
			$server = '//'.$_SERVER['SERVER_NAME'];
		}
		$path = 'data/_uploaded/image/'.$this->folder_path.'/'.$image;
		$full_url = $server.common::GetDir($path,false);

		//get image size
		$size = getimagesize($img_folder.$image);
		$style = 'width:100%;';
		if( $size ){
			$style .= 'max-width:'.$size[0].'px;max-height:'.$size[1].'px;';
		}

		//display image
		echo '<h3>'.$this->header.'</h3>'."\n";
		echo '<center>';
			echo '<a href="'.$full_url.'">';
				echo '<img src="'.$full_url.'" border="0" style="'.$style.'" />';
			echo '</a>';
		echo '</center>';
	}
}





