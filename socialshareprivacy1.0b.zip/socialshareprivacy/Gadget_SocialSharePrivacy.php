<?php

defined('is_running') or die('Not an entry point...');

include_once 'Common_SocialSharePrivacy.php';

class Gadget_SocialSharePrivacy{
	
	function Gadget_SocialSharePrivacy(){
		$this->Get_Head();
		echo '<div id="socialshareprivacy">&nbsp;</div>';
	}
	
	function Get_Head()
	{
		global $page, $addonRelativeCode, $addonPathData;
		$page->head .= '<script type="text/javascript">';
		$page->head .= '  jQuery(document).ready(function($){';
		$page->head .= '    if($(\'#socialshareprivacy\').length > 0){';
		$page->head .= '      $(\'#socialshareprivacy\').socialSharePrivacy({';
		
		$this->OutputOptions(SocialSharePrivacy_GetConfig());
		
		$page->head .= '}); ';
		$page->head .= '    }';
		$page->head .= '  });';
		$page->head .= '</script>';
	}
	
	function OutputOptions($configData)
	{
		global $page;
		
		$page->head .= 'services : {';
		
		foreach($configData as $option1 => $value1)
		{
			if (is_array($value1))
			{
				$page->head .= $option1.' : {';
				foreach($configData[$option1] as $option2 => $value2)
				{
					if ($value2 !== false)
					{
						$page->head .= '\''.$option2.'\'	: \''.$value2.'\',';
					}
				}
				$page->head .= '},';
			}
		}
		$page->head .= '},';
		foreach($configData as $option1 => $value1)
		{
			if (!is_array($value1) && ($value1 !== false))
			{
				$page->head .= '\''.$option1.'\'	: \''.$value1.'\',';
			}

		}
	}
}