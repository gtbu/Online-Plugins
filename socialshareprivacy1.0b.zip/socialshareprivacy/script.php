<?php
function Get_Head($js_files){
	global $addonFolderName,$page;
	$page->head_js[] = '/data/_addoncode/'.$addonFolderName.'/jquery.socialshareprivacy.js';
}