<?php 
defined('is_running') or die('Not an entry point...');

$SSP_LANG = array();

$SSP_LANG['settings_perma'] = 'Dauerhaft aktivieren und Daten&uuml;bertragung zustimmen:';
$SSP_LANG['txt_fb_off'] = 'nicht mit Facebook verbunden';
$SSP_LANG['txt_fb_on'] = 'mit Facebook verbunden';
$SSP_LANG['txt_twitter_off'] = 'nicht mit Twitter verbunden';
$SSP_LANG['txt_twitter_on'] = 'mit Twitter verbunden';
$SSP_LANG['txt_gplus_off'] = 'nicht mit Google+ verbunden';
$SSP_LANG['txt_gplus_on'] = 'mit Google+ verbunden';
$SSP_LANG['txt_info'] = '2 Klicks f&uuml;r mehr Datenschutz: Erst wenn Sie hier klicken, wird der Button aktiv und Sie k&ouml;nnen Ihre Empfehlung an Facebook senden. Schon beim Aktivieren werden Daten an Dritte &uuml;bertragen &ndash; siehe <em>i</em>.';
$SSP_LANG['txt_help'] = 'Wenn Sie diese Felder durch einen Klick aktivieren, werden Informationen an Facebook, Twitter oder Google in die USA &uuml;bertragen und unter Umst&auml;nden auch dort gespeichert. N&auml;heres erfahren Sie durch einen Klick auf das <em>i</em>.';

$SSP_LANG['reset_to_defaults'] = 'Auf Standard-Werte zur&uuml;cksetzen';
$SSP_LANG['save'] = 'Speichern';
$SSP_LANG['general_settings'] = 'Allgemeine Einstellungen';
$SSP_LANG['facebook_settings'] = 'Facebook Einstellungen';
$SSP_LANG['twitter_settings'] = 'Twitter Einstellungen';
$SSP_LANG['gplus_settings'] = 'Google+ Einstellungen';
$SSP_LANG['parameter'] = 'Parameter';
$SSP_LANG['value'] = 'Wert';
$SSP_LANG['delete'] = 'L&ouml;schen';
$SSP_LANG['explanation'] = 'Erkl&auml;rung';

$SSP_LANG['info_link_label'] = 'Info-Link';
$SSP_LANG['info_link_explain'] = 'Link zu detaillierter Datenschutz-Info';
$SSP_LANG['txt_help_label'] = 'Hilfetext';
$SSP_LANG['txt_help_explain'] = 'MouseOver-Text des i-Icons';
$SSP_LANG['settings_perma_label'] = '&Uuml;berschrift Einstellungen';
$SSP_LANG['settings_perma_explain'] = '&Uuml;berschrift des Einstellungsmen&uuml;s';
$SSP_LANG['status_label'] = 'Status';
$SSP_LANG['status_explain'] = 'Funktion ist aktiviert (on) oder deaktiviert (off)';
$SSP_LANG['app_id_label'] = 'App-ID';
$SSP_LANG['app_id_explain'] = 'Bei Facebook einloggen, <a href="http://developers.facebook.com/docs/reference/plugins/like/" target="_blank">Entwickler-Seite</a> aufrufen, dort in der Box unter "Step 1" auf "Get Code" klicken und die App-ID aus dem angezeigten Code-Teil entnehmen.';
$SSP_LANG['txt_info_label'] = 'Button-Text';
$SSP_LANG['txt_info_explain'] = 'MouseOver-Text des Buttons';
$SSP_LANG['txt_fb_off_label'] = 'txt_fb_off';
$SSP_LANG['txt_fb_off_explain'] = 'Text-Entsprechung der Schalter-Grafik im ausgeschalteten Zustand, in der Regel nicht sichtbar f&uuml;r den User';
$SSP_LANG['txt_fb_on_label'] = 'txt_fb_on';
$SSP_LANG['txt_fb_on_explain'] = 'Text-Entsprechung der Schalter-Grafik im eingeschalteten Zustand, in der Regel nicht sichtbar f&uuml;r den User';
$SSP_LANG['perma_option_label'] = 'Perma-Option';
$SSP_LANG['perma_option_explain'] = 'Der User hat die Option sich den Dienst dauerhaft einblenden zu lassen (mittels Cookie) (on/off)';
$SSP_LANG['display_name_label'] = 'Anzeigename';
$SSP_LANG['display_name_explain'] = 'Schreibweise des Service in den Optionen';
$SSP_LANG['referrer_track_label'] = 'Referrer-Tracker';
$SSP_LANG['referrer_track_explain'] = 'Wird ans Ende der URL geh&auml;ngt, kann zum Tracken des Referrers genutzt werden';
$SSP_LANG['language_label'] = 'Sprache';
$SSP_LANG['language_explain'] = 'Spracheinstellung';
$SSP_LANG['txt_twitter_off_label'] = 'txt_twitter_off';
$SSP_LANG['txt_twitter_off_explain'] = 'Text-Entsprechung der Schalter-Grafik im ausgeschalteten Zustand, in der Regel nicht sichtbar f&uuml;r den User';
$SSP_LANG['txt_twitter_on_label'] = 'txt_twitter_on';
$SSP_LANG['txt_twitter_on_explain'] = 'Text-Entsprechung der Schalter-Grafik im eingeschalteten Zustand, in der Regel nicht sichtbar f&uuml;r den User';
$SSP_LANG['tweet_text_label'] = 'tweet_text';
$SSP_LANG['tweet_text_explain'] = 'Die Funktion pr&uuml;ft ob es die Meta-Angabe DC.title gibt und verwendet diese. Gibt es au&szlig;erdem noch DC.creator wird diese etwas abgesetzt (" - ") hinten angeh&auml;ngt. Ist DC.title nicht vorhanden wird das title-Tag der Seite verwendet. Diese Option kann mit einem eigenen Text &uuml;berschrieben werden. Der &uuml;bergebene Texte wird immer auf 120 Zeichen gek&uuml;rzt und beim letzten Leerzeichen mit ... ersetzt. ';
$SSP_LANG['txt_gplus_off_label'] = 'txt_gplus_off';
$SSP_LANG['txt_gplus_off_explain'] = 'Text-Entsprechung der Schalter-Grafik im ausgeschalteten Zustand, in der Regel nicht sichtbar f&uuml;r den User';
$SSP_LANG['txt_gplus_on_label'] = 'txt_gplus_on';
$SSP_LANG['txt_gplus_on_explain'] = 'Text-Entsprechung der Schalter-Grafik im eingeschalteten Zustand, in der Regel nicht sichtbar f&uuml;r den User';

return $SSP_LANG;