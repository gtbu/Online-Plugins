<?php 
defined('is_running') or die('Not an entry point...');

$SSP_LANG = array();

$SSP_LANG['settings_perma'] = 'Activate permanently and agree to transmit data:';
$SSP_LANG['txt_fb_off'] = 'not connected to Facebook';
$SSP_LANG['txt_fb_on'] = 'connected to Facebook';
$SSP_LANG['txt_twitter_off'] = 'not connected to Twitter';
$SSP_LANG['txt_twitter_on'] = 'connected to Twitter';
$SSP_LANG['txt_gplus_off'] = 'not connected to  Google+';
$SSP_LANG['txt_gplus_on'] = 'connected to  Google';
$SSP_LANG['txt_info'] = '2 clicks for more privacy: Onyl after you click here, the button is activated and you can send your recommendation to Facebook, Twitter or Google. Even at the activation data is transmitted to third parties. &ndash; read <em>i</em>.';
$SSP_LANG['txt_help'] = 'When you activate these checkboxes, information will be transmitted to Facebook, Twitter or Google in the USA and might be stored there. For more Information, read <em>i</em>.';

$SSP_LANG['reset_to_defaults'] = 'Reset to defaults';
$SSP_LANG['save'] = 'Save';
$SSP_LANG['general_settings'] = 'General Settings';
$SSP_LANG['facebook_settings'] = 'Facebook Settings';
$SSP_LANG['twitter_settings'] = 'Twitter Settings';
$SSP_LANG['gplus_settings'] = 'Google+ Settings';
$SSP_LANG['parameter'] = 'Parameter';
$SSP_LANG['value'] = 'Value';
$SSP_LANG['delete'] = 'Delete';
$SSP_LANG['explanation'] = 'Exlanation';

$SSP_LANG['info_link_label'] = 'Info-Link';
$SSP_LANG['info_link_explain'] = 'Link to deails privacy information';
$SSP_LANG['txt_help_label'] = 'Help text';
$SSP_LANG['txt_help_explain'] = 'MouseOver text for the i-icon';
$SSP_LANG['settings_perma_label'] = 'Settings header';
$SSP_LANG['settings_perma_explain'] = 'Header for the settings menu';
$SSP_LANG['status_label'] = 'Status';
$SSP_LANG['status_explain'] = 'Funktion is "on" or "off"';
$SSP_LANG['app_id_label'] = 'App-ID';
$SSP_LANG['app_id_explain'] = 'Log into Facebook, go to <a href="https://developers.facebook.com/docs/reference/plugins/like/">Facebook Developer</a>, in "Step 1" click on "Get Code" and copy the app id from the displayed code.';
$SSP_LANG['txt_info_label'] = 'Button-Text';
$SSP_LANG['txt_info_explain'] = 'MouseOver text for the button';
$SSP_LANG['txt_fb_off_label'] = 'txt_fb_off';
$SSP_LANG['txt_fb_off_explain'] = 'Text version of the button icon when inactive, not usualy visible to the user';
$SSP_LANG['txt_fb_on_label'] = 'txt_fb_on';
$SSP_LANG['txt_fb_on_explain'] = 'Text bersion of the button icon when active, not usualy visible to the user';
$SSP_LANG['perma_option_label'] = 'Perma-Option';
$SSP_LANG['perma_option_explain'] = 'The user can activate the service permanently (via cookie) (on/off)';
$SSP_LANG['display_name_label'] = 'Display name';
$SSP_LANG['display_name_explain'] = 'Display name of the service in the options';
$SSP_LANG['referrer_track_label'] = 'Referrer-Tracker';
$SSP_LANG['referrer_track_explain'] = 'Is attached to the end of the URL, can be used to track the refferer';
$SSP_LANG['language_label'] = 'Language';
$SSP_LANG['language_explain'] = 'Language setting';
$SSP_LANG['txt_twitter_off_label'] = 'txt_twitter_off';
$SSP_LANG['txt_twitter_off_explain'] = 'Text version of the button icon when inactive, not usualy visible to the user';
$SSP_LANG['txt_twitter_on_label'] = 'txt_twitter_on';
$SSP_LANG['txt_twitter_on_explain'] = 'Text bersion of the button icon when active, not usualy visible to the user';
$SSP_LANG['tweet_text_label'] = 'tweet_text';
$SSP_LANG['tweet_text_explain'] = 'The function checks meta-tag DC.title and uses this. If DC.creator is defined it will be set off (" - ") and appended. If DC.title is not defined, the title-tag of the page will be used. This option can be replaced with a custom text. The text is shortened to 120 characters and replaced with ... at the last blank space.';
$SSP_LANG['txt_gplus_off_label'] = 'txt_gplus_off';
$SSP_LANG['txt_gplus_off_explain'] = 'Text version of the button icon when inactive, not usualy visible to the user';
$SSP_LANG['txt_gplus_on_label'] = 'txt_gplus_on';
$SSP_LANG['txt_gplus_on_explain'] = 'Text bersion of the button icon when active, not usualy visible to the user';

return $SSP_LANG;