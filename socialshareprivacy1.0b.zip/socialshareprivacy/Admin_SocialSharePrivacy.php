<?php
defined('is_running') or die('Not an entry point...');

include_once 'Common_SocialSharePrivacy.php';

class Admin_SocialSharePrivacy{
	function Admin_SocialSharePrivacy()
	{ 
//		$SSP_LANG = SocialSharePrivacy_GetLang();
		$configData = SocialSharePrivacy_GetConfig();
		
		switch (common::GetCommand())
		{
			case 'SSP_defaults':
				$configData = SocialSharePrivacy_DefaultConfig();
				SocialSharePrivacy_SaveConfig($configData);
				break;
			
			case 'SSP_save':
				$configData['info_link']				= $_POST['info_link'];
				$configData['txt_help']				= $_POST['txt_help'];
				$configData['settings_perma']		= $_POST['settings_perma'];

				$configData['facebook']['status']		= $_POST['facebook-status'];
				$configData['facebook']['app_id']		= $_POST['facebook-app_id'];
				$configData['facebook']['txt_info']		= $_POST['facebook-txt_info'];
				$configData['facebook']['txt_fb_off']	= $_POST['facebook-txt_fb_off'];
				$configData['facebook']['txt_fb_on']	= $_POST['facebook-txt_fb_on'];
				$configData['facebook']['perma_option']	= $_POST['facebook-perma_option'];
				$configData['facebook']['display_name']	= $_POST['facebook-display_name'];
				$configData['facebook']['referrer_track']	= $_POST['facebook-refferer_track'];
				$configData['facebook']['language']		= $_POST['facebook-language'];
				
				$configData['twitter']['status']		= $_POST['twitter-status'];
				$configData['twitter']['txt_info']		= $_POST['twitter-txt_info'];
				$configData['twitter']['txt_twitter_off']	= $_POST['twitter-txt_twitter_off'];
				$configData['twitter']['txt_twitter_on']	= $_POST['twitter-txt_twitter_on'];
				$configData['twitter']['perma_option']	= $_POST['twitter-perma_option'];
				$configData['twitter']['display_name']	= $_POST['twitter-display_name'];
				$configData['twitter']['referrer_track']	= $_POST['twitter-refferer_track'];
				$configData['twitter']['tweet_text']		= $_POST['twitter-tweet_text'];
				
				$configData['gplus']['status']			= $_POST['gplus-status'];
				$configData['gplus']['txt_info']		= $_POST['gplus-txt_info'];
				$configData['gplus']['txt_gplus_off']		= $_POST['gplus-txt_gplus_off'];
				$configData['gplus']['txt_gplus_on']		= $_POST['gplus-txt_gplus_on'];
				$configData['gplus']['perma_option']	= $_POST['gplus-perma_option'];
				$configData['gplus']['display_name']		= $_POST['gplus-display_name'];
				$configData['gplus']['referrer_track']	= $_POST['gplus-referrer_track'];
				$configData['gplus']['language']		= $_POST['gplus-language'];
				
				SocialSharePrivacy_SaveConfig($configData);
				break;
		}
		
		$this->DisplayForm($configData);
	}
	
	function DisplayForm($configData)
	{
		$SSP_LANG = SocialSharePrivacy_GetLang();
		
		echo '<p><form action="" method="post">';
		echo '	<input type="hidden" name="cmd" value="SSP_defaults">';
		echo '	<input type="submit" name="reset" value="'.$SSP_LANG['reset_to_defaults'].'">';
		echo '</form></p>';
		echo '<p><form action="" method="post">';
		echo '	<table>';
		
		echo '	<tr><td colspan="4">';
		echo '		<h2>'.$SSP_LANG['general_settings'].'</h2>';
		echo '	</td></tr>';
		echo '	<tr><td>';
		echo '		'.$SSP_LANG['parameter'];
		echo '	</td><td>';
		echo '		'.$SSP_LANG['value'];
		echo '	</td><td>';
		echo '	</td><td>';
		echo '		'.$SSP_LANG['explanation'];
		echo '	</td></tr>';
		
		$this->FormFieldHelper($SSP_LANG, $configData, 'info_link', false);
		$this->FormFieldHelper($SSP_LANG, $configData, 'txt_help', false);
		$this->FormFieldHelper($SSP_LANG, $configData, 'settings_perma', false);

		echo '	<tr><td colspan="4">';
		echo '		<h2>'.$SSP_LANG['facebook_settings'].'</h2>';
		echo '	</td></tr>';
		echo '	<tr><td>';
		echo '		'.$SSP_LANG['parameter'];
		echo '	</td><td>';
		echo '		'.$SSP_LANG['value'];
		echo '	</td><td>';
		echo '	</td><td>';
		echo '		'.$SSP_LANG['explanation'];
		echo '	</td></tr>';
		$this->FormFieldHelper($SSP_LANG, $configData['facebook'], 'status', false, 'facebook-');
		$this->FormFieldHelper($SSP_LANG, $configData['facebook'], 'app_id', false, 'facebook-');
		$this->FormFieldHelper($SSP_LANG, $configData['facebook'], 'txt_info', false, 'facebook-');
		$this->FormFieldHelper($SSP_LANG, $configData['facebook'], 'txt_fb_off', false, 'facebook-');
		$this->FormFieldHelper($SSP_LANG, $configData['facebook'], 'txt_fb_on', false, 'facebook-');
		$this->FormFieldHelper($SSP_LANG, $configData['facebook'], 'perma_option', false, 'facebook-');
		$this->FormFieldHelper($SSP_LANG, $configData['facebook'], 'display_name', false, 'facebook-');
		$this->FormFieldHelper($SSP_LANG, $configData['facebook'], 'referrer_track', false, 'facebook-');
		$this->FormFieldHelper($SSP_LANG, $configData['facebook'], 'language', false, 'facebook-');
		
		echo '	<tr><td colspan="4">';
		echo '		<h2>'.$SSP_LANG['twitter_settings'].'</h2>';
		echo '	</td></tr>';
				echo '	<tr><td>';
		echo '		'.$SSP_LANG['parameter'];
		echo '	</td><td>';
		echo '		'.$SSP_LANG['value'];
		echo '	</td><td>';
		echo '		'.$SSP_LANG['delete'];
		echo '	</td><td>';
		echo '		'.$SSP_LANG['explanation'];
		echo '	</td></tr>';
		$this->FormFieldHelper($SSP_LANG, $configData['twitter'], 'status', false, 'twitter-');
		$this->FormFieldHelper($SSP_LANG, $configData['twitter'], 'txt_info', false, 'twitter-');
		$this->FormFieldHelper($SSP_LANG, $configData['twitter'], 'txt_twitter_off', false, 'twitter-');
		$this->FormFieldHelper($SSP_LANG, $configData['twitter'], 'txt_twitter_on', false, 'twitter-');
		$this->FormFieldHelper($SSP_LANG, $configData['twitter'], 'perma_option', false, 'twitter-');
		$this->FormFieldHelper($SSP_LANG, $configData['twitter'], 'display_name', false, 'twitter-');
		$this->FormFieldHelper($SSP_LANG, $configData['twitter'], 'referrer_track', false, 'twitter-');
		$this->FormFieldHelper($SSP_LANG, $configData['twitter'], 'tweet_text', true, 'twitter-');
		
		echo '	<tr><td colspan="4">';
		echo '		<h2>'.$SSP_LANG['gplus_settings'].'</h2>';
		echo '	</td></tr>';
				echo '	<tr><td>';
		echo '		'.$SSP_LANG['parameter'];
		echo '	</td><td>';
		echo '		'.$SSP_LANG['value'];
		echo '	</td><td>';
		echo '	</td><td>';
		echo '		'.$SSP_LANG['explanation'];
		echo '	</td></tr>';
		$this->FormFieldHelper($SSP_LANG, $configData['gplus'], 'status', false, 'gplus-');
		$this->FormFieldHelper($SSP_LANG, $configData['gplus'], 'txt_info', false, 'gplus-');
		$this->FormFieldHelper($SSP_LANG, $configData['gplus'], 'txt_gplus_off', false, 'gplus-');
		$this->FormFieldHelper($SSP_LANG, $configData['gplus'], 'txt_gplus_on', false, 'gplus-');
		$this->FormFieldHelper($SSP_LANG, $configData['gplus'], 'perma_option', false, 'gplus-');
		$this->FormFieldHelper($SSP_LANG, $configData['gplus'], 'display_name', false, 'gplus-');
		$this->FormFieldHelper($SSP_LANG, $configData['gplus'], 'referrer_track', false, 'gplus-');
		$this->FormFieldHelper($SSP_LANG, $configData['gplus'], 'language', false, 'gplus-');
		
		echo '</table>';
		echo '	<input type="hidden" name="cmd" value="SSP_save">';
		echo '	<input type="submit" name="save" value="'.$SSP_LANG['save'].'">';
		echo '</form></p>';
	}
	function FormFieldHelper($SSP_LANG, $configData, $name, $checkbox, $prefix='')
	{
		$this->FormField($prefix.$name, $configData[$name], $checkbox, $SSP_LANG[$name.'_label'], $SSP_LANG[$name.'_explain']);
	}
	function FormField($name, $value, $checkbox, $label, $text)
	{
		echo '	<tr><td>';
		echo '		'.$label;
		echo '	</td><td>';
		echo '		<input type="text" name="'.$name.'" value="'.$value.'">';
		echo '	</td><td>';
		if($checkbox)
			echo '		<input type="checkbox" name="'.$name.'_enable" '.(($value===false) ? 'checked="checked"' : '') .'>';
		echo '	</td><td>';
		echo '		'.$text;
		echo '	</td></tr>';
	}
}