<?php
defined('is_running') or die('Not an entry point...');

function SocialSharePrivacy_GetLang()
{
	global $addonPathCode, $config;
	
	if (file_exists($addonPathCode.'/lang/'.$config['language'].'.php'))
	{
		return include($addonPathCode.'/lang/'.$config['language'].'.php');
//		echo $addonPathCode.'/lang/'.$config['language'].'.php included';
	}
	else
	{
		return include($addonPathCode.'/lang/en.php');
//		echo $addonPathCode.'/lang/en.php included';
	}
}
function SocialSharePrivacy_GetConfig()
{
	global $addonDataFolder;
	global $SocialSharePrivacy_Config;
	$configFile = $addonDataFolder.'/SocialSharePrivacy_Config.php';
	
	if (!file_exists($configFile))
	{
		return SocialSharePrivacy_DefaultConfig();
	}
	require($configFile);
	
	return($SocialSharePrivacy_Config);
}

function SocialSharePrivacy_DefaultConfig()
{
	global $addonRelativeCode;
	
	$SSP_LANG = SocialSharePrivacy_GetLang();
	
	$configData= array();
	
	$configData['info_link']				= '';
	$configData['txt_help']				= $SSP_LANG['txt_help'];
	$configData['settings_perma']		= $SSP_LANG['settings_perma'];
	$configData['cookie_path']			= false;
	$configData['cookie_domain']			= false;
	$configData['cookie_expires']			= false;
	$configData['css_path']				= $addonRelativeCode.'/socialshareprivacy/socialshareprivacy.css';

	$configData['facebook']				= array();
	$configData['facebook']['status']		= 'on';
	$configData['facebook']['app_id']		= '__FB_APP-ID__';
	$configData['facebook']['dummy_img']	= $addonRelativeCode.'/socialshareprivacy/images/dummy_facebook.png';
	$configData['facebook']['txt_info']		= $SSP_LANG['txt_info'];
	$configData['facebook']['txt_fb_off']	= $SSP_LANG['txt_fb_off'];
	$configData['facebook']['txt_fb_on']	= $SSP_LANG['txt_fb_on'];
	$configData['facebook']['perma_option']	= 'on';
	$configData['facebook']['display_name']	= 'Facebook';
	$configData['facebook']['referrer_track']	= false;
	$configData['facebook']['language']		= '';
	
	$configData['twitter']				= array();
	$configData['twitter']['status']		= 'on';
	$configData['twitter']['dummy_img']		= $addonRelativeCode.'/socialshareprivacy/images/dummy_twitter.png';
	$configData['twitter']['txt_info']		= $SSP_LANG['txt_info'];
	$configData['twitter']['txt_twitter_off']	= $SSP_LANG['txt_twitter_off'];
	$configData['twitter']['txt_twitter_on']	= $SSP_LANG['txt_twitter_on'];
	$configData['twitter']['perma_option']	= 'on';
	$configData['twitter']['display_name']	= 'Twitter';
	$configData['twitter']['referrer_track']	= false;
	$configData['twitter']['tweet_text']		= false;
	
	$configData['gplus']				= array();
	$configData['gplus']['status']			= 'on';
	$configData['gplus']['dummy_img']		= $addonRelativeCode.'/socialshareprivacy/images/dummy_gplus.png';
	$configData['gplus']['txt_info']		= $SSP_LANG['txt_info'];
	$configData['gplus']['txt_gplus_off']		= $SSP_LANG['txt_gplus_off'];
	$configData['gplus']['txt_gplus_on']		= $SSP_LANG['txt_gplus_on'];
	$configData['gplus']['perma_option']	= 'on';
	$configData['gplus']['display_name']		= 'Google+';
	$configData['gplus']['referrer_track']	= false;
	$configData['gplus']['language']		= '';
	
	return $configData;
}

function SocialSharePrivacy_SaveConfig($configData)
{
	global $addonDataFolder, $langmessage;
	$configFile = $addonDataFolder.'/SocialSharePrivacy_Config.php';
	
	if (!gpFiles::SaveArray($configFile, 'SocialSharePrivacy_Config', $configData) )
	{
		message($langmessage['OOPS']);
		return false;
	}
	else
	{
		message($langmessage['SAVED']);
	}
}