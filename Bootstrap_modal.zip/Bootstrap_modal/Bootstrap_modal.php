<?php
defined('is_running') or die('Not an entry point...');


class Bootstrap_modal{
	
function SectionTypes($section_types) {
    $section_types['bootstrap_modal_section'] = array();
    $section_types['bootstrap_modal_section']['label'] = 'Modal window';
    return $section_types;
  }
  
 function SectionToContent($section_data) {
    if( $section_data['type'] != 'bootstrap_modal_section' ) {
      return $section_data;
    }
    
	if(preg_match_all("/{button=.+?}/", $section_data['content'], $text_button)){
	$section_data['content'] = str_replace($text_button[0], "", $section_data['content']);
	$text_button = str_replace("{button=", "", $text_button[0]);
	$text_button = str_replace("}", "", $text_button[0]);} else {$text_button="Click me";} 
	
	if(preg_match_all("/{title=.+?}/", $section_data['content'], $text_title)){
	$section_data['content'] = str_replace($text_title[0], "", $section_data['content']);
	$text_title = str_replace("{title=", "", $text_title[0]);
	$text_title = str_replace("}", "", $text_title[0]);} else {$text_title="&nbsp; &nbsp; &nbsp";} 
	
	ob_start();
    	
	echo '<div class="mod">';
   
    echo '<a href="#'.$section_data['modid'].'" class="btn btn-default" data-toggle="modal">'.$text_button.'</a>';
       
    echo '<div id="'.$section_data['modid'].'" class="modal fade">';
        echo '<div class="modal-dialog">';
            echo '<div class="modal-content">';
                echo '<div class="modal-header">';
                    echo '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>';
                   echo ' <h4 class="modal-title">'.$text_title.'</h4>';
              echo '  </div>';
             echo '   <div class="modal-body">';
                    
					echo $section_data['content'];
				echo ' 	<div class="modal-footer">';
                echo '     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>';
                    
              echo '   </div> ';
              echo '  </div>';
             
         echo '   </div>';
     echo '   </div>';
   echo ' </div>';
echo '</div>    '; 
	
	$section_data['content'] = ob_get_clean();
	
    return $section_data;
  }


  function DefaultContent($default_content,$type) {
    if( $type != 'bootstrap_modal_section' ) {
      return $default_content;
    }
    $section = array();
    $section['content'] = '<h4>New modal window!</h4>' . 
                           '<p>Your content.</p> Edit to see options.' .
						    ' {title=Your title for modal} {button= Your text for button}'  ;
			   
			   
    $section['modid'] = "modal-" . crc32(uniqid("",true));
    return $section;
  }


  function SaveSection($return,$section,$type) {
    if( $type != 'bootstrap_modal_section' ) {
      return $return;
    }
    global $page;
    $content =& $_POST['gpcontent'];
    $page->file_sections[$section]['content'] = $content;
    return true;
  }


  function GenerateContent_Admin() {
    global $addonFolderName, $page;
    static $done = false;
    if ($done || !common::LoggedIn()) { return; }
    $done = true;
  }


 static function InlineEdit_Scripts($scripts,$type) {
    if( $type !== 'bootstrap_modal_section' ) {
      return $scripts;
    }
    includeFile('tool/ajax.php');
   $scripts = gpAjax::InlineEdit_Text($scripts);
 
	
    return $scripts;
  }  
  
  
		
	
}


