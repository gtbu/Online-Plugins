<?php
defined('is_running') or die('Not an entry point...');

class Admin_GrGoogleAnalytics
{
  const mVersion           ='1.1';
  var $mKey                = 'UA-NNNNNNNN-N';
  var $mDisplayFeatures    = 0;

  function Admin_GrGoogleAnalytics()
  {
    $this->loadConfig();

    $cmd                   = common::GetCommand();

    switch($cmd){
      case 'saveConfig':
        $this->saveConfig();
        break;
    }
		$this->showForm();
  }

  function showForm()
  {
    global $langmessage;
    echo '<h1>GrGoogleAnalytics (v'.self::mVersion.')</h1>';

    echo '<h2>ID de acompanhamento</h2>';

    echo '<form action="'.common::GetUrl('Admin_GrGoogleAnalytics').'" method="post">';

    echo '<p>Entre com o código de acompanhamento do Universal Analytics</br>';
    echo '<input type="text" name="key" value="'.$this->mKey.'" class="gpinput" style="width:200px" />';
    echo '</p>';

    echo '<p>Deseja implementar os recursos da publicidade gráfica</br>';
    echo '<select name="displayFeatures">';
    if( $this->mDisplayFeatures )
    {
      echo '  <option value="0">Não</option>';
      echo '  <option value="1" selected="selected">Sim</option>';
    }
    else
    {
      echo '  <option value="0" selected="selected">Não</option>';
      echo '  <option value="1">Sim</option>';
    }
    echo '</select>';
    echo '</p>';

    echo '<input type="hidden" name="cmd" value="saveConfig" />';

    echo '<input type="submit" value="'.$langmessage['save_changes'].'" class="gpsubmit"/>';
    echo '</p>';
    echo '</form>';
  }

  function saveConfig()
  {
    global                   $addonPathData;
    global                   $langmessage;

    $configFile            = $addonPathData.'/config.php';
    $config                = array();
    $config['key']         = $_POST['key'];
    $config['displayFeatures'] = $_POST['displayFeatures'];
    $this->mKey            = $config['key'];
    $this->mDisplayFeatures = $configFile['displayFeatures'];

    if( !gpFiles::SaveArray($configFile,'config',$config) )
    {
      message($langmessage['OOPS']);
      return false;
    }

    message($langmessage['SAVED']);
    return true;
  }

  function loadConfig()
  {
    global                   $addonPathData;

    $configFile            = $addonPathData.'/config.php';
    include_once $configFile;

    if (isset($config)) {
      $this->mKey             = $config['key'];
      $this->mDisplayFeatures = $config['displayFeatures'];
    }
  }
}
// vim: set noai ts=2 sw=2: 
?>

