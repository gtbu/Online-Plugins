<?php defined('is_running') or die('Not an entry point...');
// encoding UTF-8 ÄÖÜäöüß

function FA_getHead() {
  global $page, $addonRelativeCode;
  // make FontAwesome site-wide
  if ( version_compare(gpversion, '5.0') < 0 ){
    // Typesetter CMS <= 5: We need to load  Font Awesome
    $page->css_user[] =  $addonRelativeCode . '/CKEditor_plugins/fontawesome_1_2/font-awesome/css/font-awesome.min.css';
    // enforce usage of FA in admin html
    $page->css_user[] = $addonRelativeCode . '/force_fa_admin.css';
  }else{
    common::LoadComponents('fontawesome');
  }
}

function CKEditor_addFontAwesomePlugin($plugins) {
  global $addonRelativeCode;
  $plugins['widget']      = $addonRelativeCode . '/CKEditor_plugins/widget_4_3_5_mod/';
  $plugins['lineutils']   = $addonRelativeCode . '/CKEditor_plugins/lineutils_4_3_5/';
  $plugins['fontawesome'] = $addonRelativeCode . '/CKEditor_plugins/fontawesome_1_2/';
  return $plugins;
}

function CKEditor_addFontAwesomeConfig($options) { 
  global $addonRelativeCode;
  if ( version_compare(gpversion, '5.0') < 0 ){
    $options['contentsCss'] = $addonRelativeCode . '/CKEditor_plugins/fontawesome_1_2/font-awesome/css/font-awesome.min.css';
    $options['allowedContent'] = true;
  }
  return $options;
}