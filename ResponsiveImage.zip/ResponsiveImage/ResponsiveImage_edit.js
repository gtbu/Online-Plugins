/**
 * JS/jQuery script for Typesetter CMS plugin Responsive Image - Editor Component
 * Author: J. Krausz
 * Version 1.5.6
 */

function gp_init_inline_edit(area_id, section_object){

  $gp.LoadStyle(ResponsiveImage.base + '/thirdparty/jquery.minicolors/jquery.minicolors.css');
  $gp.LoadStyle(ResponsiveImage.base + '/ResponsiveImage_edit.css');
  gp_editing.editor_tools();
  edit_div = gp_editing.get_edit_area(area_id);

  // add external plugins
  if( typeof(gp_add_plugins) == 'object' ){
    $.each(gp_add_plugins,function(name,path){
      CKEDITOR.plugins.addExternal(name,path);
    });
  }


  gp_editor = {

    save_path           : gp_editing.get_path(area_id),
    destroy             : function(){},
    checkDirty          : function(){ return gp_editor.optionsChanged; },
    resetDirty          : function(){},
    updateElement       : function(){},
    gp_saveData         : function(){},

    optionsChanged      : false,
    imageData           : { src : false, focusX : false, focusY : false, imageW : false, imageH : false },

    imageFromContent    : function(){},
    imageToContent      : function(){},

    selectUsingFinder   : function(){},

    setFocusPoint       : function(){},
    updateFocusPoint    : function(){},
    updateEditor        : function(){},

    showHelperOverlay   : function(){},
    hideHelperOverlay   : function(){},
    moveHelperOverlay   : function(){},

    imageHeight         : { heightType : false, heightValue : false, heightUnits : false },
    getImageHeight      : function(){},
    updateImageHeight   : function(){},

    showCaption         : false,
    captionBgColor      : false,
    setCaptionBgColor   : function(){},
    editCaption         : function(){},
    updateCaption       : function(){},
    setShowCaption      : function(){},

    link                : false,
    useColorbox         : false,
    editLink            : function(){},
    updateLink          : function(){},
    fullScreen          : false,
    updateDataAttr      : function(){}

  };



  gp_editor.gp_saveData = function(){
     var save_clone = edit_div.clone();
     save_clone.find(".gpclear, .fullscreen-trigger").remove();
     var content = save_clone.html();
     save_clone = null;
     gp_editor.optionsChanged = false;
     return '&gpcontent=' + encodeURIComponent(content)
     + '&' + $.param(gp_editor.imageHeight);
  };



  gp_editor.getImageHeight = function(){
    gp_editor.imageHeight = {
      heightType  : section_object.image_height_type  || false,
      heightValue : section_object.image_height_value || false,
      heightUnits : section_object.image_height_units || false
    }
  };



  gp_editor.updateImageHeight = function(){

    gp_editor.imageHeight = {
      heightType  : $("#gp_RI_imageHeightType").val(),
      heightValue : $("#gp_RI_imageHeightValue").val(),
      heightUnits : $("#gp_RI_imageHeightUnits").val()
    }

    if (gp_editor.imageHeight.heightType == "proportional") {
      $("#gp_RI_imageHeightValue").prop("disabled", false);
      $("#gp_RI_imageHeightUnits").val("%").prop("disabled", true);
      edit_div.find(".responsive_image_wrapper").css({ 
        "height" : "0",
        "padding-top" : gp_editor.imageHeight.heightValue + "%"
      });
    }

    if (gp_editor.imageHeight.heightType == "fixed") {
      $("#gp_RI_imageHeightValue").prop("disabled", false);
      $("#gp_RI_imageHeightUnits").prop("disabled", false);
      edit_div.find(".responsive_image_wrapper").css({ 
        "height" : gp_editor.imageHeight.heightValue + gp_editor.imageHeight.heightUnits,
        "padding-top" : "0"
      });
      if( gp_editor.imageHeight.heightUnits == "%" ){
        if( typeof(delayHeight)=="number"){
          clearTimeout(delayHeight);
        }
        delayHeight = setTimeout( function(){
          var sectionHeight = edit_div.height();
          if( sectionHeight < 40 ){
            alert('The current section does not appear to \n'
              + 'have a suitable height defined in a stylesheet \n'
              + 'or via section options. Thus, using percents of \n'
              + 'section height seems to be inappropriate!');
          }
        }, 750);
      }
    }

    if( typeof(delayFocus) == "number" ){
      clearTimeout(delayFocus); 
    }
    delayFocus = setTimeout( function(){
      edit_div.find(".focuspoint").focusPoint('adjustFocus');
    }, 150);

    gp_editor.optionsChanged = true;
    $(window).trigger("resize");
  };



  gp_editor.updateDataAttr = function(){
    gp_editor.fullScreen = $("#gp_RI_fullScreenCheckbox").prop("checked");
    gp_editor.useColorbox = $("#gp_RI_useColorboxCheckbox").prop("checked");
    edit_div.find('.responsive_image_wrapper')
      .attr("data-enable-fullscreen", gp_editor.fullScreen)
      .attr("data-use-colorbox", gp_editor.useColorbox);
    if( gp_editor.fullScreen ){
      create_fullscreen_trigger( edit_div.find(".responsive_image_wrapper"));
    }else{
      edit_div.find(".fullscreen-trigger").remove();
    }
    gp_editor.optionsChanged = true;
  };



  gp_editor.destroyCK = function(){
    CKEDITOR.instances['gp_RI_captionHtml'].destroy();
  };



  gp_editor.editCaption = function(){
    var caption = edit_div.find('.responsive_image_caption').html();
    var boxHtml = '<div class="inline_box" id="gp_RI_caption">'
    + '<h3>'+gplang.cp+'</h3>'
    + '<textarea id="gp_RI_captionHtml" name="caption" cols="50" rows="3">'+$gp.htmlchars(caption)+'</textarea>'
    + '<p><input class="gpsubmit" type="submit" name="" onclick="gp_editor.updateCaption()" value="'+gplang.up+'" /> '
    + '<input class="gpcancel gp_admin_box_close" data-cmd="admin_box_close" onclick="gp_editor.destroyCK()" type="button" name="" value="'+gplang.ca+'" /></p>'
    + '</div>';
    $gp.AdminBoxC(boxHtml);
    CKEDITOR.config.baseFloatZIndex = 12000;
    CKEDITOR
      .replace("gp_RI_captionHtml",gp_RI_ckconfig)
      .on("instanceReady", function(){
        var CKhtml = this.document.$.documentElement;
        var CKbody = this.document.$.body;

        CKhtml.style.backgroundImage = 'url("' + gp_editor.imageData.src + '")';
        CKhtml.style.backgroundRepeat = 'no-repeat';
        CKhtml.style.backgroundPosition = 'center center';
        CKhtml.style.backgroundSize = 'cover';
        CKhtml.style.display = 'table';
        CKhtml.style.width = '100%';

        CKbody.style.display = 'table-cell';
        CKbody.style.verticalAlign = 'middle';
        CKbody.style.margin = '0';
        CKbody.style.padding = '0';
        CKbody.style.backgroundColor = gp_editor.captionBgColor;
      });
  };



  gp_editor.updateCaption = function(){
    gp_editor.destroyCK();
    var caption = $("#gp_RI_captionHtml").val();
    edit_div.find('.responsive_image_caption').html(caption);
    $gp.CloseAdminBox();
    gp_editor.setShowCaption();
    gp_editor.optionsChanged = true;
  };



  gp_editor.setCaptionBgColor = function(){
    edit_div.find('.responsive_image_caption_wrapper').css("background-color", gp_editor.captionBgColor);
    gp_editor.optionsChanged = true;
  };



  gp_editor.setShowCaption = function(){
    var capWrap = edit_div.find('.responsive_image_caption_wrapper')
    capWrap.removeClass("caption-show-always caption-show-hover caption-show-never");
    switch( gp_editor.showCaption ){
      case 'always':
        capWrap.addClass("caption-show-always");
        break;
      case 'never':
        capWrap.addClass("caption-show-never");
        break;
      case 'hover':
      default:
        capWrap.addClass("caption-show-hover");
        break;
    }
  };



  gp_editor.editLink = function(){
    var link = gp_editor.link;
    var boxHtml = '<div class="inline_box" id="gp_RI_link">'
    + '<h3>Link</h3>'
    + '<input id="gp_RI_linkurl" class="gpinput" style="width:70%; margin-right:10px;" placeholder="type to autocomplete" name="linkurl" value="'+$gp.htmlchars(link)+'" />'
    + '<input type="button" class="gpsubmit" style="width:10%;" value="clear" onClick="$(\'#gp_RI_linkurl\').val(\'\').focus()"/>'
    + '<input type="button" class="gpsubmit" style="width:10%;" value="select" onClick="gp_editor.selectUsingFinder(gp_editor.setLink)" />'
    + '<p>Type to autocomplete internal page URLs. External URLs (containing a protocol like http:\/\/) will open in a new window/tab. '
    + 'Clear the field or leave it empty to remove the link.</p>'
    + '<p><input class="gpsubmit" type="submit" name="" onClick="gp_editor.updateLink()" value="'+gplang.up+'" /> '
    + '<input class="gpcancel gp_admin_box_close" data-cmd="admin_box_close" type="button" name="" value="'+gplang.ca+'" /></p>'
    + '</div>';
    $gp.AdminBoxC(boxHtml);
    $("#gp_RI_linkurl").focus().autocomplete({
      source    : gptitles,
      appendTo  : "#gp_admin_boxc",
      delay     : 100,
      minLength : 0,
      select    : function(event, ui){
        if(ui.item) {
          $(this).val(encodeURI(ui.item[1]));
          event.stopPropagation();
          return false;
        }
      }
    }).data("ui-autocomplete")._renderItem = function(ul, item){
      return $("<li></li>")
        .data("ui-autocomplete-item", item[1])
        .append('<a>' + $gp.htmlchars(item[0]) + '<span>'+$gp.htmlchars(item[1])+'</span></a>')
        .appendTo(ul);
    };
  };



  gp_editor.setLink = function(fileUrl){
    $("#gp_RI_linkurl").val(fileUrl);
  };



  gp_editor.updateLink = function(){
    var link = $("#gp_RI_linkurl").val();
    gp_editor.link = link;
    if( link.trim() == "" ){
      edit_div.find(".responsive_image_wrapper").removeAttr("href target");
    }else{
      if( link.indexOf("://") != -1 ){
        edit_div.find(".responsive_image_wrapper").attr("target", "_blank");
      }else{
        if( (/\.(jpe?g|gif|png|apng|bmp|svg|svgz|webp)$/i).test(link) ){
          // if link points to an an (internal) image, activate colorBox option
          $("#gp_RI_useColorboxCheckbox").prop("checked", true).trigger("change");
        }
      }
      edit_div.find(".responsive_image_wrapper").attr("href", link);
    }
    $gp.CloseAdminBox();
    gp_editor.optionsChanged = true;
  };



  gp_editor.updateFocusPoint = function(){
    edit_div.find(".focuspoint")
      .attr({
        "data-image-w" : gp_editor.imageData.imageW,
        "data-image-h" : gp_editor.imageData.imageH,
        "data-focus-x" : gp_editor.imageData.focusX,
        "data-focus-y" : gp_editor.imageData.focusY
      })
      .data({
        "imageW" : gp_editor.imageData.imageW,
        "imageH" : gp_editor.imageData.imageH,
        "focusX" : gp_editor.imageData.focusX,
        "focusY" : gp_editor.imageData.focusY 
      })
      .focusPoint('adjustFocus');
  };



  gp_editor.selectUsingFinder = function(callback_fn){
    gp_editor.FinderSelect = function(fileUrl){
      if( fileUrl != "" ){
        callback_fn(fileUrl);
      }
      return true;
    };
    // open new gpFinder popup window
    var finderPopUp = window.open(gpFinderUrl, 'gpFinder', 'menubar=no,width=960,height=640');
    if( window.focus ){
      finderPopUp.focus();
    }
  };



  gp_editor.setImage = function(fileUrl){
    gp_editor.imageData.src = fileUrl;
    gp_editor.imageData.focusX = 0;
    gp_editor.imageData.focusY = 0;
    gp_editor.imageToContent();
    gp_editor.optionsChanged = true;
  };



  gp_editor.imageToContent = function(){
    var imgSrc = gp_editor.imageData.src;
    if( !imgSrc ){
      return false;
    }
    edit_div.find("img")
      .prop("src", imgSrc)
      .one("load", function(){
        gp_editor.imageData.imageW = $(this).naturalWidth();
        gp_editor.imageData.imageH = $(this).naturalHeight();
        gp_editor.updateFocusPoint();
        gp_editor.updateEditor();
      })
      .each(function(){
        if( this.complete ){
          $(this).trigger("load");
        }
      });
  };



  gp_editor.imageFromContent = function(){
    edit_div.find("img")
      .one("load", function(){
        gp_editor.imageData = {
          src     : $(this).attr("src"),
          imageW  : $(this).naturalWidth(),
          imageH  : $(this).naturalHeight(),
          focusX  : edit_div.find(".focuspoint").attr("data-focus-x"),
          focusY  : edit_div.find(".focuspoint").attr("data-focus-y")
        };
        gp_editor.updateFocusPoint();
      })
      .each(function(){
        if (this.complete) {
          $(this).trigger("load");
        }
      });
  };



  gp_editor.setFocusPoint = function(e){
    var et = $("#gp_RI_image_preview_area");
    var mx = e.pageX - et.offset().left + et.scrollLeft();
    var my = e.pageY - et.offset().top  + et.scrollTop();
    $("#gp_RI_focusPointCrosshair").css({
      "left" : Math.round(mx - 200) + "px",
      "top"  : Math.round(my - 200) + "px"
    });
    gp_editor.imageData.focusX = Math.round( 100 * (et.width() / 2 - mx) / et.width() * 2  ) / -100;
    gp_editor.imageData.focusY = Math.round( 100 * (et.height() / 2 - my) / et.height() * 2  ) / 100;
    gp_editor.updateFocusPoint();
    gp_editor.optionsChanged = true;
    // console.log( "focusX:" + gp_editor.imageData.focusX + " | focusY:" + gp_editor.imageData.focusY );
  };



  gp_editor.updateEditor = function(){
    var ipa = $("#gp_RI_image_preview_area");
    $("#gp_RI_preview_image").prop("src", gp_editor.imageData.src);
    var imgAspect = gp_editor.imageData.imageW / gp_editor.imageData.imageH;
    var scaledWidth =  imgAspect <= 1 ? Math.ceil(180 * imgAspect) : 180;
    var scaledHeight = imgAspect >= 1 ? Math.ceil(180 / imgAspect) : 180;
    /*
    console.log(
         "scaledWidth:" + scaledWidth 
      + " scaledHeight:" + scaledHeight
      + " natWidth:" + gp_editor.imageData.imageW 
      + " natHeight:" + gp_editor.imageData.imageH
    );
    */
    ipa.css({
      top : Math.round((180-scaledHeight)/2) + "px",
      width : scaledWidth + "px",
      height : scaledHeight + "px"
    });
    var fpx = gp_editor.imageData.focusX;
    var fpy = gp_editor.imageData.focusY;
    var chX = (parseFloat(fpx) + 1) * 0.5;
    var chY = (parseFloat(fpy) *-1 + 1) * 0.5;
    var chXpx = ipa.width() * chX - 200;
    var chYpx = ipa.height() * chY - 200;
    $("#gp_RI_focusPointCrosshair").css({
      "left" : chXpx.toFixed(0) + "px",
      "top"  : chYpx.toFixed(0) + "px"
    });
  };



  gp_editor.showHelperOverlay = function(){
    $("#gp_RI_helperOverlay").fadeIn(150);
  };



  gp_editor.hideHelperOverlay = function(){
    $("#gp_RI_helperOverlay").fadeOut(150);
  };



  gp_editor.moveHelperOverlay = function(e) {
    var et = $("#gp_RI_image_preview_area");
    var mx = e.pageX - et.offset().left + et.scrollLeft();
    var my = e.pageY - et.offset().top  + et.scrollTop();
    $("#gp_RI_helperOverlay").css({
      "left" : Math.round(mx - 200) + "px",
      "top"  : Math.round(my - 200) + "px"
    });
  };



  /**
   * Init Focuspoint
   */
  edit_div.find(".focuspoint").focusPoint();

  /**
   * Init Editor
   */
  gp_editor.imageFromContent(); 
  gp_editor.getImageHeight();
  gp_editor.link = edit_div.find('.responsive_image_wrapper').attr("href");
  gp_editor.fullScreen =  edit_div.find('.responsive_image_wrapper').attr("data-enable-fullscreen") == "true";
  gp_editor.useColorbox = edit_div.find('.responsive_image_wrapper').attr("data-use-colorbox") == "true";
  var capWrap = edit_div.find('.responsive_image_caption_wrapper');
  gp_editor.showCaption = "hover";
  gp_editor.showCaption = capWrap.hasClass("caption-show-always") ? "always" : gp_editor.showCaption;
  gp_editor.showCaption = capWrap.hasClass("caption-show-never")  ? "never"  : gp_editor.showCaption;
  gp_editor.captionBgColor = capWrap.css("background-color") || "";


  // RENDER EDITOR AREA
  var option_area = $('<div id="gp_RI_options"/>').prependTo('#ckeditor_controls');

  // IMAGE PREVIEW AREA
  $('<div id="gp_RI_image_canvas"><div id="gp_RI_image_preview_area">' + 
    '<img id="gp_RI_preview_image" src="' + gp_editor.imageData.src + '"/>' + 
    '<div id="gp_RI_helperOverlay"/>' + 
    '<div id="gp_RI_focusPointCrosshair" title="click to set focus point"/>' + 
    '</div></div>')
    .appendTo( option_area )
    .find('#gp_RI_image_preview_area')
    .on({
      'mouseenter' : gp_editor.showHelperOverlay,
      'mouseleave' : gp_editor.hideHelperOverlay,
      'mousemove'  : gp_editor.moveHelperOverlay,
      'click'      : gp_editor.setFocusPoint
    });


  // BUTTONS
  var buttons = $('<div class="full_width" style="padding-top:12px; margin-bottom:0;">'
   + '<button style="display:block; width:100%; margin-right:0!important;" '
   + 'id="gp_RI_getImageButton" class="ckeditor_control">Select Image</button> '
   + '<button style="display:block; width:48%; float:left;" '
   + 'id="gp_RI_editCaptionButton" class="ckeditor_control">Edit Caption</button>'
   + '<button style="display:block; width:48%; float:right; margin-right:0!important;" '
   + 'id="gp_RI_editLinkButton" class="ckeditor_control">Edit Link</button>'
   + '</div>');
  buttons.appendTo(option_area);
  buttons.find('#gp_RI_getImageButton').on('click', function(){
    gp_editor.selectUsingFinder(gp_editor.setImage);
  });
  buttons.find('#gp_RI_editCaptionButton').on('click', gp_editor.editCaption);
  buttons.find('#gp_RI_editLinkButton').on('click', gp_editor.editLink);


  // CAPTION SETTINGS
  $('<div class="full_width" ><label style="width:48%;">Show Caption</label>'
   + '<select id="gp_RI_showCaption" style="width:48%; margin-left:4%;">'
   + '<option value="always">always</option>'
   + '<option value="hover">hover/touch</option>'
   + '<option value="never">never</option>'
   + '</select></div>')
    .appendTo(option_area)
    .find('select')
    .each(function(){
      $(this).val(gp_editor.showCaption);
    })
    .on('change', function(){
      gp_editor.showCaption = $(this).val();
      gp_editor.setShowCaption();
      gp_editor.optionsChanged = true;
    });


  // CAPTION BACKGROUND
  var opc = gp_editor.captionBgColor.replace(/^.*,(.+)\)/,'$1') || true;
  $('<div class="full_width"><label>Caption Background</label><br/>'
   + '<input type="text" data-opacity="' + opc + '" style="width:100%;" '
   + 'id="gp_RI_captionBgColor" value="' + gp_editor.captionBgColor + '"/>'
   + '</div>')
    .appendTo(option_area)
    .find('input')
    .minicolors({
      format        : "rgb",
      keywords      : "transparent",
      defaultValue  : "rgba(0, 0, 0, 0.75)",
      opacity       : opc
    })
    .on('change', function(){
      gp_editor.captionBgColor = $(this).val().trim(); 
      gp_editor.setCaptionBgColor(); 
    });


  // COLORBOX OPTION
  $('<div class="full_width" style="padding-top:0; margin-top:0;">'
   + '<input type="checkbox" id="gp_RI_useColorboxCheckbox" /> '
   + 'Open Link in Colorbox'
   + '</div>')
    .appendTo( option_area )
    .find('input')
    .each(function(){
      $(this).prop("checked", gp_editor.useColorbox );
    })
    .on('click change', gp_editor.updateDataAttr );


  // FULLSCREEN OPTION
  $('<div class="full_width" style="padding-top:0; margin-top:0;">'
   + '<input type="checkbox" id="gp_RI_fullScreenCheckbox" />'
   + ' Show Full-Screen Button'
   + '</div>')
    .appendTo(option_area)
    .find('input')
    .each(function(){
      $(this).prop("checked", gp_editor.fullScreen);
    })
    .on('click change', gp_editor.updateDataAttr);


  // HEIGHT SETTINGS
  $('<div class="full_width" style="margin-bottom:0;">'
   + '<label>Clipping Frame Height</label><br/>'
   + '<select id="gp_RI_imageHeightType" style="width:100%">'
   + '<option value="proportional">proportional (% of width)</option>'
   + '<option value="fixed">fixed height</option>'
   + '</select></div>')
    .appendTo(option_area)
    .find('select')
    .each(function(){
      $(this).val(gp_editor.imageHeight.heightType);
    })
    .on('change', gp_editor.updateImageHeight);

  var imgHeightVals =
  $('<div class="full_width" style="margin-bottom:12px;">'
   + '<input type="number" style="width:60%;" id="gp_RI_imageHeightValue" class="ckeditor_input"/>'
   + '<select id="gp_RI_imageHeightUnits" style="width:35%; margin-left:5%;">'
   + '<option value="%">%</option>'
   + '<option value="px">px</option>'
   + '<option value="em">em</option>'
   + '<option value="rem">rem</option>'
   + '<option value="vw">vw</option>'
   + '<option value="vh">vh</option>'
   + '<option value="vmin">vmin</option>'
   + '<option value="vmax">vmax</option>'
   + '</select></div>');
  imgHeightVals.appendTo(option_area);

  imgHeightVals.find('input')
    .each(function(){
      $(this).val(gp_editor.imageHeight.heightValue);
    })
    .on('click keyup change', gp_editor.updateImageHeight);

  imgHeightVals.find('select')
    .each(function(){
      $(this).val(gp_editor.imageHeight.heightUnits);
    })
    .on('change', gp_editor.updateImageHeight);


  /**
   * Update Editor
   */
  gp_editor.updateEditor();
  loaded();

}



/**
 * jQuery natrualWidth and naturalHeight for IE
 * from http://www.jacklmoore.com/notes/naturalwidth-and-naturalheight-in-ie
 * Example usage: var nWidth = $('img#example').naturalWidth(), nHeight = $('img#example').naturalHeight(); 
 */
(function($){ var props = ['Width', 'Height'], prop;
  while (prop = props.pop()) {
  (function (natural, prop) {
    $.fn[natural] = (natural in new Image()) ?
      function () {
        return this[0][natural];
      } 
      : 
      function () {
        var node = this[0], img, value;
        if (node.tagName.toLowerCase() === 'img') {
          img = new Image();
          img.src = node.src,
          value = img[prop];
        }
        return value;
      };
    } ('natural' + prop, prop.toLowerCase()));
  }
}(jQuery));
