<?php
/**
 * PHP main class for Typesetter CMS plugin Responsive Image
 * Author: J. Krausz
 * Version 1.5.6
 */

defined('is_running') or die('Not an entry point...');

class ResponsiveImage{

  static function GetHead(){
    global $page, $addonRelativeCode;
    $page->css_user[] = $addonRelativeCode . '/ResponsiveImage.css';
    $page->head_js[]  = $addonRelativeCode . '/ResponsiveImage.js';
    \gp\tool::AddColorBox();
  }



  static function SectionTypes($section_types){
    $section_types['responsive_image'] = array();
    $section_types['responsive_image']['label'] = 'Responsive Image';
    $section_types['responsive_background'] = array();
    $section_types['responsive_background']['label'] = 'Responsive Background';

    return $section_types;
  }



  static function NewSections($links){
    global $addonRelativeCode;
    foreach($links as $key => $section_type_arr){
      if( $section_type_arr[0] == 'responsive_image' ){
        $links[$key] = array('responsive_image', $addonRelativeCode . '/icons/section-responsive_image.png');
      }
      if( $section_type_arr[0] == 'responsive_background' ){
        $links[$key] = array('responsive_background', $addonRelativeCode . '/icons/section-responsive_background.png');
      }
    }
    return $links;
  }



  static function DefaultContent($default_content, $type){
    if( $type !== 'responsive_image' && $type !== 'responsive_background' ){
      return $default_content;
    }

    global $addonRelativeCode;

    if( $type == 'responsive_image' ){
      $newSection = array();
      $newSection['content']  = '<a class="responsive_image_wrapper"';
      $newSection['content'] .= ' data-enable-fullscreen="false" ';
      $newSection['content'] .= ' data-use-colorbox="false"';
      $newSection['content'] .= '>';
      $newSection['content'] .=   '<div class="focuspoint" data-focus-x="0" data-focus-y="0" data-image-w="640" data-image-h="640">';
      $newSection['content'] .=     '<img alt="Image" src="' . $addonRelativeCode . '/img/default_image.png"/>';
      $newSection['content'] .=   '</div>';
      $newSection['content'] .=   '<div class="responsive_image_caption_wrapper caption-show-hover" style="background-color:rgba(0,0,0,0.75);">';
      $newSection['content'] .=     '<div class="responsive_image_caption">';
      $newSection['content'] .=       '<h3 style="text-align:center;"><span style="color:#ffffff;">Caption Heading</span></h3>';
      $newSection['content'] .=       '<p style="text-align:center;"><span style="color:#ffffff;">Caption Text</span></p>';
      $newSection['content'] .=     '</div>';
      $newSection['content'] .=   '</div>';
      $newSection['content'] .= '</a>';

      $newSection['image_height_type']  = 'proportional'; // 'fixed' | 'proportional'
      $newSection['image_height_value'] = '67';
      $newSection['image_height_units'] = '%'; // '%' | 'px' | 'em' | 'rem' | 'vw' | 'vh' | 'vmax' | 'vmin'

      $newSection['gp_label'] = 'Responsive Image';
      $newSection['gp_color'] = '#2daeff';
    }

    if( $type == 'responsive_background' ){
      $newSection = array();
      $newSection['content']  = '<a class="responsive_image_wrapper"';
      $newSection['content'] .= ' data-enable-fullscreen="false" ';
      $newSection['content'] .= ' data-use-colorbox="false"';
      $newSection['content'] .= ' style="height:100%; padding-top:0px;"';
      $newSection['content'] .= '>';
      $newSection['content'] .=   '<div class="focuspoint" data-focus-x="0" data-focus-y="0" data-image-w="640" data-image-h="640">';
      $newSection['content'] .=     '<img alt="Image" src="' . $addonRelativeCode . '/img/default_background.png"/>';
      $newSection['content'] .=   '</div>';
      $newSection['content'] .=   '<div class="responsive_image_caption_wrapper caption-show-never" style="background-color:rgba(0,0,0,0.75);">';
      $newSection['content'] .=     '<div class="responsive_image_caption"></div>';
      $newSection['content'] .=   '</div>';
      $newSection['content'] .= '</a>';

      $newSection['image_height_type']  = 'fixed'; // 'fixed' | 'proportional'
      $newSection['image_height_value'] = '100';
      $newSection['image_height_units'] = '%'; // '%' | 'px' | 'em' | 'rem' | 'vw' | 'vh' | 'vmax' | 'vmin'

      $newSection['gp_label'] = 'Responsive Background';
      $newSection['gp_color'] = '#2daeff';
    }

    return $newSection;
  }



  static function SaveSection($return,$section,$type){
    global $page;
    if( $type == 'responsive_image' || $type == 'responsive_background' ){
      $content =& $_POST['gpcontent'];
      $page->file_sections[$section]['content'] = $content;
      $page->file_sections[$section]['image_height_type'] =  $_POST['heightType'];
      $page->file_sections[$section]['image_height_value'] = $_POST['heightValue'];
      $page->file_sections[$section]['image_height_units'] = $_POST['heightUnits'];
      return true;
    }
    return $return;
  }



  static function InlineEdit_Scripts($scripts,$type){
    global $addonRelativeCode, $addonCodeFolder, $addonFolderName, $plugins;

    if( $type !== 'responsive_image' && $type !== 'responsive_background' ){
      return $scripts;
    }

    includeFile('tool/editing.php');

    // autocomplete
    echo \gp\tool\Editing::AutoCompleteValues(true);

    // ckeditor basepath and configuration
    $options = array();

    $ckeditor_basepath = (version_compare(gpversion, '5.1') > 0) ?
      \gp\tool::GetDir('/include/thirdparty/ckeditor/') :
      \gp\tool::GetDir('/include/thirdparty/ckeditor_34/');

    echo 'CKEDITOR_BASEPATH = ' . \gp\tool\Output\Ajax::quote($ckeditor_basepath) . '; ';
    echo 'var gp_RI_ckconfig = ' . \gp\tool\Editing::CKConfig($options, 'json', $plugins) . '; ';

    // extra plugins
    echo 'var gp_add_plugins = ' . json_encode($plugins) . ';';

    $scripts[] = (version_compare(gpversion, '5.1') > 0) ?
      '/include/thirdparty/ckeditor/ckeditor.js' :
      '/include/thirdparty/ckeditor_34/ckeditor.js';

    $scripts[] = '/include/js/ckeditor_config.js';

    // addon JS Data Object/basepath
    $addonBasePath = (strpos($addonRelativeCode,'addons/') > 0) ? '/addons/' . $addonFolderName : '/data/_addoncode/' . $addonFolderName;
    echo 'var ResponsiveImage = { base : "' . $addonBasePath . '" }; ';

    // scripts
    $scripts[] = $addonCodeFolder . '/thirdparty/jquery.minicolors/jquery.minicolors.min.js';
    $scripts[] = $addonCodeFolder . '/ResponsiveImage_edit.js'; 

    return $scripts;
  }

}
