/**
 * JS/jQuery for Typesetter CMS plaugin Responsive Image - Runtime
 * Author: J. Krausz
 * Version 1.5.6
 */

// Init new section
$(document).on("SectionAdded PreviewAdded SectionCopied", ".filetype-responsive_image, .filetype-responsive_background", function(){
  $(this).find(".focuspoint").focusPoint();
});

// Init section in new combo
$(document).on("SectionAdded PreviewAdded SectionCopied", ".filetype-wrapper_section", function(){
  var NewRiSection = $(this).find(".filetype-responsive_image, .filetype-responsive_background");
  if ( NewRiSection.length > 0 ){
    NewRiSection.find(".focuspoint").focusPoint();
  }
});


$(function() {

  // Init focuspoint
  $(".focuspoint").focusPoint();

  $(".responsive_image_wrapper").each( function() {
    // check fullscreen
    if ($(this).attr("data-enable-fullscreen") == "true") {
      create_fullscreen_trigger($(this).find(".focuspoint"));
    }
  });

  $(".responsive_image_wrapper").on("click", function(e){

    // check for using colobox
    if( $(this).attr("href") && $(this).attr("data-use-colorbox") == "true" ){

      var href = $(this).attr("href");

      // check if href points to an a file, prevent colorbox in case
      if( (/\.(pdf|doc?x|xsl?x|ppt?x|tif?f|gz?ip|bzip|tar|tgz|zip|7z|rar|sit?x|ods|odt|opus|oga|ogg|psd|avi|wav|mov|mpg|mpeg|mid|mp3|mp4|m4a|webm|aif?f|flac|asf)$/i).test(href) ){
        return;
      }

      // check if href points to an an image (internal or external)
      if( (/\.(jpe?g|gif|png|apng|bmp|svg|svgz|webp)$/i).test(href) ){
        var cbOpts = $gp.cboxSettings();
        cbOpts.open = true;
        $(this).colorbox(cbOpts);
        return false;
      }

      // prevent colorbox AJAXing internal links while logged In
      if( isadmin && href.indexOf("://") == -1 ){
        alert(
          "Loading internal links via AJAX in Colorbox is disabled while being logged-in. " 
          + "\nTo see how internal links will actually look in Colorbox (without header and footer),"
          + "\n please log out first. The internal link will now be loaded into an iframe."
        );
      }

      // check if href is an internal link (w/o protocol) and we're nit logged in
      if( href.indexOf("://") == -1 && !isadmin ){
        // tell Typesetter to only get the body content
        // console.log("colorbox: internal link");
        var cbOpts = $gp.cboxSettings();
        cbOpts.width = "90%";
        // cbOpts.height = "90%";
        cbOpts.href = updateQuery(href, 'gpreq', 'body');
        cbOpts.open = true;
        $(this).colorbox(cbOpts);
        return false;
      }

      // otherwise use iframe
      // console.log("colorbox: external link->iframe");
      var cbOpts = $gp.cboxSettings();
      cbOpts.iframe = true;
      cbOpts.fastIframe = false;
      cbOpts.width = "90%";
      cbOpts.height = "90%";
      cbOpts.open = true;
      $(this).colorbox(cbOpts);
      return false;
    }

  });



   // on touch enabled devices use: first tab->show caption, 2nd tab->follow link
   $(".responsive_image_wrapper").on('click',function(e){
     if ("ontouchstart" in document.documentElement && $(this).find(".responsive_image_caption_wrapper.caption-show-hover")) {
       $(this).data("touched", (typeof($(this).data("touched")) == "undefined" ? false : true ));
       if ($(this).data("touched")) {
         $(this).data("touched", false);
         $(this).trigger("mouseleave");
         return true;
       }
       $(this).trigger("mouseenter");
       e.preventDefault();
       e.stopPropagation();
       return false;
     }
   });

});



function updateQuery(uri, key, value){
  var re = new RegExp("([?|&])" + key + "=.*?(&|#|$)", "i");
  if (uri.match(re)) {
    return uri.replace(re, '$1' + key + "=" + value + '$2');
  } else {
    var hash =  '';
    if( uri.indexOf('#') !== -1 ){
        hash = uri.replace(/.*#/, '#');
        uri = uri.replace(/#.*/, '');
    }
    var separator = uri.indexOf('?') !== -1 ? "&" : "?";    
    return uri + separator + key + "=" + value + hash;
  }
}



/**
 * Create fullscreen trigger
 */
function create_fullscreen_trigger(obj){
  var fullscreen_support = document.body.webkitRequestFullScreen || document.body.requestFullScreen;
  if( !fullscreen_support ){ 
    return false;
  }
  $('<div title="make full screen" class="fullscreen-trigger">Full Screen</div>')
  .on("click", function(e) {
    e.stopPropagation();
    var elem = e.target.parentNode;
    if( $(elem).hasClass("is-fullscreen") ){
      $(elem).removeClass("is-fullscreen");
      $(this).attr("title" , "make full screen");
      if( document.exitFullscreen ){ 
        document.exitFullscreen(); 
      }else if( document.msExitFullscreen ){ 
        document.msExitFullscreen(); 
      }else if( document.webkitCancelFullScreen ){
        document.webkitCancelFullScreen();
      }
    } else {
      $(elem).addClass("is-fullscreen");
      $(this).attr("title" , "exit full screen");
      if( elem.requestFullscreen ){ 
        elem.requestFullscreen();
      }else if( elem.msRequestFullscreen ){
        elem.msRequestFullscreen();
      }else if( elem.webkitRequestFullscreen ){
        elem.webkitRequestFullscreen(); 
      }
    }
    return false;
  })
  .appendTo(obj);
}




/**
 * jQuery FocusPoint; version: 1.1.1
 * Author: http://jonathonmenz.com
 * Source: https://github.com/jonom/jquery-focuspoint
 * Copyright (c) 2014 J. Menz; MIT License
 * @preserve
 */
;
(function($) {

  var defaults = {
    reCalcOnWindowResize: true,
    throttleDuration: 17 //ms - set to 0 to disable throttling
  };

  //Setup a container instance
  var setupContainer = function($el) {
    var imageSrc = $el.find('img').attr('src');
    $el.data('imageSrc', imageSrc);

    resolveImageSize(imageSrc, function(err, dim) {
      $el.data({
        imageW: dim.width,
        imageH: dim.height
      });
      adjustFocus($el);
    });
  };

  //Get the width and the height of an image
  //by creating a new temporary image
  var resolveImageSize = function(src, cb) {
    //Create a new image and set a
    //handler which listens to the first
    //call of the 'load' event.
    $('<img />').one('load', function() {
      //'this' references to the new
      //created image
      cb(null, {
        width: this.width,
        height: this.height
      });
    }).attr('src', src);
  };

  //Create a throttled version of a function
  var throttle = function(fn, ms) {
    var isRunning = false;
    return function() {
      var args = Array.prototype.slice.call(arguments, 0);
      if (isRunning) return false;
      isRunning = true;
      setTimeout(function() {
        isRunning = false;
        fn.apply(null, args);
      }, ms);
    };
  };

  //Calculate the new left/top values of an image
  var calcShift = function(conToImageRatio, containerSize, imageSize, focusSize, toMinus) {
    var containerCenter = Math.floor(containerSize / 2); //Container center in px
    var focusFactor = (focusSize + 1) / 2; //Focus point of resize image in px
    var scaledImage = Math.floor(imageSize / conToImageRatio); //Can't use width() as images may be display:none
    var focus =  Math.floor(focusFactor * scaledImage);
    if (toMinus) focus = scaledImage - focus;
    var focusOffset = focus - containerCenter; //Calculate difference between focus point and center
    var remainder = scaledImage - focus; //Reduce offset if necessary so image remains filled
    var containerRemainder = containerSize - containerCenter;
    if (remainder < containerRemainder) focusOffset -= containerRemainder - remainder;
    if (focusOffset < 0) focusOffset = 0;

    return (focusOffset * -100 / containerSize)  + '%';
  };

  //Re-adjust the focus
  var adjustFocus = function($el) {
    var imageW = $el.data('imageW');
    var imageH = $el.data('imageH');
    var imageSrc = $el.data('imageSrc');

    if (!imageW && !imageH && !imageSrc) {
      return setupContainer($el); //Setup the container first
    }

    var containerW = $el.width();
    var containerH = $el.height();
    var focusX = parseFloat($el.data('focusX'));
    var focusY = parseFloat($el.data('focusY'));
    var $image = $el.find('img').first();

    //Amount position will be shifted
    var hShift = 0;
    var vShift = 0;

    if (!(containerW > 0 && containerH > 0 && imageW > 0 && imageH > 0)) {
      return false; //Need dimensions to proceed
    }

    //Which is over by more?
    var wR = imageW / containerW;
    var hR = imageH / containerH;

    //Reset max-width and -height
    $image.css({
      'max-width': '',
      'max-height': ''
    });

    //Minimize image while still filling space
    if (imageW > containerW && imageH > containerH) {
      $image.css((wR > hR) ? 'max-height' : 'max-width', '100%');
    }

    if (wR > hR) {
      hShift = calcShift(hR, containerW, imageW, focusX);
    } else if (wR < hR) {
      vShift = calcShift(wR, containerH, imageH, focusY, true);
    }

    $image.css({
      top: vShift,
      left: hShift
    });
  };

  var $window = $(window);

  var focusPoint = function($el, settings) {
    var thrAdjustFocus = settings.throttleDuration ?
      throttle(function(){adjustFocus($el);}, settings.throttleDuration)
      : function(){adjustFocus($el);};//Only throttle when desired
    var isListening = false;

    adjustFocus($el); //Focus image in container

    //Expose a public API
    return {

      adjustFocus: function() {
        return adjustFocus($el);
      },

      windowOn: function() {
        if (isListening) return;
        //Recalculate each time the window is resized
        $window.on('resize', thrAdjustFocus);
        return isListening = true;
      },

      windowOff: function() {
        if (!isListening) return;
        //Stop listening to the resize event
        $window.off('resize', thrAdjustFocus);
        isListening = false;
        return true;
      }

    };
  };

  $.fn.focusPoint = function(optionsOrMethod) {
    //Shortcut to functions - if string passed assume method name and execute
    if (typeof optionsOrMethod === 'string') {
      return this.each(function() {
        var $el = $(this);
        $el.data('focusPoint')[optionsOrMethod]();
      });
    }
    //Otherwise assume options being passed and setup
    var settings = $.extend({}, defaults, optionsOrMethod);
    return this.each(function() {
      var $el = $(this);
      var fp = focusPoint($el, settings);
      //Stop the resize event of any previous attached
      //focusPoint instances
      if ($el.data('focusPoint')) $el.data('focusPoint').windowOff();
      $el.data('focusPoint', fp);
      if (settings.reCalcOnWindowResize) fp.windowOn();
    });

  };

  $.fn.adjustFocus = function() {
    //Deprecated v1.2
    return this.each(function() {
      adjustFocus($(this));
    });
  };

})(jQuery);
