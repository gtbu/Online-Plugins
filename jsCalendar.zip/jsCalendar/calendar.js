function jsCalendar(e, f, g, k, l) {
  this.hour_format = e;
  this.show_seconds = f;
  this.days = g;
  this.months = k;
  this.sfx = l;
  this.alternate = !0;
  this.tick = function() {
    var b = new Date, a = b.getHours(), c = b.getMinutes(), d = b.getSeconds(), e = b.getMonth(), f = b.getDay(), b = b.getDate(), h = "";
    if (12 == this.hour_format || 36 == this.hour_format) {
      h = " " + this.sfx[a];
    }
    12 == this.hour_format && (12 < a && (a -= 12), 0 == a && (a = 12));
    a = 10 > a ? "0" + a.toString() : a.toString();
    c = 10 > c ? "0" + c.toString() : c.toString();
    d = 10 > d ? "0" + d.toString() : d.toString();
    "0" == this.show_seconds ? document.getElementById("clock").innerHTML = a + ":" + c + ":" + d + h : "1" == this.show_seconds && (document.getElementById("clock").innerHTML = a + (this.alternate ? ":" : " ") + c + h, this.alternate = !this.alternate);
    document.getElementById("dayw").innerHTML = this.days[f];
    document.getElementById("day").innerHTML = b;
    document.getElementById("month").innerHTML = this.months[e];
    var g = this;
    window.setTimeout(function() {
      g.tick();
    }, 1E3);
  };
  this.tick();
}
;