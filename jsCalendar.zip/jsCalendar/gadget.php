<?php defined('is_running') or die('Not an entry point...');

global $page,$addonPathData,$addonPathCode,$addonRelativeData,$addonRelativeCode;

if ( file_exists($addonPathData.'/config.php') ){
	include($addonPathData.'/config.php');
}else{
  include($addonPathCode.'/config.php');
}

$page->head_js[] = $addonRelativeCode.'/calendar.min.js';

if ( file_exists($addonPathData.'/style.css') ){
	$page->css_user[] = $addonRelativeData.'/style.css';
}else{
	$page->css_user[] = $addonRelativeCode.'/style.css';
}

$page->jQueryCode .= "\n" . 'ojsCalendar = new jsCalendar('.$c['hour_format'].','.$c['show_seconds'].',new Array('.$c['days'].'),new Array('.$c['months'].'),new Array('.$c['sfx'].'));';
$page->jQueryCode .= "\n" . 'document.getElementById(\'calendar\').style.display = \'block\';';
$page->jQueryCode .= "\n" . 'document.getElementById(\'clock\').style.display = \'block\';';

echo '<div id="calendar">';
echo '<span id="dayw"></span><br/>';
echo '<span id="day"></span><br/>';
echo '<span id="month"></span>';
echo '</div>';
echo '<div id="clock"></div>';
