<?php 
defined('is_running') or die('Not an entry point...');

function GetAddonKey($addon_id)
{
	global $config;
	if(empty($config['addons']))
		return false;
	foreach($config['addons'] as $addon_key => $addon_info){
		if( isset($addon_info['id']) && $addon_info['id'] == $addon_id )
			return $addon_key;
	}
	return false;
}

function Install_Check()
{
	global $config;
	$key=GetAddonKey(109);
	if ($key) //if plugin already installed
	{
		$ver = 0+$config['addons'][$key]['version'];
		if ($ver<=1.4 && isset($config['gadgets']['jsCalendar']['calendar']))
		{
			//$config['gadgets']['jsCalendar']['disabled']=true;
			unset($config['gadgets']['jsCalendar']['calendar']);
			unset($config['gadgets']['jsCalendar']['dayw']);
			unset($config['gadgets']['jsCalendar']['day']);
			unset($config['gadgets']['jsCalendar']['month']);
			unset($config['gadgets']['jsCalendar']['clock']);
			unset($config['gadgets']['jsCalendar']['hour_format']);
			unset($config['gadgets']['jsCalendar']['show_seconds']);
			unset($config['gadgets']['jsCalendar']['lang']);
			unset($config['gadgets']['jsCalendar']['days']);
			unset($config['gadgets']['jsCalendar']['months']);
			unset($config['gadgets']['jsCalendar']['am']);
			unset($config['gadgets']['jsCalendar']['pm']);
			admin_tools::SaveConfig();
		}
	}
	return true;
}
