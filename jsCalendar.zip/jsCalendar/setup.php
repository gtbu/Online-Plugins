<?php defined('is_running') or die('Not an entry point...');
global $config, $title, $langmessage, $addonPathCode, $addonPathData, $addonRelativeCode;

//load config
$c = array();
$msg = array();
if (file_exists($addonPathData.'/config.php')) {
  //load saved config
  include($addonPathData.'/config.php');
  $lang= isset($_POST['lang']) ? $_POST['lang'] : $c['lang'];
  Load_Language($lang,$msg,$c);
}else{
  //use default config
  if ( !file_exists($addonPathData) ){
    gpFiles::CheckDir($addonPathData);
  }
  $c['hour_format'] = '24';
  $c['show_seconds'] = '0';
  $c['lang'] = '';
  Load_Language($config['language'],$msg,$c);
}

if ( isset($_GET['cmd']) && $_GET['cmd']=='defaults') { 
  //if restore default style
  if ( file_exists($addonPathData.'/style.css') ){
    unlink($addonPathData.'/style.css');
  }
}

//load style
$s = file_exists($addonPathData.'/style.css') ? $addonPathData . '/style.css' : $addonPathCode . '/style.css';
$style = file_get_contents($s);

// msg(pre($_POST));

//save posted settings
if ( isset($_POST['save_settings']) ){
  if ($c['lang'] != $_POST['lang'] && file_exists($addonPathCode . '/language/lang_' . $_POST['lang'] . '.php') ){
    $c['lang'] = $_POST['lang'];
    include($addonPathCode.'/language/lang_' . $_POST['lang'] . '.php');
  }
  $c['hour_format'] = 0+$_POST['hour_format'];
  $c['show_seconds'] = 0+$_POST['show_seconds'];
  gpFiles::SaveArray($addonPathData . '/config.php', 'c', $c);
  msg($langmessage['SAVED']);
}

//save posted style
if ( isset($_POST['save_style']) ){
  $style = $_POST['style'];
  $file = fopen($addonPathData.'/style.css', 'w');
  fwrite($file,$style);
  fclose($file);
  msg($langmessage['SAVED']);
}

echo  '<form action="' . $title . '" method="post" name="setup">';
echo  '<h2 class="hqmargin">' . $msg['setup'] . '</h2>';

echo  '<table class="bordered" style="width:100%;">';

echo    '<tr><th>Option</th><th>Value</th><th>Option</th><th>Value</th></tr>';

echo    '<tr>';
echo      '<td>' . $langmessage['language'] . '</td>';
echo      '<td colspan="3">';
            Select_Languages($c['lang']);
echo      '</td>';
echo    '</tr>';

echo    '<tr>';
echo      '<td>' . $langmessage['Preferences'] . '</td>';
echo      '<td>';
echo        '<select class="gpselect" id="hour_format" name="hour_format" onchange="ojsCalendar.hour_format=this.value;">';
echo          '<option value="12" ' . ($c['hour_format'] == "12" ? 'selected="selected"' : '') . '>' . $msg['h12'] . '</option>';
echo          '<option value="24" ' . ($c['hour_format'] == "24" ? 'selected="selected"' : '') . '>' . $msg['h24'] . '</option>';
echo          '<option value="36" ' . ($c['hour_format'] == "36" ? 'selected="selected"' : '') . '>' . $msg['h24'] . '*</option>';
echo        '</select>';
echo      '</td>'; 

echo      '<td>' . $msg['seconds'] . '</td>';
echo      '<td>';
echo        '<select class="gpselect" id="show_seconds" name="show_seconds" onchange="ojsCalendar.show_seconds=this.value;">';
echo          '<option value="0"' . ($c['show_seconds'] == '0' ? ' selected="selected"' : '') . '>' . $msg['visible'] . '</option>';
echo          '<option value="1"' . ($c['show_seconds'] == '1' ? ' selected="selected"' : '') . '>' . $msg['hidden'] . '</option>';
echo        '</select>';
echo      '</td>';
echo    '</tr>';

echo    '<tr>';
echo      '<td>' . $msg['appendices'] . '</td>';
echo      '<td colspan="3">';

echo        '<div style="float:left; margin-right:1em;">';
for ($i=0; $i < 6; $i++) {
  echo        '<div style="margin-bottom:4px;">';
  echo          '<span style="width:3em; text-align:right; display:inline-block;">' . $i . ':00 </span>';
  echo          ' <input style="width:6em;" class="gpinput" name="x' . $i . '" type="text" value="' . $c['x'][$i] . '" />';
  echo        '</div>';
}
echo        '</div>';

echo        '<div style="float:left; margin-right:1em;">';
for ($i=6; $i < 12; $i++) {
  echo        '<div style="margin-bottom:4px;">';
  echo          '<span style="width:3em; text-align:right; display:inline-block;">' . $i . ':00 </span>';
  echo          ' <input style="width:6em;" class="gpinput" name="x' . $i . '" type="text" value="' . $c['x'][$i] . '" />';
  echo        '</div>';
}
echo        '</div>';

echo        '<div style="float:left; margin-right:1em;">';
for ($i=12; $i < 18; $i++) {
  echo        '<div style="margin-bottom:4px;">';
  echo          '<span style="width:3em; text-align:right; display:inline-block;">' . $i . ':00 </span>';
  echo          ' <input style="width:6em;" class="gpinput" name="x' . $i . '" type="text" value="' . $c['x'][$i] . '" />';
  echo        '</div>';
}
echo        '</div>';

echo        '<div style="float:left;">';
for ($i=18; $i < 24; $i++) {
  echo        '<div style="margin-bottom:4px;">';
  echo          '<span style="width:3em; text-align:right; display:inline-block;">' . $i . ':00 </span>';
  echo          ' <input style="width:6em;" class="gpinput" name="x' . $i . '" type="text" value="' . $c['x'][$i] . '" />';
  echo        '</div>';
}
echo        '</div>';

echo      '</td>';
echo    '</tr>';

echo  '</table>';
echo  '<br/>';
echo  '<input class="gpsubmit" type="submit" name="save_settings" value="' . $langmessage['save'] . '" />';
echo '</form>';

echo  '<br/>';
echo  '<br/>';
echo '<form action="' . $title . '" method="post" name="fstyle">';

echo  '<table class="bordered" style="width:100%;">';
echo    '<tr><th>Option</th><th>Value</th></tr>';

echo    '<tr>';
echo      '<td>' . $langmessage['style'] . '</td>';
echo      '<td>';
echo        '<textarea id="clockstyle" style="width:100%;" name="style" rows="15" cols="50" spellcheck="false" wrap="off">' . htmlspecialchars($style) . '</textarea>';
echo      '</td>';
echo    '</tr>';
echo  '</table>';
echo  '<br/>';
echo  '<input class="gpsubmit" type="submit" name="save_style" value="' . $langmessage['save'] . '" /> ';
echo  common::link($title, $langmessage['restore_defaults'], 'cmd=defaults', 'class="gpcancel" onclick="javascript:return confirm(\'' . $msg['confirm'] . '\');"');
echo '</form>';


function Load_Language($try, &$msg, &$c){
  global $addonPathCode;
  if ( file_exists($addonPathCode . '/language/lang_' . $try . '.php') ){
    include($addonPathCode . '/language/lang_' . $try . '.php');
    // msg("Language loaded: " . $try);
    $lang = $try;
  }else{
    include($addonPathCode . '/language/lang_en.php');
    $lang = 'en';
  }
  if ( $lang != $c['lang'] ){
    //if language changed, we set default hour suffix
    for ($i = 0; $i < 24; $i++){
      $c['x'][$i] = ($i < 12) ? $msg['am'] : $msg['pm'];
    }
  }elseif ( isset($_POST['x0']) ){
    //else language not changed and if settings are posted
    for ($i = 0; $i < 24; $i++) {
      //we set posted suffixes
      $c['x'][$i] = $_POST['x'.$i]; 
    }
  }
  $c['lang'] = $lang;
  $c['days'] = '"' . implode('","', $msg['d']) . '"';
  $c['months'] = '"' . implode('","', $msg['m']) . '"';
  $c['sfx'] = '"' . implode('","', $c['x']) . '"';
}


function Select_Languages($selected){
  global $addonPathCode, $languages, $langmessage;
  $avail=array();
  if ( $handle = opendir($addonPathCode . '/language') ){
    while (false !== ($file = readdir($handle))) {
      if (strpos($file, 'lang_') !== false ){
        $avail[] = substr($file,5,-4);
      }
    }
    closedir($handle);
  }

  echo '<select class="gpselect" name="lang">';
  echo '<optgroup label="'.$langmessage['language'].'">';
  foreach ($avail as $lang){
    if ( !strlen($lang) ){
      continue;
    }
    $lang1 = isset($languages[$lang]) ? $languages[$lang] : $lang;
    echo '<option value="' . $lang . '"'. ($lang == $selected ? 'selected="selected"' : '') . '> ' . $lang . ' - ' . $lang1 . ' </option>';
  }
  echo '</optgroup>';
  echo '</select>';
}