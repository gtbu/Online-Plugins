<?php
defined('is_running') or die('Not an entry point...');
$fileVersion = '5.0-rc3';
$fileModTime = '1456637390';
$file_stats = array (
  'created' => 1456637390,
  'gpversion' => '5.0-rc3',
  'modified' => 1456637390,
  'username' => 'juergen',
);

$c = array (
  'hour_format' => 24,
  'show_seconds' => 0,
  'lang' => 'en',
  'x' => 
  array (
    0 => 'am',
    1 => 'am',
    2 => 'am',
    3 => 'am',
    4 => 'am',
    5 => 'am',
    6 => 'am',
    7 => 'am',
    8 => 'am',
    9 => 'am',
    10 => 'am',
    11 => 'am',
    12 => 'pm',
    13 => 'pm',
    14 => 'pm',
    15 => 'pm',
    16 => 'pm',
    17 => 'pm',
    18 => 'pm',
    19 => 'pm',
    20 => 'pm',
    21 => 'pm',
    22 => 'pm',
    23 => 'pm',
  ),
  'days' => '"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"',
  'months' => '"January","February","March","April","May","June","July","August","September","October","November","December"',
  'sfx' => '"am","am","am","am","am","am","am","am","am","am","am","am","pm","pm","pm","pm","pm","pm","pm","pm","pm","pm","pm","pm"',
);

