/* UTF-8! ÄÖÜäöüß
######################################################################
JS/jQuery for gpEasy Collapsible Wrappers
Author: J. Krausz
Date: 2015-08-30
######################################################################
*/

$(document).on("section_sorting:loaded", function(e) { 
  gpE_CW_CollapseWrappers();
});

$(document).on("click", "#cktabs a[data-arg='#section_sorting']", function(e) { 
  if ($("#section_sorting .secsort_wrapper-collapsible").length < 1) {
    gpE_CW_CollapseWrappers();
  }
});

function gpE_CW_CollapseWrappers() {
  $("#section_sorting ul.section_drag_area").hide();
  $(".section_drag_area").closest("li").each( function() {
    $(this).addClass("secsort_wrapper-collapsible secsort_wrapper-collapsed")
    .find("div").first().find("i")
    .prepend('<span class="secsort_wrapper-collapse-toggle"/>')
    .find("span.secsort_wrapper-collapse-toggle")
    .on("click", function() {
      $(this).closest("li.secsort_wrapper-collapsible")
        .toggleClass("secsort_wrapper-collapsed")
        .find("ul").first().slideToggle();
    });
  });
}