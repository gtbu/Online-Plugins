<?php /* UTF-8! ÄÖÜäöüß
######################################################################
PHP script for gpEasy Collapsible Wrappers
Author: J. Krausz
Date: 2015-08-30
######################################################################
*/

defined('is_running') or die('Not an entry point...');

class CollapsibleWrappers {

  function GetHead() {
    if (common::LoggedIn()) {
      global $page, $addonRelativeCode;
      $page->css_admin[] = $addonRelativeCode.'/CollapsibleWrappers.css';
      $page->head_js[] =   $addonRelativeCode.'/CollapsibleWrappers.js';
      
      if ( version_compare(gpversion, '4.6a1', '>=') ){
        $page->jQueryCode .= 
            "\n" . 'if ( window.location.href.indexOf("uninstall&addon=CollapsibleWrappers") == -1 ){'
          . "\n" . '  $gp.AdminBoxC(\'<h2>Plugin Incompatibility!</h2><p>Please ' 
          . common::Link('Admin_Addons','uninstall Collapsible Wrappers','cmd=uninstall&addon=CollapsibleWrappers')         
          . '<br/>because it is obsolete with gpEasy 4.6 and will cause errors!<br/><br/>Thank you</p>\');' 
          . "\n" . '}';
      }
    }
  }

}