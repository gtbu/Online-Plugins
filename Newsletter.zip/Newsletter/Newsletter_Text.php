<?php

defined('is_running') or die('Not an entry point...');

global $addonCodeFolder, $config;

if (file_exists("$addonCodeFolder/Newsletter_Text.php.".$config['language'])) {
	require_once("$addonCodeFolder/Newsletter_Text.php.".$config['language']);
} else {
	require_once("$addonCodeFolder/Newsletter_Text.php.en");
}

?>

