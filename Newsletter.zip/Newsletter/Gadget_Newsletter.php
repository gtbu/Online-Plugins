<?php
defined('is_running') or die('Not an entry point...');

global $addonCodeFolder;
require_once("$addonCodeFolder/Newsletter_Text.php");

class Gadget_Newsletter{
	function __construct(){
		global $addonRelativeCode,$linkPrefix, $NewsletterText;
		
		echo '<h4>', $NewsletterText['newsletter'], '</h4>';
		echo "<form action='$linkPrefix/Newsletter?cmd=subscribe' class='nsub' method='POST'>";
		echo '<label for="nl_email"><p class="title">';
		echo  $NewsletterText['gadget_text'];
		echo '</p><p><input class="text form-control" type="text" name="nl_email" value="" required="yes" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" maxlength="50" size="25"></p></label>';
		echo '<p><input type="submit" class="submit" name="aaa" value="', $NewsletterText['subscribe'], '" /></p></form>';
	}

}
