 <?php
defined('is_running') or die('Not an entry point...');

global $addonCodeFolder;
require_once("$addonCodeFolder/Newsletter_Text.php");

class Admin_Newsletter{
	function __construct(){
		
		global $addonRelativeCode,$linkPrefix, $NewsletterText;
		\gp\tool\Plugins::css('nstyle.css');
		
		echo "<form class='contactform nst' action='$linkPrefix/Newsletter?cmd=broadcast' method='post'>";
		echo '<label for="subject"><span class="title">';
		echo $NewsletterText['admin_subject']; 
		echo '</span><input class="input text" type="text" name="subject" value="';
		echo sprintf($NewsletterText['admin_headline'], $_SERVER['SERVER_NAME']);
		echo '"  /></label><label for="message"><span class="title">';
		echo $NewsletterText['admin_message'];  
		echo '</span><textarea name="message" class="nmess" rows="100" cols="50" maxlength="10000" autofocus required="yes" placeholder="Write something here">';
		echo '</textarea></label>';
		echo '<br><input type="submit" class="submit" value="', $NewsletterText['admin_send_button'], '" /></form>';
		echo "</div>";
	}
}


