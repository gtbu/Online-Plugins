<?php
defined('is_running') or die('Not an entry point...');

global $addonCodeFolder;
require_once("$addonCodeFolder/Newsletter_Text.php");

class Newsletter_Subscription{
	function __construct(){
		
		$cmd = common::GetCommand();
		
		if(empty($cmd)) $this->no_cmd();	
		
		switch($cmd){

			case 'subscribe':
				$this->subsc();
			break;

			case 'unsubscribe':
				$this->unsubsc();
			break;

			case 'broadcast':
				$this->broadcast();
			break;

			$this->no_cmd($cmd);

		}
	}
	
	function subsc(){
					
		global $addonDataFolder, $linkPrefix, $NewsletterText;
		
		if(isset($_POST['nl_email'])) {
			$nl_email = $_POST['nl_email'];
		} else {
			echo '<h2>', $NewsletterText['error'], '</h2>';
			echo '<p>', $NewsletterText['error1'], '</p>';
			return;
		}
			
		if(empty($nl_email) || !$this->mailcheckDNS($nl_email)) {
			echo '<h2>', $NewsletterText['error'], '</h2>';
			echo '<p>', sprintf($NewsletterText['error2'], $nl_email), '</p>';
			return;
		}
		
		$addresses = $this->getAddresses();
		$filename = "$addonDataFolder/addresses.dump";

		if(!array_key_exists($nl_email, $addresses)) {
			$addresses["$nl_email"] = 1;
			gpFiles::SaveArray($filename,'addresses',$addresses);
		}
				 
		$subject	= $NewsletterText['confirm_mail_subject'];
		
		$message	= $NewsletterText['confirm_mail_body'];
		$message	.= "\r\n--\r\n"; 
		$message	.= sprintf($NewsletterText['mailfooter'], $_SERVER['SERVER_NAME'], $linkPrefix,
				urlencode($nl_email));
		
		if($this->send_email($nl_email, '=?UTF-8?B?'.base64_encode($subject).'?=', $message)) {
			echo sprintf($NewsletterText['confirmation_sent'],$nl_email), '<br />';
		}
		echo '<h2>', $NewsletterText['thankyou'], '</h2>';
		echo '<p>', sprintf($NewsletterText['confirmation'], $nl_email), '</p>';
	}
	
	function unsubsc(){
		
		global $addonDataFolder, $NewsletterText;
		
		if(isset($_GET['nl_email'])) {
			$nl_email = $_GET['nl_email'];
		} else {
			echo '<h2>', $NewsletterText['error'], '</h2>';
			echo '<p>', $NewsletterText['error1'], '</p>';
			return;
		}
					
		$addresses = $this->getAddresses();
		$filename = "$addonDataFolder/addresses.dump";
		
		if(array_key_exists($nl_email, $addresses)) {
			unset($addresses["$nl_email"]);
			gpFiles::SaveArray($filename,'addresses',$addresses);
		}
		echo '<h2>', $NewsletterText['pity'], '</h2>';
		echo '<p>', sprintf($NewsletterText['unsub_text'], $nl_email), '</p>';
	}
	
	function broadcast(){
		
		global $linkPrefix, $NewsletterText;

		if(!isset($_POST['subject']) || !isset($_POST['message'])) {
			echo '<h2>', $NewsletterText['error'], '</h2>';
			echo '<p>', $NewsletterText['error3'], '</p>';
			return;
		}
		
		$subject = $_POST['subject'];
		$message = $_POST['message'];
		$message	.= "\r\n--\r\n"; 
		
		$addresses = $this->getAddresses();
		
		foreach(array_keys($addresses) as $a) {
			$message_complete = $message . sprintf($NewsletterText['mailfooter'], $_SERVER['SERVER_NAME'], $linkPrefix, urlencode($a));
			if($this->send_email($a, '=?UTF-8?B?'.base64_encode($subject).'?=', $message_complete)) {
				echo sprintf($NewsletterText['sending_ok'], $a), "<br />";
			} else {
				echo sprintf($NewsletterText['sending_fail'], $a), "<br />";
			}
		}
		return;
	}

	function no_cmd($cmd = ''){

		global $addonDataFolder, $NewsletterText, $linkPrefix;
		\gp\tool\Plugins::css('nstyle.css');
		
		if(!empty($cmd)) {
			echo '<h2>', $NewsletterText['error'], '</h2>';
			echo '<p>', sprintf($NewsletterText['error4'], $cmd), '</p>';
			return;
		}
		if(!common::LoggedIn()) {
			echo '';
			return;
		}
		$filename = "$addonDataFolder/addresses.dump";
		if(file_exists($filename)) {
			include_once($filename);
		} else {
			echo $NewsletterText['no_address_file'];
			return;
		}
		
		if(count($addresses) == 0) {
			echo $NewsletterText['no_addresses'];
			return;
		}
		
		echo "<div><br><p>", $NewsletterText['addresses_list'], "</p><p>";
		foreach(array_keys($addresses) as $i) {
			echo "&#128231; "; echo $i; 
			echo '&nbsp;( <a href="', sprintf($NewsletterText['unsubscribe'], $_SERVER['SERVER_NAME'], $linkPrefix, urlencode($i)), '">';
			echo $NewsletterText['delete'], '</a>'; echo " )";
			echo "<br />";
		}
		echo "</p></div>";
	}
	
	function send_email($to, $subject, $message){
		global $langmessage, $config, $gp_mailer, $NewsletterText;

		includeFile('tool/email_mailer.php');

		//captcha
		/*
		if( !gp_recaptcha::Check() ){
			return;
		} */

		//subject
		$subject = strip_tags($subject);

		//message
		$tags = '<p><div><span><font><b><i><tt><em><i><a><strong><blockquote>';
		$message = strip_tags($message,$tags);

		$gp_mailer->AddCustomHeader('Content-type: text/plain; charset=utf-8');
 		
		if(isset($NewsletterText['from_address']) && !empty($NewsletterText['from_address'])) {
			$gp_mailer->SetFrom($NewsletterText['from_address']);
		}

		if(isset($NewsletterText['replyto_address']) && !empty($NewsletterText['replyto_address'])) {
			$gp_mailer->AddReplyTo($NewsletterText['replyto_address']);
		}
		
		if( $gp_mailer->SendEmail($to, $subject, $message) ){
			message($langmessage['message_sent']);
			return true;
		}

		message($langmessage['OOPS'].' (Send Failed)');
		return false;
	}
	
	function getAddresses() {
		
		global $addonDataFolder;
		$filename = "$addonDataFolder/addresses.dump";
		
		if(file_exists($filename)) {
			include_once($filename);
		} else {
			$addresses = array();
		}
		return $addresses;
	}
	
	function mailcheckDNS($mail) {
		return true;
		$email = htmlspecialchars($mail); 
		$r = false; 
		if(preg_match('/(.*?)\@(.*?)\.(\w){2,6}/i', $email)) { 
			$split = explode('@', $email); 
			$split2 = explode('.', $split[1]); 
			if(preg_match('/([a-z]){3,64}/i', $split2[0])) { 
				if(preg_match('/([a-z0-9\!\"\$\&\/\(\)\?\~\#\+\.\:\_\-]+){1,64}[^\@]/i', $split[0])) { 
					$MXCheck = getmxrr($split[1], $mxhosts); 
					if(!empty($MXCheck)) { 
						$r = true; 
					} 
				} 
			} 
		} 
		return $r; 
	}
}
?>

