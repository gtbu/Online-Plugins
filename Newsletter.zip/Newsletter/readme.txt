Short Documentation for the Newsletter Plugin for gpEasy
Plugin written by Martin Gürtel (guertel@web.de)

* 2022 updated to php8 by user mabu (Typesetter Forum)


INSTALLATION
------------
1. Unzip "Newsletter.zip"
2. Open "Newsletter_Text.php.en" or "Newsletter_Text.php.de".
   Here you can uncomment and edit the 
   $NewsletterText['from_address'] variable (line 19), if you want
   to use a sender address other than the one configured in the gpEasy
   Special_Contact e-mail settings. Optionally, you can set a reply-to
   address by uncommenting and editing the corresponding variable on
   line 20. Save.
3. Upload the folder Newsletter to your gpEasy 'addons' directory and
   install the plugin within the gpEasy admin area like any other plugin.
4. This Plugin uses the gpEasy Special_Contact e-mail settings, so you
   have to configure the built-in contact form using the dialog in
   Settings > Configuration > Contact.
   
USAGE
-----
- Visitors can subscribe to the Newsletter by entering their e-mail
  address in the Newsletter gadget.
- When logged in, you can see the list of subscribers on this page:
  Plugins > Newsletter Plugin > Abonnenten-Liste
  You can also unsubscribe addresses here.
- You can write a newsletter using this form:
  Plugins > Newsletter Plugin > Newsletter versenden
  Your newsletter will be sent to each subscriber automatically.