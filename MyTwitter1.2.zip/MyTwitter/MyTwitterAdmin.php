<?php
defined('is_running') or die('Not an entry point...');

class MyTwitterAdmin
{
  var $configFile;
  var $config = array();

	function MyTwitterAdmin()
  {
    $this->init();

		$cmd = common::GetCommand();
		if (common::LoggedIn()) {
			switch($cmd) {
				case 'save_config':
          $this->checkSave();
				break;
      }
    }
    $this->configForm();
	}

  function init()
  {
    global $addonPathData;

    $this->configFile = $addonPathData.'/index.php';
    $this->getData();
  }

  function getData()
  {
    global $langmessage;
    
		if (file_exists($this->configFile)) {
			require($this->configFile);
			$this->config = $twitterConfig;
		}
    else {
      $this->config = array('gadget_head'=>'MyTwitter', 'twitter_username'=>'username', 'gadget_enable'=>'enable');

   		if (!$this->saveConfig()) {
        message($langmessage['OOPS']);
      }
      else {
        message($langmessage['SAVED']);
      }
    }
  }

	function checkSave()
  {
		global $langmessage;
		
		$this->config['gadget_head'] = htmlspecialchars($_POST['gadget_head']);
		$this->config['twitter_username'] = htmlspecialchars($_POST['twitter_username']);
    if (isset($_POST['gadget_enable'])) {
      $this->config['gadget_enable'] = $_POST['gadget_enable'];
    }
    else {
      $this->config['gadget_enable'] = '';
    }

		if (!$this->saveConfig()) {
			message($langmessage['OOPS']);
		}
    else {
      message($langmessage['SAVED']);
    }
	}

	function saveConfig()
  {
		return gpFiles::SaveArray($this->configFile, 'twitterConfig', $this->config);
	}
	
  function configForm()
  {
    global $langmessage;
    $array =& $this->config;

		echo "<h2>MyTwitter Configuration</h2>\n";

		echo "<form action=\"".common::getUrl('Admin_MyTwitter')."\" method=\"post\">\n".
      "<table style=\"width:100%\">\n".
      "<tr>\n".
        "<td>Gadget Header</td>\n".
        "<td><input type=\"text\" name=\"gadget_head\" size=\"30\" value=\"".htmlspecialchars($array['gadget_head'])."\" /></td>\n".
			"</tr>\n".
      "<tr>\n".
        "<td>Twitter Username</td>".
        "<td><input type=\"text\" name=\"twitter_username\" size=\"30\" value=\"".htmlspecialchars($array['twitter_username'])."\" /></td>\n".
			"</tr>\n".
      "<tr>\n".
        "<td>Enable Gadget</td>".
        "<td><input type=\"checkbox\" name=\"gadget_enable\" value=\"enable\"";
          if ($array['gadget_enable'] == 'enable') echo " checked=\"checked\"";
        echo " /></td>\n".
			"</tr>\n".
      "<tr>\n".
        "<td></td>\n".
        "<td><input type=\"hidden\" name=\"cmd\" value=\"save_config\" />\n".
        "<input type=\"submit\" name=\"\" value=\"".$langmessage['save']."\" />\n".
        "<input type=\"submit\" name=\"cmd\" value=\"".$langmessage['cancel']."\" /></td>\n".
			"</tr>\n".
      "</table>\n".
      "</form>\n";
  }
}
