<?php
defined('is_running') or die('Not an entry point...');

class MyTwitterGadget
{
  var $header;
  var $username;
  var $is_working = true;

  function MyTwitterGadget()
  {
    $this->getData();
    if ($this->is_working and !common::LoggedIn()) {
      $this->showTweet();
    }
    if (common::LoggedIn()) {
			echo '<h3>'.$this->header.'</h3>'."\n";
			echo '<p>'.common::Link('Admin_MyTwitter', 'Twitter Admin').'</p>'."\n";
		}
  }

  function getData()
  {
    global $addonPathData;
    
    $configFile = $addonPathData.'/index.php';
    if (file_exists($configFile)) {
      require($configFile);
      $this->header = $twitterConfig['gadget_head'];
      $this->username = $twitterConfig['twitter_username'];
      if ($twitterConfig['gadget_enable'] != 'enable') {
        $this->is_working = false;
      }
    }
    else {
      $this->is_working = false;
    }
  }

  function showTweet()
  {
    $link = 'http://search.twitter.com/search.atom?q=from:'.$this->username.'&rpp=1';
    $feed = file_get_contents($link);
    ereg("<content type=\"html\">(.*)</content>", $feed, $tweet);
    
    echo '<h3>'.$this->header.'</h3>'."\n";

    if (!empty($tweet[1])) echo '<p>'.htmlspecialchars_decode($tweet[1]).'</p>'."\n";
		else echo '<p><a href="http://twitter.com/'.$this->username.'">'.$this->username.'.</a></p>'."\n";
  }
}
