var directionDisplay, directionsService = new google.maps.DirectionsService, map;
$(function() {
  directionsDisplay = new google.maps.DirectionsRenderer;
  var a = new google.maps.LatLng(50.903315, 13.67583), b = {zoom:17, mapTypeId:google.maps.MapTypeId.ROADMAP, center:a};
  map = new google.maps.Map(document.getElementById("map_canvas"), b);
  directionsDisplay.setMap(map);
  directionsDisplay.setPanel(document.getElementById("directionsPanel"));
  new google.maps.Marker({position:a, map:map, title:"Sportpark Dippoldiswalde", zIndex:1});
  $("#calc_route_button").click(calcRoute);
});
function calcRoute() {
  var a = {origin:document.getElementById("map_address").value, destination:"50.903315,13.67583", travelMode:google.maps.DirectionsTravelMode.DRIVING};
  directionsService.route(a, function(a, c) {
    c == google.maps.DirectionsStatus.OK && directionsDisplay.setDirections(a);
  });
}
;