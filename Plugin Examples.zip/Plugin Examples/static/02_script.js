gplinks.refresh_content = function(c, a) {
  a.preventDefault();
  var b = jPrep(this.href) + "&cmd=refresh";
  $.getJSON(b, ajaxResponse);
};
