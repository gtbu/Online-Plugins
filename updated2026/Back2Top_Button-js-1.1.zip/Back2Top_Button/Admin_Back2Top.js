/*
 * Back2Top Button admin behavior.
 * Native browser color controls; no jQuery or third-party picker dependency.
 */
(function () {
  'use strict';

  function initBack2TopAdmin() {
    var form = document.getElementById('b2t_config_form');
    if (!form) return;

    var dirty = false;
    function markDirty() { dirty = true; }

    form.addEventListener('input', markDirty);
    form.addEventListener('change', markDirty);

    form.addEventListener('submit', function () {
      dirty = false;
    });

    window.addEventListener('beforeunload', function (event) {
      if (!dirty) return;
      event.preventDefault();
      event.returnValue = '';
    });

    form.querySelectorAll('.b2t-native-color').forEach(function (picker) {
      var targetId = picker.getAttribute('data-target');
      var text = targetId ? document.getElementById(targetId) : null;
      if (!text) return;

      picker.addEventListener('input', function () {
        text.value = picker.value;
        markDirty();
      });

      text.addEventListener('input', function () {
        var value = text.value.trim();
        if (/^#[0-9a-f]{6}$/i.test(value)) {
          picker.value = value;
        } else if (/^#([0-9a-f])([0-9a-f])([0-9a-f])$/i.test(value)) {
          var m = value.match(/^#([0-9a-f])([0-9a-f])([0-9a-f])$/i);
          picker.value = '#' + m[1] + m[1] + m[2] + m[2] + m[3] + m[3];
        }
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initBack2TopAdmin);
  } else {
    initBack2TopAdmin();
  }
}());
