<?php
/*
######################################################################
PHP class for Typesetter CMS plugin Back2Top Button - Admin
Author: J. Krausz
Date: 2018-07-14
Version 1.0.3
######################################################################
*/

defined('is_running') or die('Not an entry point...');

class Back2Top{

  static $b2t_config;

  static function Gadget() {
    global $page, $addonRelativeCode, $addonRelativeData, $addonPathData;

    self::LoadConfig();
 
    $b2t_css_file = file_exists($addonPathData.'/b2t_custom.css') 
      ? $addonRelativeData.'/b2t_custom.css' 
      : $addonRelativeCode.'/defaults/b2t_custom.css';

    $page->css_user[] =   $addonRelativeCode.'/Back2Top.css';
    $page->css_user[] =   $b2t_css_file;
    $page->head_js[] =    $addonRelativeCode.'/Back2Top.js';

    $bt2_js_config = [
      'scroll_trigger' => (int) self::$b2t_config['scroll_trigger'],
      'scroll_speed'   => (int) self::$b2t_config['scroll_speed'],
      'scroll_easing'  => (string) self::$b2t_config['scroll_easing'],
    ];

    $page->head_script .= "\nvar bt2_config = "
      . json_encode(
          $bt2_js_config,
          JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
      )
      . ";\n";

    $text = htmlspecialchars((string) self::$b2t_config['text'], ENT_QUOTES, 'UTF-8');
    $icon = preg_match('/^b2t-arrow-(?:[0-9]|1[0-6])$/', (string) self::$b2t_config['icon'])
      ? self::$b2t_config['icon']
      : 'b2t-arrow-0';
    echo '<div class="gp_Back2Top"' . (self::$b2t_config['content'] < 2 ? ' title="' . $text . '"' : '') . '>';
    if( self::$b2t_config['content'] == 1 || self::$b2t_config['content'] == 3 ){
      echo '<span class="b2t-arrow ' . $icon . '"></span>';
    }
    if( self::$b2t_config['content'] > 1 ){
      echo '<span class="b2t-text">' . $text . '</span>';
    }
    echo '</div>';
  }


  static function LoadConfig() {
    global $addonPathCode, $addonPathData;
    $b2t_config_file = $addonPathData . '/b2t_config.php';
    if (file_exists($b2t_config_file)) {
      self::$b2t_config = \gp\tool\Files::Get($b2t_config_file, 'b2t_config');
    } else {
      include($addonPathCode . "/defaults/b2t_config.php");
      self::$b2t_config = $b2t_config;
    }
  }

}