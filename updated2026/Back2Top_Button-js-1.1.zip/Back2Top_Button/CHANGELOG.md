# Back2Top 1.0.3

## PHP 8.5 / current Typesetter maintenance release

- Updated addon version to 1.0.3.
- Migrated configuration reads/writes to the current `\\gp\\tool\\Files` API.
- Replaced deprecated `SaveArray()` with `SaveData()`.
- Hardened configuration POST handling against non-scalar values and unknown keys.
- Validated enum and numeric configuration values before saving.
- Escaped configuration values rendered into HTML attributes.
- Generated frontend configuration with `json_encode()` rather than manual JavaScript concatenation.
- Updated legacy jQuery `.bind()` usage to `.on()`.
- Added pointer-event handling for the hidden Back2Top button.
- Preserved the existing configuration format and frontend behavior.

## 1.0.4
- Removed the legacy Bootstrap Colorpicker dependency and bundled assets.
- Replaced it with the browser-native color input plus an editable CSS color value (including RGBA transparency).
- Rewrote admin form behavior in dependency-free vanilla JavaScript.
- Added strict CSS color-literal validation before writing generated CSS.
