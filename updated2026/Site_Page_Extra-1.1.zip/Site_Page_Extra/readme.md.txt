Updated Version 1.1 for php81+.

After installation you must register the areas with 

gpOutput::GetGadget('Site_Page_Extra1');
gpOutput::GetGadget('Site_Page_Extra2'); 
gpOutput::GetGadget('Site_Page_Extra3');   

in the sidebar within php-brackets.

You can of Course also place the single Gadgets in other places of the template.php