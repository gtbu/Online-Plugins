<?php defined('is_running') or die('Not an entry point...');

//gpPlugin::incl('AdminSitePageExtra.php','require_once');

global $addonPathCode;
require_once($addonPathCode . '/AdminSitePageExtra.php');

class SitePageExtraGadget extends AdminSitePageExtra{

	protected $gadgetPosition = null;

	public function __construct($position){
		// Gadget instances receive their position from Addon.ini's numbered class.
		$this->Init($position, false);
		$this->position = (int)$position;
		$this->gadgetPosition = (int)$position;
		$this->Run();
	}

	function Run(){
		global $gp_titles,$page;

		/* only show on defined pages
		if( !isset($gp_titles[$page->gp_index]) ){
			return;
		}
		*/

		$this->GetPageExtra();	
	}

	function GetPageExtra($name='Side_Menu'){
		global $page,$langmessage,$edit_index;

		if (!isset($page->gp_index)) {
			return;
		}

		$name=$page->gp_index;

		//load page specific extra content
		$extra_content = $this->LoadContent($name,'');
		if (empty($extra_content)) {
			//load default position specific extra content
			$extra_content=$this->LoadContentDefault($this->gadgetPosition,'');
		}

		//$extra_content = gpPlugin::Filter('GetExtra',array($extra_content,$name));
		$wrap = gpOutput::ShowEditLink('Admin_SitePageExtra');
		$permission = class_exists('admin_tools') && admin_tools::HasPermission('Admin_SitePageExtra');
		if( $wrap && $permission ){
			$edit_link = gpOutput::EditAreaLink($edit_index,'Admin_SitePageExtra',$langmessage['edit'],'file='.$name.'&position='.$this->position,' title="Page Extra '.$this->position.': '.$page->title.'" data-cmd="inline_edit_generic" ');

			ob_start();
			echo '<span class="nodisplay" id="ExtraEditLnks'.$edit_index.'">';
			echo $edit_link;
			echo common::Link('Admin_SitePageExtra',$langmessage['edit'].' Default','cmd=editdefault&file='.$name.'&position='.$this->position,' title="Page Extra '.$this->position.': '.$page->title.' Default"');
			echo common::Link('Admin_SitePageExtra','Site Page Extra','',' class="nodisplay"');
			echo '</span>';
			gpOutput::$editlinks .= ob_get_clean();

			echo '<div class="editable_area filetype-text" id="ExtraEditArea'.$edit_index.'">'; // class="edit_area" added by javascript
			echo !empty($extra_content)?$extra_content:$this->DefaultContent();// '<p>&nbsp;</p'; //for editing menu to show
			echo '</div>';
		}else{
			echo $extra_content;
		}
	}
}

class SitePageExtraGadget1 extends SitePageExtraGadget {
	public function __construct(){
		$this->Init(1, false);
		$this->position = 1;
		$this->gadgetPosition = 1;
		$this->Run();
	}
}
class SitePageExtraGadget2 extends SitePageExtraGadget {
	public function __construct(){
		$this->Init(2, false);
		$this->position = 2;
		$this->gadgetPosition = 2;
		$this->Run();
	}
}
class SitePageExtraGadget3 extends SitePageExtraGadget {
	public function __construct(){
		$this->Init(3, false);
		$this->position = 3;
		$this->gadgetPosition = 3;
		$this->Run();
	}
}
