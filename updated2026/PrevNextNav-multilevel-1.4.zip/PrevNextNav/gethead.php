<?php
/**
 * name:      prevnextnav.php
 * date:      16.03.2013
 * author:    Folke Ashberg
 * copyright: Folke Ashberg <https://www.ashberg.de>
 */
defined('is_running') or die('Not an entry point...');

function plugin_function($js_files){
    global $addonFolderName,$page;
    $page->css_user[] = '/data/_addoncode/'.$addonFolderName.'/style.css';
}

?>
