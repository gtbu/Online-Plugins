<?php
/**
 * name:      prevnextnav.php
 * date:      16.03.2013
 * author:    Folke Ashberg
 * copyright: Folke Ashberg <https://www.ashberg.de>
 * modified to multilevel 2026
 * PHP 8 compatibility update: the original navigation logic is retained,
 * but previous/next now follows the complete menu order, including child pages.
 */
defined('is_running') or die('Not an entry point...');

function PrevNextNav_MakeLink($title, $pos){
    $label = common::GetLabel($title, false);
    echo common::Link($title, "&nbsp;", '', 'class="arrow '.$pos.'" title="'.common::Ampersands($label).'"');
}

function PrevNextNav() {
    global $gp_menu, $page;

    if (!isset($gp_menu) || !is_array($gp_menu) || !isset($page->title)) {
        return false;
    }

    $currentTitle = $page->title;
    $prevTitle = '';
    $nextTitle = '';
    $upTitle = '';
    $currentLevel = -1;

    // Find the current page and its level.
    foreach ($gp_menu as $index => $info) {
        if (!is_array($info) || !isset($info['level'])) {
            continue;
        }
        $title = common::IndexToTitle($index);
        if ($title == $currentTitle) {
            $currentLevel = (int)$info['level'];
            break;
        }
    }

    if ($currentLevel < 0) {
        return;
    }

    /*
     * Walk the menu in its natural order. Unlike the original 2013 code,
     * this deliberately does not restrict previous/next to the current
     * level. Therefore level-2 (and deeper) pages participate in navigation.
     */
    $titles = array();
    $levels = array();

    foreach ($gp_menu as $index => $info) {
        if (!is_array($info) || !isset($info['level'])) {
            continue;
        }

        $title = common::IndexToTitle($index);
        if ($title === '' || $title === null) {
            continue;
        }

        $titles[] = $title;
        $levels[] = (int)$info['level'];
    }

    $currentPosition = -1;
    foreach ($titles as $position => $title) {
        if ($title == $currentTitle) {
            $currentPosition = $position;
            break;
        }
    }

    if ($currentPosition < 0) {
        return;
    }

    if ($currentPosition > 0) {
        $prevTitle = $titles[$currentPosition - 1];
    }

    if ($currentPosition + 1 < count($titles)) {
        $nextTitle = $titles[$currentPosition + 1];
    }

    // Keep the original 'up' fallback for a page which has no previous item.
    if ($currentPosition === 0 && $currentLevel > 0) {
        for ($i = $currentPosition - 1; $i >= 0; $i--) {
            if ($levels[$i] === $currentLevel - 1) {
                $upTitle = $titles[$i];
                break;
            }
        }
    }

    print '<div id="prevnextnav">' . "\n";
    print '<div id="prevnextnav_left">' . "\n";
    if ($prevTitle !== '') {
        PrevNextNav_MakeLink($prevTitle, 'left');
    } elseif ($upTitle !== '') {
        PrevNextNav_MakeLink($upTitle, 'up');
    }
    print '</div>' . "\n";
    print '<div id="prevnextnav_right">' . "\n";
    if ($nextTitle !== '') {
        PrevNextNav_MakeLink($nextTitle, 'right');
    }
    print '</div>' . "\n";
    print '</div>' . "\n";
}

PrevNextNav();

?>
