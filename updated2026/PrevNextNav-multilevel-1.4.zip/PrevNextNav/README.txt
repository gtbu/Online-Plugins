PrevNextNav 1.3.1

This is a conservative PHP 8.2-8.5 compatibility update of the original 2013 PrevNextNav addon.

Changes from the original:
- Preserves the original navigation algorithm and CSS.
- Replaces the nested global function 'makelink()' with a uniquely named global helper to prevent function redeclaration errors when the gadget is loaded more than once.
- Moves the $gp_menu validation before the first foreach.
- Removes duplicate/unused global declarations.

No visual/CSS redesign was made.
