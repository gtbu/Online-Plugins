<?php
defined('is_running') or die('Not an entry point...');


class Admin_PrevNextNav{
	function __construct(){ 
		echo '<h2>
	Typesetter5 PrevNextNav Plugin</h2>
<p>
	This Plugin provides a Gadget. It outputs a &lt;div&gt;-Element with two arrows left and right for previous and next page from same menulevel. 
	If no previous page exists the parent page is used. . This version is multilevel.</p>
	<p>
	Add such a line to your template.php:<br/>
	<pre>&nbsp;&nbsp;&lt;?php gpOutput::GetGadget(\'PrevNextNav\'); ?&gt;</pre>  
	Then edit the appropriate template and insert Gadget \'PrevNextNav\' to the section.
	</p>
	<p> 
	In some cases you will have to modify the div (id="prevnextnav") and the 2 arrows with arrow-id id="prevnextnav_left" and  right arrow class="arrow left" in the style.css.
	</p>
	<p>
	Plugin Homepage: <a target="_blank" href="https://www.ashberg.de">ashberg.de</a>
	</p>
';
	}
}
	

