/* UTF-8! ÄÖÜäöüß
######################################################################
JS/jQuery script for StickyNotes gpEasy Plugin
Author: J. Krausz
Date: 2015-03-29
Version 1.0
######################################################################
*/


$(window).load( function() {
  $(".filetype-sticky_note_section").fadeIn(500);
}); //winload end


$(document).ready( function() {

  $(".filetype-sticky_note_section").fadeOut(0);

  $(".filetype-sticky_note_section.draggable:not(.gp_editing)")
  .append('<div class="sticky_note_draghandle">&hellip;<br/>&hellip;<br/>&hellip;</div>')
  .on("mousedown", function() { $(this).css( { zIndex : "+=10" }); })
  .draggable({ 
    handle : ".sticky_note_draghandle" ,
    start : function(event,ui) { 
      $(this).css( { "right" : "auto" } );
    }
  });

  $(".filetype-sticky_note_section.closable:not(.gp_editing)")
    .append('<div class="sticky_note_dismiss">&times;</div>');

  $(".filetype-sticky_note_section .sticky_note_dismiss")
  .on("click" , function() {
    var really = true;
    if ( $("body").hasClass("gpAdmin") ) {
      really = confirm("Really dismiss this Sticky Note? \nYou will not be able to edit it unless you reload this page!");
    }
    if (really) { $(this).parent().fadeOut(200); }
  });

  $(window).on("resize", function() {
    $(".filetype-sticky_note_section").each( function() {
      var top = $(this).offset().top;
      var left = $(this).offset().left;
      if (left-$(this).width()+24 > $(window).innerWidth()) {
         $(this).css( { left : "auto", right : "auto" } );
         $(this).offset( { top : top, left : $(window).innerWidth() - $(this).width() - 12 } );
      }
    });
  });

}); // domready end