<?php 
/*UTF-8! ÄÖÜäöüß
######################################################################
PHP script for StickyNotes gpEasy Plugin
Author: J. Krausz
Date: 2015-03-29
Version 1.0
######################################################################
*/
defined('is_running') or die('Not an entry point...');

class StickyNote {

  static function GetHead() {
    global $page, $addonRelativeCode;
    common::LoadComponents('widget,draggable,mouse');
    $page->css_user[] = $addonRelativeCode . '/StickyNote.css';
    $page->head_js[] =  $addonRelativeCode . '/jquery.ui.touch-punch.min.js';
    $page->head_js[] =  $addonRelativeCode . '/StickyNote.js';
  }


  static function SectionTypes($section_types) {
    $section_types['sticky_note_section'] = array();
    $section_types['sticky_note_section']['label'] = 'StickyNote';
    return $section_types;
  }


  static function SectionToContent($section_data) {
    if( $section_data['type'] != 'sticky_note_section' ) {
      return $section_data;
    }
    // ob_start();
    // $section_data['content'] = ob_get_clean();
    return $section_data;
  }


  static function DefaultContent($default_content,$type) {
    if( $type != 'sticky_note_section' ) {
      return $default_content;
    }
    $section = array();
    $section['content'] = '<h4>Hi, I’m a new <br/>Sticky Note!</h4>' . 
                          '<p class="edit_me">Edit me&hellip; </p>' . 
                          '<p>My size adapts to my content. <br/>' . 
                           'Use [Shift]+Return for <br/>line breaks.</p>';
    $section['uniqid'] = "sn-" . crc32(uniqid("",true));
    $section['attributes'] = array ('class' => 'draggable closable', 'style' => 'position:absolute; top:1em; left:auto; right:36px;');
    return $section;
  }


  static function SaveSection($return,$section,$type) {
    if( $type != 'sticky_note_section' ) {
      return $return;
    }
    global $page;
    $content =& $_POST['gpcontent'];
    $page->file_sections[$section]['content'] = $content;
    return true;
  }


  static function GenerateContent_Admin() {
    global $addonFolderName, $page;
    static $done = false;
    if ($done || !common::LoggedIn()) { return; }
    $done = true;
  }


  static function InlineEdit_Scripts($scripts,$type) {
    if( $type !== 'sticky_note_section' ) {
      return $scripts;
    }
    includeFile('tool/ajax.php');
    $scripts = gpAjax::InlineEdit_Text($scripts);
    return $scripts;
  }

}